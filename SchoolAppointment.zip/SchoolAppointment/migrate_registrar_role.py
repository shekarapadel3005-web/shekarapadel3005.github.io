import sqlite3
import shutil
from pathlib import Path
from datetime import datetime

DB_PATH = Path(__file__).resolve().parent / "school.db"
TARGET_ID = 3
TARGET_EMAIL = "masid9461@gmail.com"
TARGET_ROLE = "Registrar Staff"

def main():
    if not DB_PATH.exists():
        raise SystemExit(f"STOP: Database not found: {DB_PATH}")

    # Confirm the intended account and expected original schema before changing anything.
    with sqlite3.connect(DB_PATH) as check:
        check.row_factory = sqlite3.Row
        account = check.execute(
            "SELECT id, name, email, role FROM users WHERE id = ?", (TARGET_ID,)
        ).fetchone()
        if not account:
            raise SystemExit("STOP: Account ID 3 was not found. No changes made.")
        if account["email"].lower() != TARGET_EMAIL or account["role"] != "Teacher":
            raise SystemExit(
                "STOP: Account ID 3 does not match the expected Teacher account. "
                "No changes made."
            )
        columns = [row["name"] for row in check.execute("PRAGMA table_info(users)")]
        expected = ["id", "name", "email", "password_hash", "role", "mobile", "student_number"]
        if columns != expected:
            raise SystemExit(
                f"STOP: Unexpected users columns: {columns}. No changes made."
            )
        user_sql_row = check.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='users'"
        ).fetchone()
        user_sql = user_sql_row["sql"] if user_sql_row else ""
        if "Teacher" not in user_sql or "Student" not in user_sql:
            raise SystemExit("STOP: Unexpected users role constraint. No changes made.")
        users_before = [tuple(row) for row in check.execute(
            "SELECT id,name,email,password_hash,role,mobile,student_number FROM users ORDER BY id"
        )]
        appointments_before = [tuple(row) for row in check.execute(
            "SELECT id,user_id,service,appointment_date,appointment_time,reason,status,"
            "reference_number,campus,verification_token FROM appointments ORDER BY id"
        )]
        index_list = list(check.execute("PRAGMA index_list(users)"))
        mobile_index = check.execute(
            "SELECT sql FROM sqlite_master WHERE type='index' AND name='idx_users_mobile_unique'"
        ).fetchone()
        if not mobile_index or not mobile_index["sql"]:
            raise SystemExit("STOP: Expected mobile unique index was not found. No changes made.")
        mobile_index_sql = mobile_index["sql"]
        if list(check.execute("PRAGMA foreign_key_check")):
            raise SystemExit("STOP: Existing foreign-key issues found. No changes made.")

    backup = DB_PATH.with_name(
        f"school_before_registrar_migration_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    )
    shutil.copy2(DB_PATH, backup)

    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    try:
        connection.execute("PRAGMA foreign_keys=OFF")
        connection.execute("BEGIN IMMEDIATE")

        connection.execute("""
            CREATE TABLE users_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('Student', 'Teacher', 'Registrar Staff')),
                mobile TEXT,
                student_number TEXT
            )
        """)

        connection.execute("""
            INSERT INTO users_new
                (id,name,email,password_hash,role,mobile,student_number)
            SELECT id,name,email,password_hash,
                   CASE WHEN id = ? AND role = 'Teacher' THEN 'Registrar Staff'
                        ELSE role END,
                   mobile,student_number
            FROM users
        """, (TARGET_ID,))

        connection.execute("DROP TABLE users")
        connection.execute("ALTER TABLE users_new RENAME TO users")
        connection.execute(mobile_index_sql)

        # Confirm the appointment table still points to users and the data is unchanged.
        users_after = [tuple(row) for row in connection.execute(
            "SELECT id,name,email,password_hash,role,mobile,student_number FROM users ORDER BY id"
        )]
        expected_users_after = [
            row[:4] + (TARGET_ROLE,) + row[5:] if row[0] == TARGET_ID else row
            for row in users_before
        ]
        appointments_after = [tuple(row) for row in connection.execute(
            "SELECT id,user_id,service,appointment_date,appointment_time,reason,status,"
            "reference_number,campus,verification_token FROM appointments ORDER BY id"
        )]
        if users_after != expected_users_after:
            raise RuntimeError("User data verification failed.")
        if appointments_after != appointments_before:
            raise RuntimeError("Appointment records changed unexpectedly.")
        fk_issues = list(connection.execute("PRAGMA foreign_key_check"))
        if fk_issues:
            raise RuntimeError(f"Foreign-key verification failed: {fk_issues}")

        connection.commit()
        connection.execute("PRAGMA foreign_keys=ON")
        integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise RuntimeError(f"Database integrity check failed after migration: {integrity}")

        print("SUCCESS: Registrar role migration completed.")
        print(f"Backup created: {backup.name}")
        print("Updated account: ID 3 — Aerish Canillas — Registrar Staff")
        print("Other user records: preserved")
        print("Appointment records: preserved")
        print("Foreign-key check: passed")
        print(f"Integrity check: {integrity}")
    except Exception:
        connection.rollback()
        print("MIGRATION STOPPED. The migration transaction was rolled back.")
        print(f"Keep the backup for safety: {backup.name}")
        raise
    finally:
        connection.close()

if __name__ == "__main__":
    main()
