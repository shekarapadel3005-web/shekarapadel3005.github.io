from getpass import getpass
import sqlite3

from werkzeug.security import generate_password_hash

from app import get_db


def main():
    with get_db() as db:
        if db.execute(
            "SELECT 1 FROM users WHERE role = 'Admin' LIMIT 1"
        ).fetchone():
            raise SystemExit(
                "An admin account already exists. Use the admin dashboard to assign additional admin roles."
            )

    name = input("Admin name: ").strip()
    email = input("Admin email: ").strip().lower()
    password = getpass("Password (at least 8 characters): ")
    confirmation = getpass("Confirm password: ")

    if not name or not email or "@" not in email:
        raise SystemExit("Enter a name and a valid email address.")
    if len(name) > 100 or len(email) > 254:
        raise SystemExit("Name or email is too long.")
    if len(password) < 8:
        raise SystemExit("Password must be at least 8 characters.")
    if password != confirmation:
        raise SystemExit("Passwords do not match.")

    try:
        with get_db() as db:
            db.execute("BEGIN IMMEDIATE")
            if db.execute(
                "SELECT 1 FROM users WHERE role = 'Admin' LIMIT 1"
            ).fetchone():
                raise SystemExit(
                    "An admin account already exists. Use the admin dashboard to assign additional admin roles."
                )

            db.execute(
                """
                INSERT INTO users (name, email, password_hash, role)
                VALUES (?, ?, ?, 'Admin')
                """,
                (name, email, generate_password_hash(password)),
            )
    except sqlite3.IntegrityError:
        raise SystemExit("That email address is already registered.") from None

    print("Admin account created. Sign in using the email and password you entered.")


if __name__ == "__main__":
    main()