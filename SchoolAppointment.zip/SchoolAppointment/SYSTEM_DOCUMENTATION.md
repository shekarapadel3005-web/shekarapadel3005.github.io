# School Online Appointment Booking System

## Evidence-based System Documentation

**Assessment scope:** Workspace source, templates, static assets, dependency declaration, virtual-environment metadata, and the active SQLite database; updated to document personnel assignment, database-backed dashboard filters, structured profile changes, approval, account security, and auditing.  
**Assessment date:** 2026-11-02  
**Assessment approach:** Source review, read-only inspection of the active database, implementation, and isolated Flask test-client validation against a disposable migrated database.  
**Change boundary:** Implemented assignment to Teachers or Registrar Staff, role-scoped availability, structured identity change requests with email verification and two-person review, 30-day cooldowns with logged Administrator override, notifications, authenticated password changes, and account audits. The SQLite schema changes are additive and will be applied by `init_db()` when the app next initializes. The workspace database was not modified during implementation or tests.  
**Test status:** Focused Flask test-client workflows passed against a disposable application/database, including both assignment roles, dashboard rendering, approval/cooldown behavior, email verification (mocked delivery), and password/session invalidation. Live SMTP delivery and the untested cases below still require verification.

### Evidence conventions

- **Source evidence** describes behavior present in the inspected code.
- **Database evidence** describes the schema and limited metadata observed from `school.db`; row contents were not inspected.
- **Observed environment** describes local workspace state only, not a supported deployment configuration.
- **Inferred** identifies a conclusion drawn from the implementation, not a tested result.
- **Not verified / requires testing** identifies behavior that could not be established without executing the system.
- Feature status uses **Implemented**, **Partially Implemented**, **Interface Only**, **Not Working**, and **Not Verified**. Here, “Implemented” means source-code support was identified; unless stated otherwise, it was not runtime-tested.

## 01 - System Overview

The application is a server-rendered web system titled “School Online Appointment Booking System.” Its implemented workflows cover account access, student appointment booking and cancellation, Registrar Staff assignment and office-wide appointment management, assigned-only Teacher review, Teacher and Registrar Staff availability, administrator account and appointment management, profile approval, password changes, notifications, account/appointment audit history, CSV export, appointment receipts, and QR-based appointment verification.

The primary application is [`app.py`](./app.py). It defines the Flask application, route handlers, authentication and authorization helpers, SQLite access, schema initialization, and business logic. HTML is rendered from [`templates/`](./templates/) and static resources are served from [`static/`](./static/).

### Scope and boundaries

- Appointment services configured in source: `Document Request`, `Consultation`, and `Other`.
- Appointment location assigned in source: `Main Campus – Registrar's Office`.
- Student booking offers 30-minute office-wide slots from 08:00 through 16:30, Monday through Saturday. Personnel availability and conflicts are checked when Registrar Staff assigns a Teacher or Registrar Staff member.
- The database is a local SQLite file named `school.db`.
- Password-reset email depends on external SMTP settings.
- No production deployment platform, external API, hardware specification, or tested service-level target was identified.

## 02 - Project Structure

The inventory below describes project-owned files and folders; `.venv` package internals are excluded.

| Path | Observed purpose |
|---|---|
| [`app.py`](./app.py) | Main Flask application, routes, business logic, database initialization, and direct-run entry point. |
| [`create_admin.py`](./create_admin.py) | Interactive command-line utility to create the first Admin account. Imports the application database helper. |
| [`migrate_registrar_role.py`](./migrate_registrar_role.py) | Standalone, targeted SQLite migration script for a specific registrar account/role. It contains fixed target-account assumptions and is not part of normal request handling. Do not run without reviewing its safeguards and intended target. |
| [`requirements.txt`](./requirements.txt) | Declares `Flask` and `qrcode[pil]`; dependency versions are not pinned. |
| [`school.db`](./school.db) | Active database path configured by `app.py`. It was inspected read-only. |
| `school.db.before_admin_20261031_071439.bak` | SQLite backup file present in the workspace. Its contents were not inspected. |
| `school_before_role_migration_20261030_224603.db` | SQLite backup file present in the workspace. Its contents were not inspected. |
| [`templates/index.html`](./templates/index.html) | Active shared page template for login, registration, password-reset views, student dashboard, and profile. |
| [`templates/admin_dashboard.html`](./templates/admin_dashboard.html) | Admin user and appointment management interface. |
| [`templates/registrar_dashboard.html`](./templates/registrar_dashboard.html) | Registrar office-wide appointment list, assignment controls, search, and decision interface. |
| [`templates/teacher_dashboard.html`](./templates/teacher_dashboard.html) | Teacher assigned-appointment list, approve/reject actions, weekly availability, and unavailable dates. |
| [`templates/receipt.html`](./templates/receipt.html) | Appointment receipt and QR presentation. |
| [`templates/verify_appointment.html`](./templates/verify_appointment.html) | Limited appointment details shown by a verification token. |
| `templates/index_backup.html` | Backup/older template. It contains a separate local-storage demo and must not be assumed to be active. |
| `templates/receipt_backup.html` | Backup receipt template; active route renders `receipt.html`. |
| `templates/registrar_dashboard_before_approval.html` | Earlier registrar template, not the template rendered by the active registrar route. |
| [`static/style.css`](./static/style.css) | Main custom stylesheet referenced by active page templates. |
| `static/style_backup.css` | Backup stylesheet; usage by active templates was not identified. |
| [`static/script.js`](./static/script.js) | Separate client-side local-storage implementation. The active templates inspected do not load this file; active-system use is not verified. |
| `.venv/` | Local Python virtual environment. Its `pyvenv.cfg` reports Python 3.14.7. This is not a declared support range. |
| `__pycache__/` | Generated Python bytecode cache. |

No separate README, deployment manifest, environment file, test suite, or project-level configuration file was identified in the inspected project-root inventory. The `static/profile_photos` folder was not present at inspection time; source code creates it when a profile image is saved.

## 03 - Technology Stack

| Layer | Evidence |
|---|---|
| Language/runtime | Python. The current local virtual environment metadata reports Python 3.14.7; supported versions are not declared. |
| Web framework | Flask. The dependency is declared without a version in `requirements.txt`; the local environment contains Flask 3.1.3. |
| Server-side rendering | Flask/Jinja templates, with HTML in `templates/`. |
| Client-side presentation | Custom CSS and inline JavaScript. No separate frontend framework or asset build pipeline was identified. |
| Persistence | SQLite using Python's standard-library `sqlite3` module. |
| Password hashing | Werkzeug password hashing helpers. |
| Signed reset token | itsdangerous `URLSafeTimedSerializer`. |
| Image handling | Pillow validates and normalizes uploaded profile images. |
| QR generation | `qrcode[pil]` produces QR-code images for receipts. |
| Email | Python standard-library `smtplib` and `email.message`; SMTP credentials/settings are read from environment variables. |
| Other standard-library use | `csv`, `io`, `os`, `secrets`, `shutil`, `datetime`, and related modules. |

The actual Flask and qrcode versions observed in the virtual environment are not pinned in the project's dependency declaration. Pillow, Werkzeug, and itsdangerous are imported or used directly by the source but are not separately listed in `requirements.txt`; they are present in the inspected environment through dependency installation.

## 04 - System Architecture

The application follows a small, single-process web architecture:

```mermaid
flowchart LR
    U[Browser] -->|HTTP form, page, or JSON request| F[Flask application and route handlers]
    F -->|SQL queries and writes| D[(SQLite school.db)]
    F -->|Jinja render| T[HTML templates]
    T -->|HTML response| U
    U -->|Static asset request| S[CSS and static files]
    F -->|SMTP, password reset only| M[Configured mail server]
    F -->|Generated QR and normalized images| A[QR response / profile image files]
```

Routes, authorization helpers, database routines, and business logic are concentrated in `app.py`. Route handlers interact directly with SQLite rather than through a separate ORM/service layer. Most pages use HTML form submissions and redirects; `/available-slots` returns JSON, and Admin export routes return CSV. The app records appointment creation, assignment changes, decisions, cancellations, and Admin status changes in `appointment_events`.

The direct-run branch invokes Flask's built-in development server with `debug=True`. A production WSGI server and production startup configuration were not identified.

## 05 - Feature Inventory

Status labels distinguish source implementation from the focused integration checks run against a disposable database. Do not interpret isolated tests as production deployment validation.

| ID | Feature and module | User | Input and processing | Output / database interaction | Dependencies / status / evidence |
|---|---|---|---|---|---|
| F-01 | Public account registration | Public; creates Student | Name, student number, email or mobile, password. Validates lengths/formats; forces role to Student; hashes password. Backend supports mobile-only identity using a placeholder email. | Inserts into `users`; redirects to login or re-renders with feedback. | Flask, Werkzeug, SQLite. **Partially Implemented:** active form requires email and has no mobile input, despite backend support. [`register`](./app.py), [`index.html`](./templates/index.html). |
| F-02 | Login and role routing | Account holders | Email or mobile plus password; checks password hash and `is_active`, then sets session identity/role. | Student/Admin go to their dashboards; Registrar Staff and Teacher go to separate role-specific dashboards. | Flask session, Werkzeug, SQLite. **Teacher login verified against an isolated database.** [`login`](./app.py). |
| F-03 | Password-reset request and reset | Users with email accounts | Email lookup; creates a signed token; sends a link by SMTP. Reset token is limited to 30 minutes; new password must be at least eight characters and match confirmation. | Updates `users.password_hash`; generic response is shown for reset request. | itsdangerous, SMTP, Werkzeug. **Implemented in source; email delivery not verified.** [`forgot_password`](./app.py), [`reset_password`](./app.py). |
| F-04 | Student dashboard and request history | Student | Session user identity scopes appointments before search, status/category/date filtering, and sorting. | Database-backed count and 20-row pagination; renders booking form and own requests. | Flask, SQLite, Jinja. **Search/filter/sort/pagination verified in isolation.** [`dashboard`](./app.py), [`index.html`](./templates/index.html). |
| F-05 | Appointment slot availability | Student | Date query parameter; parses ISO date, rejects past/Sunday dates, removes booked slots and past same-day slots. | JSON object with `slots`; reads non-cancelled appointments. | Flask JSON, SQLite, date/time. Slots are 08:00–16:30. **Implemented in source.** [`make_time_slots`](./app.py), [`available_slots`](./app.py). |
| F-06 | Appointment booking | Student | Service, date, time, reason. Validates service list, date, weekday, slot, reason length/non-empty value, and past times. Opens an immediate write transaction and checks occupied slot before insert. | Inserts a Pending appointment with generated reference, campus, and random verification token. | Flask, SQLite, `secrets`. **Implemented in source.** [`book`](./app.py). |
| F-07 | Appointment cancellation | Student | Appointment identifier; update is constrained by appointment owner and Pending status. | Changes status to Cancelled; redirects with feedback. | Flask, SQLite. **Implemented in source.** [`cancel`](./app.py). |
| F-08 | Appointment receipt and QR verification | Student; verification page is public to anyone with token URL | Student requests own appointment receipt. QR code encodes absolute verification URL. Public route looks up token. | Receipt includes QR; verification view returns reference, service, date, time, campus, and status. | `qrcode`, Pillow, Flask, SQLite. **Implemented in source; public-link operational behavior not tested.** [`appointment_receipt`](./app.py), [`verify_appointment`](./app.py), [`receipt.html`](./templates/receipt.html). |
| F-09 | Registrar appointment management and directories | Registrar Staff | Search appointments and apply status/category/date/personnel filters; choose a whitelisted sort; manage appointments. Search/filter/sort student and staff directories using available fields. | SQL filtering, counts, and 20-row pagination for appointments and directories. No department/course/year fields exist. | Flask, SQLite, Jinja. **Verified in isolation.** [`registrar_dashboard`](./app.py), [`registrar_dashboard.html`](./templates/registrar_dashboard.html). |
| F-10 | Admin user and role management | Admin | Forms create/edit account fields, assign one of four roles, suspend/reactivate accounts, and delete accounts. Role changes protect the signed-in Admin and last active Admin. Student number is shown and required only for Student accounts; suspend/delete require confirmation and Admin POST forms prevent repeat submission. Search/filter/sort the account directory, including Teacher assignment/schedule and Student appointment activity filters. | Reads/writes `users`; directory and appointments are filtered, sorted, counted, and paginated in SQL. | Flask, SQLite. Account management routes in [`app.py`](./app.py); interface in [`admin_dashboard.html`](./templates/admin_dashboard.html). |
| F-11 | Admin appointment status management | Admin | Submitted status must be one of Pending, Approved, Rejected, Cancelled. Rejection requires a reason. For non-cancelled status, checks for another non-cancelled appointment at same date/time. | Updates appointment status/rejection reason and records an event. | Flask, SQLite. **Implemented in source; Admin status route not runtime-tested.** [`admin_update_appointment_status`](./app.py). |
| F-12 | Admin CSV export | Admin | Chooses `users` or `appointments`; appointment export includes assigned Teacher and rejection reason; prefixes values beginning with common spreadsheet formula characters. | Returns downloadable `users.csv` or `appointments.csv`. | Python `csv`, SQLite, Flask `Response`. **Implemented in source; export not runtime-tested after added columns.** [`admin_export_csv`](./app.py). |
| F-13 | Profile management and photo upload | Student, Registrar Staff, Teacher, Admin | Name, email, mobile, student number, optional photo. Image limited to 3 MiB, formats JPEG/PNG/WebP, 20-million-pixel ceiling; resized to 512×512 and saved as JPEG. | Updates `users`; saves image under `static/profile_photos`; deletes replaced image when safe filename check passes. | Pillow, SQLite, filesystem. **Teacher profile page access verified against isolated database; profile updates/uploads not tested.** [`profile`](./app.py). |
| F-14 | Logout | Authenticated users | POST request with CSRF token. | Clears session and redirects to login. | Flask session. **Implemented in source.** [`logout`](./app.py). |
| F-15 | Database initialization and schema migration | Application startup | Creates tables/indexes if absent; adds missing columns; fills missing appointment reference/campus/token values; performs role migration when required. | Mutates `school.db` when `app.py` is imported/executed. | SQLite, filesystem backup in admin-role migration. **Implemented in source; startup can alter persistent data.** [`init_db`](./app.py), module-level initialization call. |
| F-16 | First Admin account creation | Operator with local command line | Interactive name/email/password/confirmation; password length and email/name checks; checks no Admin already exists. | Inserts Admin with password hash into `users`. | Python CLI, Werkzeug, SQLite. **Implemented in source; not executed.** [`create_admin.py`](./create_admin.py). |
| F-17 | Registrar role migration script | Operator with local command line | Script is hard-coded for one account ID/email and expected original schema; checks state and creates a backup before migration. | Alters `users` role constraint and target account role; verifies appointment data and integrity. | Python CLI, SQLite, `shutil`. **Script exists; not executed as part of this assessment.** [`migrate_registrar_role.py`](./migrate_registrar_role.py). |
| F-18 | Standalone local-storage demo | Not established | `static/script.js` contains client-side account and appointment logic using browser localStorage/sessionStorage. | Stores separate demo records in browser storage. | JavaScript/browser storage. **Not Verified as an active feature:** active templates inspected do not reference this script. |
| F-19 | Teacher assigned appointment management | Teacher | View only records assigned to own user ID; search, filter, and sort assigned requests; approve or reject Pending requests; configure availability. | SQL scope is constrained by the signed-in Teacher ID before filtering/pagination. | Flask, SQLite, Jinja. **Access scope and dashboard filters verified in isolation.** [`teacher_dashboard`](./app.py), [`teacher_dashboard.html`](./templates/teacher_dashboard.html). |
| F-20 | Appointment history / audit trail | Admin | View up to 100 newest event records with actor, reference, status changes, assignments, notes, and time. | Reads `appointment_events`; events are added for new bookings and later assignment/status transitions. | SQLite, Flask, Jinja. **Event creation and Admin display tested in isolation. Existing appointments receive no fabricated historical events.** [`log_appointment_event`](./app.py), [`admin_dashboard`](./app.py). |
| F-21 | Database-backed record search and browsing | Student, Teacher, Registrar Staff, Admin | Search partial terms case-insensitively; combine supported filters; sort by whitelisted appointment/user fields; move between pages while retaining query parameters. | Parameterized SQL predicates, safe sort maps, result counts, and 20-row page limits. | Flask, SQLite, Jinja. **Role-specific dashboards, filters, sorting, empty results, and page state verified in isolation.** Query helpers in [`app.py`](./app.py). |
| F-22 | Role-aware dashboard navigation and Admin form UX | Student, Teacher, Registrar Staff, Admin | Use shared role-specific links to existing page sections and profile; collapse the desktop sidebar or open/close its mobile drawer. Admin forms show and require Student Number only for Student accounts; destructive account actions require confirmation and POST buttons disable after submission. | Server-rendered navigation and forms; JavaScript handles responsive/collapsible navigation, role fields, and repeat-submit prevention. | Flask, Jinja, CSS, JavaScript. **All role dashboards/profiles, Admin field behavior, navigation, filter reset, confirmation, and repeat-submit prevention checked in isolated browser/test-client runs.** [`_dashboard_sidebar.html`](./templates/_dashboard_sidebar.html), [`admin_dashboard.html`](./templates/admin_dashboard.html). |

## 06 - User Roles and Permissions

Roles are constrained in the database to `Student`, `Teacher`, `Registrar Staff`, and `Admin`. Public registration always assigns Student. The Admin interface can create users and change roles among all four.

| Role | Supported actions in current source | Restrictions / findings |
|---|---|---|
| Student | Book appointments, view own requests, cancel own Pending appointment, view own receipt/QR, and edit own profile. Can see the assigned Teacher and rejection reason for their requests. | Cannot access registrar or Admin routes due role decorators. |
| Registrar Staff | View all appointment records, search references, assign/reassign/unassign active Teachers to Pending appointments, approve or reject Pending appointments, and edit own profile. | Assignment requires Teacher availability and no overlapping non-cancelled appointment. Cannot use Admin account-management/export routes. |
| Teacher | View only appointments assigned to their own account; approve or reject assigned Pending requests; maintain weekly availability and future unavailable dates; edit own profile. | Cannot view unassigned/other-Teacher records or use Registrar-wide/Admin routes. Rejections require a reason. |
| Admin | Manage accounts and roles; suspend/reactivate/delete users; update appointment status; export user and appointment CSVs; view the 100 most recent appointment events; edit own profile. | Cannot change own role, delete own account, or suspend own account. Code protects the last active Admin from selected removal/demotion operations. |

Role authorization is applied by `role_required`, which checks the current database role and active flag on protected endpoints. The root route's redirects rely on `session["user_role"]`, while protected routes perform a fresh database lookup.

An appointment has at most one assigned Teacher. No weekly availability rows means the Teacher is not assignable; assignment checks the Teacher's weekday window, date blocks, and conflicting non-cancelled assigned appointments. The application enforces the Teacher role for assignment; the database foreign key itself only verifies that the referenced user exists.

### Creating Staff accounts

An existing Admin can create a Registrar Staff or Teacher account from the Admin dashboard:

1. Sign in with an Admin account and open the Admin dashboard.
2. In **Create User**, enter the staff member's full name, email, and a temporary password of at least eight characters. Mobile and student number are optional for these roles.
3. Select **Registrar Staff** or **Teacher** for the role and submit **Create Account**.
4. The account is saved with the selected role and the password is hashed. Provide the account holder their credentials securely.

There is no public Registrar Staff or Teacher registration flow; public registration always creates a Student.

If no Admin account exists, create the initial Admin from the project directory with `.\.venv\Scripts\python.exe create_admin.py`, then use the Admin dashboard to create staff accounts. The helper is intended only for first-Admin setup. It imports `app.py`, whose module-level initialization can create or migrate the database; back up the database first and do not run it against production without reviewing that behavior.

Teacher login was previously blocked because the login route did not route the Teacher role and staff/profile endpoints excluded it. Teacher login now routes to a dedicated dashboard; authorization scopes appointment reads and decisions to appointments assigned to the signed-in Teacher. Registrar Staff retains the office-wide dashboard and assignment controls. Teacher-scoped access, assignment, decision reasons, and availability constraints were exercised using an isolated temporary database; broader profile/upload and production-database behavior remain untested.

## 07 - System Workflows

### Registration and login

```mermaid
flowchart TD
    A([Start]) --> B[Open registration]
    B --> C[/Enter name, student number, email or mobile, password/]
    C --> D{Server validation passes?}
    D -- No --> E[Display validation feedback]
    D -- Yes --> F[Hash password and insert Student account]
    F --> G[Open login]
    G --> H[/Submit email or mobile and password/]
    H --> I{Credentials correct and account active?}
    I -- No --> J[Display login error]
    I -- Yes --> K{Role handled by login route?}
    K -- Student --> L[Student dashboard]
    K -- Registrar Staff --> M[Registrar dashboard]
    K -- Teacher --> T[Assigned Teacher dashboard]
    K -- Admin --> N[Admin dashboard]
```

### Appointment booking and review

```mermaid
flowchart TD
    A([Student dashboard]) --> B[/Select appointment date/]
    B --> C[Request available slots]
    C --> D{Date eligible and slot available?}
    D -- No --> E[Display empty slots or guidance]
    D -- Yes --> F[/Choose service, time, and reason/]
    F --> G{Booking validation passes?}
    G -- No --> H[Display validation message]
    G -- Yes --> I[Begin immediate write transaction]
    I --> J{Slot still unoccupied?}
    J -- No --> K[Reject conflicting booking]
    J -- Yes --> L[Insert Pending request, identifiers, and creation event]
    L --> M[Student views request or receipt]
    M --> N[Registrar Staff assigns an available Teacher]
    N --> O{Teacher available and slot conflict-free?}
    O -- No --> P[Reject assignment and show feedback]
    O -- Yes --> Q[Save assignment and event]
    Q --> R[Assigned Teacher reviews request]
    R --> S{Teacher approves or rejects?}
    S -- Approve --> T[Set Approved and record event]
    S -- Reject --> U[Require reason, set Rejected, and record event]
    M --> V{Student cancels while Pending?}
    V -- Yes --> W[Set Cancelled and record event]
```

### Password reset

The visitor submits an email address. If it matches a user with a non-placeholder email, the application creates a signed token and attempts to send an external reset link. Request feedback is generic. The token must be valid and no older than 30 minutes; the new password must be at least eight characters and match confirmation before the password hash is updated.

### Admin account lifecycle

Admin visits the dashboard, selects account creation/edit/role/active/delete action, and submits a CSRF-protected POST form. The route validates allowed values and applies self/last-Admin restrictions where coded. Deleting a user explicitly deletes that user's appointments and removes a profile image if its filename passes the basename check.

## 08 - Functional Requirements

These are source-derived testable requirements. Results of the focused assigned-Teacher integration checks are recorded in Section 13:

| ID | Requirement | Implementation evidence | Test |
|---|---|---|---|
| FR-001 | The system shall allow public creation of Student accounts after validating required fields and password length. | [`register`](./app.py) | T-01, T-02 |
| FR-002 | The system shall authenticate users by email or mobile and password and deny inactive accounts. | [`login`](./app.py) | T-03 |
| FR-003 | The system shall support signed password-reset links with a maximum age of 30 minutes. | [`forgot_password`](./app.py), [`reset_password`](./app.py) | T-04 |
| FR-004 | The system shall show a Student their own appointment requests. | [`dashboard`](./app.py) | T-05 |
| FR-005 | The system shall provide eligible dates' available appointment times, excluding booked slots and past same-day times. | [`available_slots`](./app.py) | T-05 |
| FR-006 | The system shall allow Students to create a Pending appointment with an allowed service, eligible date/time, and non-empty reason. | [`book`](./app.py) | T-06 |
| FR-007 | The system shall prevent booking a date/time already occupied by a non-cancelled appointment at the time of reservation. | [`book`](./app.py) | T-06 |
| FR-008 | The system shall allow a Student to cancel only their own Pending appointment. | [`cancel`](./app.py) | T-07 |
| FR-009 | The system shall provide a receipt and QR-coded verification URL for a Student's own appointment. | [`appointment_receipt`](./app.py) | T-08 |
| FR-010 | The system shall display limited appointment details for a valid verification token. | [`verify_appointment`](./app.py) | T-08 |
| FR-011 | The system shall allow Registrar Staff to view all appointments, assign/unassign active Teachers, and approve or reject Pending requests. | [`registrar_dashboard`](./app.py), [`assign_appointment`](./app.py) | T-09, T-14 |
| FR-012 | The system shall allow Admins to create, edit, assign roles, suspend/reactivate, and delete user accounts. | Admin user routes in [`app.py`](./app.py) | T-10 |
| FR-013 | The system shall allow Admins to update appointment statuses from the supported status set and require a reason when rejecting. | [`admin_update_appointment_status`](./app.py) | T-10 |
| FR-014 | The system shall allow Admins to export user or appointment data as CSV. | [`admin_export_csv`](./app.py) | T-11 |
| FR-015 | The system shall allow eligible roles to update profile details and upload an accepted profile photo. | [`profile`](./app.py) | T-12 |
| FR-016 | The system shall require a valid session CSRF token for POST requests. | [`protect_post_requests`](./app.py) | T-13 |
| FR-017 | The system shall allow Teachers to sign in, view only appointments assigned to them, and approve or reject their assigned Pending appointments; rejection requires a reason. | [`teacher_dashboard`](./app.py), teacher decision routes | T-03, T-15 |
| FR-018 | The system shall allow Teachers to configure weekly availability and future unavailable dates without invalidating existing future assignments. | Teacher availability routes and tables in [`app.py`](./app.py) | T-16 |
| FR-019 | The system shall record appointment creation, assignment changes, decisions, cancellation, and Admin status changes, and show recent events to Admins. | `appointment_events`, [`admin_dashboard`](./app.py) | T-17 |
| FR-020 | The system shall provide case-insensitive partial appointment search, filters, and whitelisted database sorting with pagination on Student, Teacher, Registrar Staff, and Admin dashboards. | Search/filter helpers and role-specific dashboard routes in [`app.py`](./app.py) | T-18 |
| FR-021 | The system shall constrain appointment query results by the current role and user before applying search, filters, sorting, or pagination. | `role_required`, Student `user_id` predicate, Teacher `assigned_teacher_id` predicate | T-18 |
| FR-022 | The system shall allow Registrar Staff and Admins to search/filter/sort available Student and staff account fields; it shall not imply unavailable course, year, department, employee-ID, or appointment-type data. | User directory queries and existing `users` schema | T-18 |

## 09 - Non-Functional Requirements and Assessment

| ID | Category | Evidence-based statement | Status / verification |
|---|---|---|---|
| NFR-001 | Security | Passwords are processed with Werkzeug password hash helpers; reset tokens are signed and time-limited. | Source evidence; security effectiveness not independently verified. |
| NFR-002 | Security | POST requests require a session CSRF token; protected routes use login/role checks. | Source evidence; runtime tests not performed. |
| NFR-003 | Security | The secret key falls back to a known development string if `SECRET_KEY` is absent; secure-cookie mode is conditional on `HTTPS_ENABLED`; direct startup enables debug mode. | Potential deployment risk; production settings not verified. |
| NFR-004 | Data integrity | User email is unique; non-empty mobile/student numbers are unique; non-null appointment references and verification tokens are unique; appointments reference users, and `assigned_teacher_id` is a nullable user reference. The application enforces that the assigned user has the Teacher role. | Legacy active schema was verified read-only before the new migration; new columns/tables and foreign keys were validated on a disposable migrated database. |
| NFR-005 | Data integrity | Appointment eligibility and status rules are primarily enforced in application logic; schema has no corresponding CHECK constraints for status/service/date/time. | Source/schema evidence; impact depends on non-app write paths. |
| NFR-006 | Usability | Pages use server-rendered forms and viewport metadata. Authenticated dashboards share responsive role-specific navigation, and Admin account forms adapt Student Number requirements to the selected role. The active registration form still requires email and omits the mobile input supported by backend logic. | Sidebar and Admin form interactions were checked in an isolated browser at desktop and mobile widths; broader usability and registration testing remain outstanding. |
| NFR-007 | Performance | Dashboard result rows use SQL pagination and relevant appointment/account filters have supporting indexes. Partial substring search uses leading-wildcard `LIKE`, and result counts still scan matching rows. No latency/throughput measurements or load tests were run. | Acceptable performance at larger volumes is unverified and requires representative benchmarking. |
| NFR-008 | Reliability/availability | No uptime target, service supervision, or recovery procedure was identified. | Not identified. |
| NFR-009 | Maintainability | Route handling, SQL, and business logic are concentrated in a large `app.py`. | Source observation; maintainability impact not measured. |
| NFR-010 | Compatibility | Local virtual environment reports Python 3.14.7; no supported Python, OS, or browser range is declared. | Observed local environment only. |
| NFR-011 | Scalability | No scaling architecture or load test identified; SQLite is used as a local database file. | Not verified. |
| NFR-012 | Privacy | Verification URL grants access to limited appointment details to anyone possessing the token; the receipt itself warns to keep the QR private. | Source evidence; link lifecycle/rotation behavior not tested. |

## 10 - Hardware Requirements

No minimum or recommended CPU, memory, disk, network, or peripheral specifications were established by source inspection or testing. Do not infer a production hardware baseline from the existence of a local Python environment.

A browser and network connection are implied for normal web access, but browser versions and connectivity requirements are not specified.

## 11 - Software Requirements

### Observed or source-indicated

- Python runtime to execute the application; current local environment reports Python 3.14.7.
- Flask and `qrcode[pil]`, as declared in [`requirements.txt`](./requirements.txt).
- Flask-associated/runtime packages used by source: Werkzeug, itsdangerous, and Pillow.
- SQLite support through Python's standard library.
- A web browser for the HTML interface.
- SMTP service and configuration for password-reset delivery.
- Filesystem access to the application directory, SQLite file, and profile-photo directory.

### Not identified or verified

- Supported operating systems and Python version range.
- Production WSGI server or deployment mode.
- Supported browser list.
- Required SMTP provider, TLS policy, and delivery service availability.
- Production storage/backup strategy for `school.db` and uploaded images.
- Hardware minimums.

## 12 - Database Documentation

### Inspection method and observed state

The active database `school.db` was opened read-only using SQLite URI `mode=ro`. The observed database contained two application tables: `users` (3 rows) and `appointments` (1 row). Record values were not inspected. `PRAGMA foreign_key_check` returned no issues.

`init_db()` in `app.py` creates tables/indexes, adds columns to existing databases, backfills missing appointment references/campus/verification tokens, and calls the admin-role migration. The latest additive migration adds `assigned_teacher_id` and `rejection_reason` to `appointments` and creates the Teacher availability, unavailable-date, and appointment-event tables. A module-level `init_db()` call runs when the application module is imported/executed. Therefore, importing or starting the application can mutate the configured database. The live workspace database has deliberately not been migrated; the new migration was tested against a disposable copy. **Back up `school.db` before running the updated application.**

### Data dictionary

| Table | Column | SQLite type | Null/default/constraints |
|---|---|---|---|
| `users` | `id` | INTEGER | Primary key, autoincrement |
| `users` | `name` | TEXT | NOT NULL |
| `users` | `email` | TEXT | NOT NULL, UNIQUE |
| `users` | `password_hash` | TEXT | NOT NULL |
| `users` | `role` | TEXT | NOT NULL; CHECK in Student, Teacher, Registrar Staff, Admin |
| `users` | `mobile` | TEXT | Nullable; unique partial index for non-null/non-empty values |
| `users` | `student_number` | TEXT | Nullable; unique partial index for non-null/non-empty values |
| `users` | `is_active` | INTEGER | NOT NULL, default 1 |
| `users` | `profile_image` | TEXT | Nullable |
| `appointments` | `id` | INTEGER | Primary key, autoincrement |
| `appointments` | `user_id` | INTEGER | NOT NULL; FK to `users.id`, ON UPDATE/DELETE NO ACTION |
| `appointments` | `service` | TEXT | NOT NULL |
| `appointments` | `appointment_date` | TEXT | NOT NULL |
| `appointments` | `appointment_time` | TEXT | NOT NULL |
| `appointments` | `reason` | TEXT | NOT NULL |
| `appointments` | `status` | TEXT | NOT NULL, default `Pending` |
| `appointments` | `reference_number` | TEXT | Nullable; unique partial index when non-null |
| `appointments` | `campus` | TEXT | Nullable |
| `appointments` | `verification_token` | TEXT | Nullable; unique partial index when non-null |
| `appointments` | `assigned_teacher_id` | INTEGER | Nullable; FK to `users.id`, ON DELETE SET NULL; legacy appointments remain unassigned |
| `appointments` | `rejection_reason` | TEXT | Nullable; populated when a request is rejected |
| `teacher_availability` | `id` | INTEGER | Primary key, autoincrement |
| `teacher_availability` | `teacher_id` | INTEGER | NOT NULL; FK to `users.id`, ON DELETE CASCADE |
| `teacher_availability` | `weekday` | INTEGER | NOT NULL; CHECK 0–5 (Monday–Saturday); unique per Teacher |
| `teacher_availability` | `start_time`, `end_time` | TEXT | NOT NULL; start must be earlier than end; app restricts to 30-minute increments between 08:00 and 17:00 |
| `teacher_unavailable_dates` | `id` | INTEGER | Primary key, autoincrement |
| `teacher_unavailable_dates` | `teacher_id` | INTEGER | NOT NULL; FK to `users.id`, ON DELETE CASCADE |
| `teacher_unavailable_dates` | `unavailable_date` | TEXT | NOT NULL; unique per Teacher |
| `teacher_unavailable_dates` | `note` | TEXT | Nullable; application limits notes to 200 characters |
| `appointment_events` | `id` | INTEGER | Primary key, autoincrement |
| `appointment_events` | `appointment_id` | INTEGER | NOT NULL; FK to `appointments.id`, ON DELETE CASCADE |
| `appointment_events` | `actor_user_id` | INTEGER | Nullable; FK to `users.id`, ON DELETE SET NULL |
| `appointment_events` | `event_type` | TEXT | NOT NULL |
| `appointment_events` | `previous_status`, `new_status` | TEXT | Nullable |
| `appointment_events` | `previous_assigned_teacher_id`, `new_assigned_teacher_id` | INTEGER | Nullable; Teacher identifiers at the time of the event |
| `appointment_events` | `note` | TEXT | Nullable; includes rejection reason when applicable |
| `appointment_events` | `created_at` | TEXT | NOT NULL, default `CURRENT_TIMESTAMP` |

### Indexes observed

- `users.email`: unique constraint/automatic SQLite index.
- `idx_users_mobile_unique`: unique partial index for non-null/non-empty mobile values.
- `idx_users_student_number_unique`: unique partial index for non-null/non-empty student numbers.
- `idx_appointments_reference_unique`: unique partial index for non-null references.
- `idx_appointments_verification_unique`: unique partial index for non-null verification tokens.
- `idx_appointments_assigned_teacher`: assigned Teacher/date/time lookup index.
- `idx_appointments_user_schedule`: Student appointment/date/time lookup index.
- `idx_appointments_status_schedule`: status/date/time filtering index.
- `idx_appointments_service_schedule`: category/date/time filtering index.
- `idx_users_role_name`: role/name account-directory index.
- `idx_appointment_events_appointment`: appointment/event-time lookup index.
- The new indexes are created additively by `init_db()`; the active legacy database was not migrated to inspect them.

### Entity relationship diagram

```mermaid
erDiagram
    USERS ||--o{ APPOINTMENTS : "books"
    USERS o|--o{ APPOINTMENTS : "is assigned"
    USERS ||--o{ TEACHER_AVAILABILITY : "sets"
    USERS ||--o{ TEACHER_UNAVAILABLE_DATES : "blocks"
    APPOINTMENTS ||--o{ APPOINTMENT_EVENTS : "records"
    USERS {
        INTEGER id PK
        TEXT name
        TEXT email UK
        TEXT password_hash
        TEXT role
        TEXT mobile UK
        TEXT student_number UK
        INTEGER is_active
        TEXT profile_image
    }
    APPOINTMENTS {
        INTEGER id PK
        INTEGER user_id FK
        TEXT service
        TEXT appointment_date
        TEXT appointment_time
        TEXT reason
        TEXT status
        TEXT reference_number UK
        TEXT campus
        TEXT verification_token UK
        INTEGER assigned_teacher_id FK
        TEXT rejection_reason
    }
    TEACHER_AVAILABILITY {
        INTEGER id PK
        INTEGER teacher_id FK
        INTEGER weekday
        TEXT start_time
        TEXT end_time
    }
    TEACHER_UNAVAILABLE_DATES {
        INTEGER id PK
        INTEGER teacher_id FK
        TEXT unavailable_date
        TEXT note
    }
    APPOINTMENT_EVENTS {
        INTEGER id PK
        INTEGER appointment_id FK
        INTEGER actor_user_id FK
        TEXT event_type
        TEXT previous_status
        TEXT new_status
        TEXT note
        TEXT created_at
    }
```

### Relationships and CRUD use

- One user may have zero or more appointment rows; each appointment references one user.
- User creation occurs through public registration and Admin account creation.
- User reads occur in login, role checks, profile views, dashboards, export, and appointment joins.
- User updates occur through profile editing and Admin management.
- User deletion is an Admin operation that explicitly deletes associated appointments first.
- Appointment creation occurs through Student booking.
- Appointment reads occur in availability lookup, dashboards, receipt, verification, and exports.
- Appointment updates occur through cancellation, Registrar assignment/decisions, assigned Teacher decisions, and Admin status management.
- Teacher availability and date blocks are managed by Teacher-scoped routes; appointment history is written by application routes and shown to Admins.
- No separate appointment deletion interface was identified.

The application uses parameterized values for database queries observed in the inspected routes. Not all domain constraints are represented in the database schema.

## 13 - System Testing Documentation

No project test files were identified at the project root. The following test plan was prepared from route and template behavior. Most cases remain Not Tested; focused assignment and record-search checks were run against disposable databases. No test used or modified the active workspace database.

| Test ID | Module/feature | Description, preconditions, steps, and test data | Expected result | Actual/status |
|---|---|---|---|---|
| T-01 | Registration | On a test copy, submit a valid Student name, student number, email, and password of at least 8 characters. | User is created; password is stored as a hash; login page is available. | Not run / Not Tested |
| T-02 | Registration validation | On a test copy, try duplicate email, duplicate mobile/student number, missing fields, malformed student number, and short password. | Invalid/duplicate input is rejected with feedback; no unintended account is created. | Not run / Not Tested |
| T-03 | Authentication and roles | Test valid/invalid credentials, inactive account, Student, Registrar Staff, Admin, and Teacher account. | Student and Admin reach their dashboards; Registrar Staff and Teacher reach separate role dashboards; invalid/inactive accounts are denied. | Teacher login redirect and Admin-route denial passed in isolated app/database; remaining cases Not Tested |
| T-04 | Password reset | With SMTP configured in a test environment, request reset for known/unknown email; test valid, expired, malformed token, mismatched confirmation, and short password. | Generic request message; valid unexpired token changes password; invalid cases do not. | Not run / Not Tested |
| T-05 | Availability | Test yesterday, Sunday, Saturday, same-day past/future slots, a booked slot, and a date with no appointments. | Past/Sunday dates return no slots; occupied and past same-day times are excluded. | Not run / Not Tested |
| T-06 | Booking | Submit valid appointment; then attempt malformed service/date/time, empty/long reason, past date/time, Sunday, and duplicate concurrent slot. | Valid request becomes Pending with identifiers; invalid/conflicting requests are rejected. | Not run / Not Tested |
| T-07 | Cancellation | Test own Pending, own Approved, and another user's Pending appointment. | Only own Pending appointment is set to Cancelled. | Not run / Not Tested |
| T-08 | Receipt/verification | Test Student receipt ownership and valid/invalid verification token; inspect fields returned by page. | Owner receives receipt/QR; valid token shows limited details; invalid token yields 404. | Not run / Not Tested |
| T-09 | Staff decisions | Registrar Staff approves/rejects a Pending appointment; test required rejection reason and retry after status changes. | Allowed decisions update the appointment; rejection requires a reason; repeat/non-authorized attempts do not. | Teacher rejection reason and event recording passed in isolated app/database; Admin and full Registrar regression not tested |
| T-10 | Admin management | Test account creation/edit, role/status updates, self-protection, last-active-Admin protection, and deletion using test records. | Valid actions succeed; invalid values and protected actions are rejected; deletion removes linked appointments as coded. | Admin create/edit role changes, Student Number requirement/preservation, and self-role protection passed in an isolated test; suspension, deletion, and last-active-Admin protection remain Not Tested |
| T-11 | CSV export | Export both datasets and include spreadsheet-formula-leading values in test data. | Correct CSV headers/data returned; leading formula characters are prefixed as coded. | Not run / Not Tested |
| T-12 | Profile/photo | Test valid JPEG/PNG/WebP under 3 MiB and 20M pixels, unsupported format, oversized file, duplicate contacts, and replacement. | Accepted image is normalized and saved; invalid input is rejected; old image cleanup occurs when applicable. | Teacher profile GET passed in isolated app/database; update and photo cases Not Tested |
| T-13 | CSRF/session | Submit POST with missing, invalid, and valid CSRF token; test logout/session clearing. | Invalid or absent token is rejected; valid requests reach route; logout clears session. | Valid-token login, approval, and account creation passed in isolated app/database; missing/invalid-token and logout cases Not Tested |
| T-14 | Schema migration and assignment | Migrate a disposable copy of a legacy database containing appointments; assign an active Teacher to a Pending appointment. | Existing appointment remains intact and unassigned until assigned; migration is additive; assignment succeeds only when eligible. | Passed on disposable legacy-schema database; workspace database was not changed |
| T-15 | Teacher access scope | Sign in as two Teachers; request dashboard and decision actions for assigned and unassigned appointments; try Registrar/Admin routes. | Each Teacher sees and acts only on own assigned requests; protected office-wide/Admin routes are denied. | Passed in isolated Flask test-client run |
| T-16 | Teacher availability | Save weekly hours, attempt invalid hours, try to block a date with an appointment, add a future block, and change hours to exclude an assignment. | Invalid/out-of-range availability and assignment-invalidating changes are refused; valid future blocks save. | Passed in isolated Flask test-client run |
| T-17 | Event history | Exercise booking, assignment, decision, cancellation, and Admin status update; render Admin history. | New actions create events; Admin history page renders recent event records; no events are backfilled for legacy records. | Representative assignment/rejection events and Admin render passed; all event types not individually tested |
| T-18 | Dashboard search, filters, sorting, and pagination | Seed a disposable database with multiple Students, Teachers, staff, statuses, categories, and dates. Test full/partial name and student-number searches, status/category/custom-date/personnel combinations, ascending/descending order, empty and special-character searches, invalid sort/date values, page links, account directories, and cross-role access. | Matching counts/data agree with database records; parameters are retained in pagination links; invalid sort inputs return 400; each role sees only authorized rows. | Passed isolated test-client checks for Student/Teacher/Registrar/Admin dashboards, student/staff directories, combined filters, date ranges, sorting direction, empty/special-character search, page state, invalid sort, and RBAC. |
| T-19 | Dashboard and Admin interface refinement | Render each role dashboard and profile; verify sidebar links, desktop collapse, mobile drawer and Escape close, dynamic Admin Student Number visibility/required state, filter clear/no-results behavior, destructive confirmation, and repeat-submit protection. | All four roles receive their own navigation and profile; linked sections exist; role-specific field validation changes correctly; confirmation can be cancelled; a POST submit button disables against repeated submission. | Passed isolated Flask/browser checks at desktop and mobile widths; confirmation was cancelled and the database create request was intercepted. |

### Validation performed during documentation

- Python syntax compilation succeeded for `app.py`, `create_admin.py`, and `migrate_registrar_role.py`.
- Read-only SQLite schema inspection completed; foreign-key check returned no errors.
- An isolated Flask test-client run validated migration over a legacy-schema database, Teacher assignment scoping, Registrar assignment and conflict checks, Teacher approval/reasoned rejection, weekly availability and date-block rules, audit-event recording, Student visibility of rejection reasons, and Admin event-history rendering.
- A separate isolated Flask test-client run seeded 35 appointments and seven accounts and verified dashboard rendering, Student name/number search and ownership, Teacher assignment scoping, Registrar/Admin appointment filters, custom date ranges, status/category/personnel combinations, ascending/descending sorting, result counts, no-result behavior, literal wildcard/special-character search, invalid sort rejection, and pagination query retention. Student/staff directory filters and Teacher schedule/assignment filters also rendered and responded as expected.
- A disposable app/database test rendered each of the four dashboards and shared profile page, then verified Admin account creation/editing, role transitions, Student Number retention, self-role protection, and filter reset visibility. Browser checks verified Student Number field visibility/required state, mobile drawer and Escape close, desktop collapse, section links, empty search results, Clear All behavior, delete confirmation, and double-submit disabling. The intercepted browser POST did not create an account.
- These tests used a disposable application copy and temporary SQLite database; the active workspace database was not used or migrated.
- The full project test suite, production startup, SMTP, uploads, CSV export, Admin status editing, and all event categories remain untested.

## 14 - Limitations and Gap Analysis

| ID | Classification | Finding and evidence | Potential impact | Recommended action |
|---|---|---|---|---|
| G-01 | **Resolved and verified in isolation** | Teacher login was previously blocked. Teacher now has a dedicated assigned-only dashboard, scoped approval/rejection actions, availability management, and profile access. Registrar Staff retains the office-wide view and assignment workflow. | Core scoped workflow passed isolated integration tests; profile update/upload and deployment behavior remain unverified. | Keep role/assignment boundaries in regression tests; separately test profile updates and photo handling. |
| G-02 | **Confirmed issue** | Backend registration accepts mobile-only identity and has mobile validation, but active `index.html` requires an email and contains no mobile input. | Backend-supported registration option is unavailable in active UI; presented behavior and server capability differ. | Decide whether mobile-only registration is intended and align UI and validation. |
| G-03 | **Potential issue** | Fallback `SECRET_KEY` is a development string, direct execution enables debug mode, and secure-cookie mode depends on `HTTPS_ENABLED`. | If deployed without production overrides, session/signing confidentiality and debug exposure may be inadequate. Actual deployment unknown. | Verify production startup, secret provisioning, HTTPS, and cookie configuration before deployment. |
| G-04 | **Potential issue** | Slot/appointment queries filter by date and time but no corresponding scheduling index was observed. | Query latency may grow with appointment volume. No benchmark or scale claim is made. | Measure with representative data before deciding on schema/index changes. |
| G-05 | **Potential issue** | Appointment status, allowed service, date/time validity, and scheduling constraints are not all database CHECK constraints. | Direct database imports or maintenance writes could bypass route-level validation. | Identify non-application write paths and determine whether DB constraints are warranted. |
| G-06 | **Requires further testing** | Most application request flows, SMTP delivery, image handling, concurrent booking, CSV exports, Admin status updates, and the complete action/permission matrix were not executed. Representative dashboard rendering, Admin role edits, and assignment/Teacher scoping/availability/audit flows were tested in isolation. | Focused tests do not establish all runtime outcomes or deployment behavior. | Run the remaining test plan against a disposable database and controlled SMTP/test environment. |
| G-07 | **Requires further investigation** | No deployment procedure, backup/restore runbook, supported browser/OS matrix, or hardware baseline was identified. | Operational requirements and recovery expectations remain unclear. | Document and verify those operational requirements with the system owner. |
| G-08 | **Requires further investigation** | `static/script.js` contains a local-storage account/appointment implementation but is not referenced by inspected active templates. | It may be obsolete/demo code or intended functionality not wired into active pages. | Confirm its intended status before treating it as a product feature or removing it. |
| G-09 | **Known limitation** | Teacher availability is one shared start/end window per selected weekday, Monday–Saturday; assignments are 30 minutes. It does not support multiple daily windows, holidays/repeating exceptions beyond date blocks, or per-service qualifications. | Scheduling rules may be too coarse for some office or teacher schedules. | Gather scheduling requirements before expanding the availability model. |
| G-10 | **Known limitation** | Appointment events start accumulating after the migration; existing appointments are not backfilled. Availability edits are not part of the appointment event history, and Admin history is limited to the newest 100 events. | Historical actions before rollout and availability changes cannot be reconstructed from the log. | Retain this boundary in operational documentation and decide whether availability auditing or pagination is needed. |
| G-11 | **Data-model limitation** | The current schema has no course/program, year level, department, employee/staff ID, appointment type, Completed, or Missed status fields. Search and filters therefore use only stored fields; appointment statuses currently supported are Pending, Approved, Rejected, and Cancelled. | Requests for filters based on those absent fields cannot be fulfilled accurately without schema/product changes. | Add these concepts only after confirming requirements and defining account/data migration behavior. |

### Features not identified

No source evidence was identified for automated reminders, appointment rescheduling, appointment reporting beyond CSV export, user self-service Teacher registration, or a production deployment configuration. Appointment event history is implemented, but it does not backfill pre-migration actions or record availability edits. These should be treated as **not identified**, not as features that are known to be required or intentionally excluded.

## 15 - Recommendations

These are proposed actions, not descriptions of existing capability:

1. Add automated regression tests for Teacher login, staff dashboard, appointment approval, profile access, and denial of Admin-only routes.
2. Resolve the registration mismatch by deciding whether mobile-only accounts are a supported public workflow.
3. Before deployment, require an externally configured secret, disable debug mode, enforce HTTPS, and verify secure session-cookie settings.
4. Establish a safe test setup using a disposable copy of the database; avoid importing/starting the application against production data until startup migrations are understood.
5. Add automated tests for role access, booking boundaries/concurrency, CSRF, password reset, admin last-account safeguards, CSV exports, and profile uploads.
6. Document database backup/restore and uploaded-photo recovery procedures.
7. Benchmark appointment lookup/booking with representative data before making performance or scaling claims.
8. Identify whether the local-storage JavaScript and backup templates are retained examples or active project artifacts.
9. Pin and declare direct runtime dependencies and state the tested Python/runtime support range.

## 16 - Glossary

| Term | Meaning in this system |
|---|---|
| CSRF | Cross-site request forgery. POST requests are checked for a session-associated token. |
| Foreign key | Database constraint linking a row to another table; `appointments.user_id` references `users.id`. |
| Jinja | Template engine used with Flask to render HTML from server-side data. |
| Role-based access control | Restricting protected routes according to the authenticated user's role. |
| SQLite | Embedded relational database stored in a file. |
| Signed reset token | Tamper-evident token used to authorize a time-limited password-reset flow. |
| Verification token | Random appointment-associated token used in a public verification URL and QR code. |
| WSGI | Python web-server interface; a production WSGI deployment was not identified in this workspace. |

## Traceability Summary

| Feature | Requirement | Implementation evidence | Test | Result |
|---|---|---|---|---|
| F-01 Registration | FR-001 | [`register`](./app.py) | T-01, T-02 | Not Tested |
| F-02 Authentication | FR-002, FR-017 (Teacher access) | [`login`](./app.py), [`role_required`](./app.py) | T-03 | Teacher login and Admin-route denial passed in isolation |
| F-03 Reset | FR-003 | [`forgot_password`](./app.py), [`reset_password`](./app.py) | T-04 | Not Tested |
| F-05/F-06 Slots and booking | FR-005–FR-007 | [`available_slots`](./app.py), [`book`](./app.py) | T-05, T-06 | Not Tested |
| F-07 Cancellation | FR-008 | [`cancel`](./app.py) | T-07 | Not Tested |
| F-08 Receipt/verification | FR-009, FR-010 | [`appointment_receipt`](./app.py), [`verify_appointment`](./app.py) | T-08 | Not Tested |
| F-09 Registrar assignment/decisions | FR-011 | [`registrar_dashboard`](./app.py), assignment and decision routes | T-09, T-14 | Teacher and Registrar Staff assignments passed in isolation; full regression not tested |
| F-19 Teacher/staff dashboard and availability | FR-017, FR-018 | [`teacher_dashboard`](./app.py), personnel availability routes | T-15, T-16 | Teacher scope, both assignment roles, and invalid Registrar availability input passed in isolation |
| F-20 Event history | FR-019 | `appointment_events`, [`admin_dashboard`](./app.py) | T-17 | Representative event write and Admin render passed |
| F-21 Search/filter/sort/pagination | FR-020, FR-021 | Dashboard query helpers and routes in [`app.py`](./app.py) | T-18 | Passed isolated test-client checks |
| F-22 Dashboard navigation/Admin UX | UI refinement request | [`_dashboard_sidebar.html`](./templates/_dashboard_sidebar.html), [`admin_dashboard.html`](./templates/admin_dashboard.html) | T-19 | Passed isolated browser and test-client checks |
| Student/staff directories | FR-022 | Registrar/Admin directory SQL and templates | T-18 | Passed isolated test-client checks using available account fields |
| F-10/F-11 Admin management | FR-012, FR-013 | Admin routes in [`app.py`](./app.py) | T-10 | Create/edit roles and self-role protection passed in isolation; remaining actions not tested |
| F-12 CSV export | FR-014 | [`admin_export_csv`](./app.py) | T-11 | Not Tested |
| F-13 Profile and approval | FR-015, new identity-review requirements | [`profile`](./app.py), `review_profile_change` | T-12, latest isolated validation | Dual approval, email verification, cooldown, and override passed in isolation; photo uploads/live SMTP not tested |
| F-14 CSRF/logout | FR-016 | [`protect_post_requests`](./app.py), [`logout`](./app.py) | T-13 | Not Tested |

## 17 - Implementation Addendum: Personnel and Profile Workflows

This addendum records the latest implementation and supersedes older statements above that describe profile editing as an immediate update or assignment as Teacher-only.

### Personnel assignment and availability

- Registrar Staff can assign a pending appointment to an active Teacher or Registrar Staff account. The selected account must have an availability window for the appointment's weekday/time, no unavailable-date block, and no conflicting active assignment.
- `assigned_personnel_id`, `assigned_personnel_role`, and `assignment_status` are the generic assignment fields. The legacy `assigned_teacher_id` remains for compatibility and is populated only for Teacher assignments.
- Legacy Teacher assignment, availability, and unavailable-date data are copied into generic personnel fields/tables during initialization. Registrar Staff manage their own weekly schedule and unavailable dates from their dashboard.
- Teacher approval/rejection remains restricted to appointments assigned to that Teacher. Registrar Staff continue to manage office-wide records. Assignment changes and assignment notifications are recorded.
- Admin role changes are blocked while an account has non-cancelled assigned appointments; staff schedule records are moved or removed consistently when a role changes. Deleting assigned personnel clears those assignments and records the transition before deleting the account.

### Structured names and profile approval

- New registration and Admin-created accounts capture first name, optional middle initial, and last name. Display names use `Last, First MiddleInitial`.
- Existing full names are preserved as stored; migration does not guess how a legacy name should be divided. A user can submit structured name parts for review.
- Mobile number and profile photo remain direct profile updates. Name, email, and Student number changes are requests; the proposed sensitive values are not applied until both an independent Registrar Staff reviewer and an Administrator approve.
- A changed email address must be verified through a random, hashed, 24-hour token before it enters the review queue. Failed mail delivery is logged and marked so the user can retry.
- The requester cannot review their own request. The Administrator must be a different account from the Registrar reviewer. Requests can be withdrawn while pending.
- Approval starts a 30-day cooldown for each changed field group. If an active cooldown blocks approval, an Administrator must provide a 10–500 character reason to override it. The override is stored on the request and in the account audit log.
- Course/program, year level, department, employee ID, and other fields not present in the database remain unavailable rather than being inferred.

### Passwords, notifications, and audit records

- Signed password-reset tokens include the account authentication version; a successful reset increments the version and invalidates outstanding reset tokens and sessions.
- An authenticated password-change form verifies the current password, enforces an eight-character minimum, records the change, increments the authentication version, and signs the user out.
- In-app notifications are associated with one user and can only be marked read by that user.
- `account_events` records profile request/review/withdrawal, verification, mobile and access changes, password changes/resets, account lifecycle changes, and cooldown override rationale. Password material is never included in the audit event.

### Additive schema

Initialization adds the structured-name and authentication-version columns to `users`; generic personnel assignment fields to `appointments` and `appointment_events`; generic availability tables; and `profile_change_requests`, `profile_change_cooldowns`, `notifications`, and `account_events`. Existing legacy name values are not split or discarded. Normal application startup will run these migrations; the active `school.db` was not imported or changed during this implementation's tests.

### Latest isolated validation

The final Flask test-client run used a temporary copy of `app.py` and a disposable SQLite database with synthetic accounts. It verified:

| Scenario | Result |
|---|---|
| Initialize a copy of the workspace database and preserve existing names/appointment count | Passed; source database remained unchanged |
| Create a Student through public registration and a Registrar Staff account through Admin | Passed with structured names |
| Render Registrar, Teacher, Admin, and profile pages | Passed |
| Assign appointments to a Teacher and to Registrar Staff | Passed |
| Reject an invalid sorting key | Passed (HTTP 400) |
| Reject malformed Registrar availability time without misrouting the user | Passed |
| Block role change while appointments are assigned; safely unassign on deletion | Passed |
| Keep requested identity values unchanged until both reviews approve | Passed |
| Block approval during an active cooldown, then allow an audited Administrator override | Passed |
| Send/verify an email change using a mocked mail sender | Passed; live SMTP not tested |
| Change password and invalidate the existing session | Passed |

These checks do not replace testing against the exact deployed production schema, real SMTP configuration, image uploads, concurrent requests, or the full application regression matrix. Do not run `init_db()` against production data as a test.

## 18 - Notification Center and Safer Appointment Actions

The notification experience now extends the existing SQLite-backed notification table rather than introducing a separate delivery system.

- Initialization adds `category`, `title`, `related_type`, `related_id`, and optional unique `dedupe_key` fields. Existing notification rows are retained and receive the migration defaults (`system` / `System update`).
- Authenticated Student, Teacher, Registrar Staff, and Admin pages share a header notification menu with an unread count and recent unread previews. The full notification center supports category/status filters, pagination, read/unread toggles, and mark-all-as-read.
- Notification queries and mutations are constrained to the signed-in user's `user_id`. CSRF protection applies to all read-state actions; guessed IDs belonging to another user are not exposed.
- Notifications accompany successful appointment booking, assignment/reassignment/unassignment, status decisions, and student cancellation; account creation/access/status changes; profile requests, verification, and review outcomes; and password change/reset events. Notices are inserted with the related database operation where possible; email-verification notices are created only after successful mail delivery.
- Notification messages do not include passwords, reset tokens, or proposed sensitive profile values. The center only renders internal application links. It refreshes through normal page requests; no push/polling service or dependency was added.
- Registrar assignment controls show assign, reassign, or cancel-assignment intent and require confirmation. Appointment rejection forms require a trimmed reason and a separate confirmation; POST forms prevent accidental duplicate submissions and show a busy state. Profile password controls have clearer visual separation and spacing.
- The database currently supports Pending, Approved, Rejected, and Cancelled appointments. Completed/Missed status and rescheduling are not implemented and were not added as part of this change.

### Isolated notification validation

Validation used a temporary copy of the application and a disposable SQLite database with a legacy-format notification table; the active `school.db` was not used as a test target.

| Scenario | Result |
|---|---|
| Add notification columns while preserving an existing legacy row | Passed; the old row retained its message and received the `system` / `System update` defaults |
| Book an appointment and notify the Student and active Registrar Staff | Passed |
| Assign to a Teacher and approve as the assigned Teacher | Passed; expected recipient records were created |
| Render Student, Teacher, Registrar Staff, Admin dashboards, and notification centers | Passed |
| Filter the notification center by unread status and category | Passed |
| Mark all read and toggle an individual notification back to unread | Passed |
| Attempt to change another user's notification read state | Passed; returned 404 and the owner's record remained unread |
| Repeat a notification write with the same idempotency key | Passed; only one row was created |
| Exclude the action actor and affected account from role-wide Admin alerts | Passed; only unrelated active Admin recipients received the alert |
| Access the notification center without authentication | Passed; redirected to sign-in |

This focused run did not perform a browser viewport/accessibility audit, live email delivery, load testing, or full application regression suite.
