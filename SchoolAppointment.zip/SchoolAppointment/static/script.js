
const loginSection = document.getElementById("loginSection");
const registerSection = document.getElementById("registerSection");
const appSection = document.getElementById("appSection");

const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const appointmentForm = document.getElementById("appointmentForm");

function getAccounts() {
    return JSON.parse(localStorage.getItem("schoolAccounts") || "[]");
}

function getAppointments() {
    return JSON.parse(localStorage.getItem("schoolAppointments") || "[]");
}

// Show the login page
function showLogin() {
    loginSection.classList.remove("hidden");
    registerSection.classList.add("hidden");
    appSection.classList.add("hidden");
}

// Show the registration page
function showRegister() {
    loginSection.classList.add("hidden");
    registerSection.classList.remove("hidden");
    appSection.classList.add("hidden");
}

// Show the dashboard
function showApp(account) {
    loginSection.classList.add("hidden");
    registerSection.classList.add("hidden");
    appSection.classList.remove("hidden");

    document.getElementById("welcomeMessage").textContent =
        "Welcome, " + account.name + "! Account type: " + account.role;

    document.getElementById("appointmentDate").min = getToday();

    displayAppointments();
}

// Get today's date in YYYY-MM-DD format
function getToday() {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");

    return year + "-" + month + "-" + day;
}

// Switch between login and registration
document.getElementById("showRegister").addEventListener("click", function(event) {
    event.preventDefault();
    showRegister();
});

document.getElementById("showLogin").addEventListener("click", function(event) {
    event.preventDefault();
    showLogin();
});

// Register an account
registerForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const name = document.getElementById("registerName").value.trim();
    const email = document.getElementById("registerEmail").value.trim().toLowerCase();
    const password = document.getElementById("registerPassword").value;
    const role = document.getElementById("registerRole").value;
    const message = document.getElementById("registerMessage");

    message.textContent = "";

    if (!name || !email || !password || !role) {
        message.textContent = "Please complete all fields.";
        return;
    }

    const accounts = getAccounts();

    if (accounts.some(account => account.email === email)) {
        message.textContent = "This email is already registered.";
        return;
    }

    accounts.push({
        name: name,
        email: email,
        password: password,
        role: role
    });

    localStorage.setItem("schoolAccounts", JSON.stringify(accounts));

    registerForm.reset();
    message.textContent = "Registration successful! You can now log in.";

    // Return to the login page after successful registration
    setTimeout(function() {
        message.textContent = "";
        showLogin();

        document.getElementById("loginEmail").value = email;
        document.getElementById("loginPassword").focus();
    }, 1200);
});

// Log in
loginForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const email = document.getElementById("loginEmail").value.trim().toLowerCase();
    const password = document.getElementById("loginPassword").value;
    const message = document.getElementById("loginMessage");

    const account = getAccounts().find(function(item) {
        return item.email === email && item.password === password;
    });

    if (!account) {
        message.textContent = "Incorrect email or password. Please try again.";
        return;
    }

    sessionStorage.setItem("schoolCurrentUser", account.email);

    message.textContent = "";
    loginForm.reset();

    showApp(account);
});

// Log out
document.getElementById("logoutButton").addEventListener("click", function() {
    sessionStorage.removeItem("schoolCurrentUser");
    showLogin();
});

// Submit an appointment
appointmentForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const email = sessionStorage.getItem("schoolCurrentUser");
    const account = getAccounts().find(function(item) {
        return item.email === email;
    });

    if (!account) {
        showLogin();
        return;
    }

    const date = document.getElementById("appointmentDate").value;
    const time = document.getElementById("appointmentTime").value;
    const message = document.getElementById("appointmentMessage");

    if (date < getToday()) {
        message.textContent = "Please choose today or a future date.";
        return;
    }

    const appointments = getAppointments();

    appointments.push({
        id: Date.now(),
        email: account.email,
        name: account.name,
        service: document.getElementById("service").value,
        date: date,
        time: time,
        reason: document.getElementById("appointmentReason").value.trim(),
        status: "Pending"
    });

    localStorage.setItem("schoolAppointments", JSON.stringify(appointments));

    message.textContent = "Appointment submitted successfully!";

    appointmentForm.reset();
    document.getElementById("appointmentDate").min = getToday();

    displayAppointments();
});

// Display appointments for the logged-in user
function displayAppointments() {
    const email = sessionStorage.getItem("schoolCurrentUser");
    const list = document.getElementById("appointmentList");

    const appointments = getAppointments().filter(function(appointment) {
        return appointment.email === email;
    });

    list.innerHTML = "";

    if (appointments.length === 0) {
        list.textContent = "You have no appointments yet.";
        return;
    }

    appointments.forEach(function(appointment) {
        const item = document.createElement("div");
        item.className = "appointmentItem";

        const title = document.createElement("h3");
        title.textContent = appointment.service;

        const details = document.createElement("p");
        details.textContent =
            "Date: " + appointment.date +
            " | Time: " + appointment.time +
            " | Status: " + appointment.status;

        const reason = document.createElement("p");
        reason.textContent = "Reason: " + appointment.reason;

        item.appendChild(title);
        item.appendChild(details);
        item.appendChild(reason);

        if (appointment.status === "Pending") {
            const cancelButton = document.createElement("button");
            cancelButton.textContent = "Cancel Appointment";
            cancelButton.type = "button";
            cancelButton.className = "cancelButton";

            cancelButton.addEventListener("click", function() {
                const updatedAppointments = getAppointments().map(function(entry) {
                    if (entry.id === appointment.id && entry.email === email) {
                        return {
                            ...entry,
                            status: "Cancelled"
                        };
                    }

                    return entry;
                });

                localStorage.setItem(
                    "schoolAppointments",
                    JSON.stringify(updatedAppointments)
                );

                displayAppointments();
            });

            item.appendChild(cancelButton);
        }

        list.appendChild(item);
    });
}

// Open the appropriate page when the website loads
const savedEmail = sessionStorage.getItem("schoolCurrentUser");

const savedAccount = getAccounts().find(function(account) {
    return account.email === savedEmail;
});

if (savedAccount) {
    showApp(savedAccount);
} else {
    showLogin();
}
