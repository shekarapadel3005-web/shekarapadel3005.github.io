import os
import secrets
import sqlite3
import smtplib
import shutil
import csv
import base64
import hashlib
import io
import json
import qrcode
import re
from PIL import Image, UnidentifiedImageError
from email.message import EmailMessage
from datetime import date, datetime, time, timedelta, timezone
from functools import wraps

from flask import (
    Flask,
    render_template,
    request,
    redirect,
    url_for,
    session,
    flash,
    abort,
    jsonify,
    Response
)
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

app = Flask(__name__)

# Use a strong secret key from an environment variable in production.
app.config["SECRET_KEY"] = os.environ.get(
    "SECRET_KEY", "local-development-key-change-before-deployment"
)

app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = (
    os.environ.get("HTTPS_ENABLED") == "1"
)

DATABASE = os.path.join(os.path.dirname(__file__), "school.db")
PROFILE_PHOTO_FOLDER = os.path.join(os.path.dirname(__file__), "static", "profile_photos")
MAX_PROFILE_PHOTO_BYTES = 3 * 1024 * 1024
app.config["MAX_CONTENT_LENGTH"] = MAX_PROFILE_PHOTO_BYTES + 1024 * 1024

SERVICES = [
    "Document Request",
    "Consultation",
    "Other"
]
APPOINTMENT_STATUSES = ("Pending", "Approved", "Rejected", "Cancelled")
PAGE_SIZE = 20
PROFILE_CHANGE_GROUPS = {
    "name": ("last_name", "first_name", "middle_initial"),
    "email": ("email",),
    "student_number": ("student_number",),
}

APPOINTMENT_SORTS = {
    "date_asc": "a.appointment_date ASC, a.appointment_time ASC, a.id ASC",
    "date_desc": "a.appointment_date DESC, a.appointment_time DESC, a.id DESC",
    "id_asc": "a.id ASC",
    "id_desc": "a.id DESC",
    "student_asc": "COALESCE(NULLIF(u.last_name, ''), u.name) COLLATE NOCASE ASC, COALESCE(u.first_name, '') COLLATE NOCASE ASC, a.appointment_date ASC, a.id ASC",
    "student_desc": "COALESCE(NULLIF(u.last_name, ''), u.name) COLLATE NOCASE DESC, COALESCE(u.first_name, '') COLLATE NOCASE DESC, a.appointment_date DESC, a.id DESC",
    "time_asc": "a.appointment_time ASC, a.appointment_date ASC, a.id ASC",
    "time_desc": "a.appointment_time DESC, a.appointment_date DESC, a.id DESC",
    "status": "a.status COLLATE NOCASE ASC, a.appointment_date ASC, a.id ASC",
    "category_asc": "a.service COLLATE NOCASE ASC, a.appointment_date ASC, a.id ASC",
    "category_desc": "a.service COLLATE NOCASE DESC, a.appointment_date DESC, a.id DESC",
    "personnel_asc": "COALESCE(p.last_name, p.name, '') COLLATE NOCASE ASC, COALESCE(p.first_name, '') COLLATE NOCASE ASC, a.appointment_date ASC, a.id ASC",
    "personnel_desc": "COALESCE(p.last_name, p.name, '') COLLATE NOCASE DESC, COALESCE(p.first_name, '') COLLATE NOCASE DESC, a.appointment_date DESC, a.id DESC",
}

USER_SORTS = {
    "name_asc": "COALESCE(NULLIF(u.last_name, ''), u.name) COLLATE NOCASE ASC, COALESCE(u.first_name, '') COLLATE NOCASE ASC, u.id ASC",
    "name_desc": "COALESCE(NULLIF(u.last_name, ''), u.name) COLLATE NOCASE DESC, COALESCE(u.first_name, '') COLLATE NOCASE DESC, u.id DESC",
    "student_number_asc": "u.student_number COLLATE NOCASE ASC, COALESCE(NULLIF(u.last_name, ''), u.name) COLLATE NOCASE ASC",
    "student_number_desc": "u.student_number COLLATE NOCASE DESC, COALESCE(NULLIF(u.last_name, ''), u.name) COLLATE NOCASE ASC",
    "role_asc": "u.role COLLATE NOCASE ASC, COALESCE(NULLIF(u.last_name, ''), u.name) COLLATE NOCASE ASC",
    "assigned_desc": "assigned_appointments DESC, COALESCE(NULLIF(u.last_name, ''), u.name) COLLATE NOCASE ASC",
    "assigned_asc": "assigned_appointments ASC, COALESCE(NULLIF(u.last_name, ''), u.name) COLLATE NOCASE ASC",
}


# Signed password-reset links expire after 30 minutes.
reset_serializer = URLSafeTimedSerializer(app.config["SECRET_KEY"])


def _escape_like(value):
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _format_full_name(last_name, first_name, middle_initial="", legacy_name=""):
    last_name = (last_name or "").strip()
    first_name = (first_name or "").strip()
    middle_initial = (middle_initial or "").strip()
    if not last_name or not first_name:
        return (legacy_name or "").strip()
    middle = f" {middle_initial}" if middle_initial else ""
    return f"{last_name}, {first_name}{middle}"


def _full_name_sql(alias="u"):
    return (
        f"CASE WHEN COALESCE({alias}.last_name, '') != '' "
        f"AND COALESCE({alias}.first_name, '') != '' "
        f"THEN {alias}.last_name || ', ' || {alias}.first_name || "
        f"CASE WHEN COALESCE({alias}.middle_initial, '') != '' "
        f"THEN ' ' || {alias}.middle_initial ELSE '' END "
        f"ELSE {alias}.name END"
    )


def _normalized_name_parts(form):
    last_name = " ".join(form.get("last_name", "").split())
    first_name = " ".join(form.get("first_name", "").split())
    middle_initial = " ".join(form.get("middle_initial", "").split())
    if not last_name or not first_name:
        return None
    if len(last_name) > 100 or len(first_name) > 100 or len(middle_initial) > 10:
        return None
    return last_name, first_name, middle_initial


def _utc_now():
    return datetime.now(timezone.utc).replace(microsecond=0)


def _send_email(recipient, subject, body):
    host = os.environ.get("MAIL_SERVER", "")
    port = int(os.environ.get("MAIL_PORT", "587"))
    username = os.environ.get("MAIL_USERNAME", "")
    password = os.environ.get("MAIL_PASSWORD", "")
    sender = os.environ.get("MAIL_SENDER", username)
    if not all([host, username, password, sender]):
        raise RuntimeError("Email settings are not configured.")
    message = EmailMessage()
    message["Subject"] = subject
    message["From"] = sender
    message["To"] = recipient
    message.set_content(body)
    with smtplib.SMTP(host, port, timeout=20) as smtp:
        smtp.starttls()
        smtp.login(username, password)
        smtp.send_message(message)


def _create_notification(
    db,
    user_id,
    message,
    link=None,
    *,
    category="system",
    title="System update",
    related_type=None,
    related_id=None,
    dedupe_key=None,
):
    return db.execute("""
        INSERT INTO notifications (
            user_id, category, title, message, link,
            related_type, related_id, dedupe_key
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(dedupe_key) WHERE dedupe_key IS NOT NULL DO NOTHING
    """, (
        user_id, category, title, message, link,
        related_type, related_id, dedupe_key,
    )).rowcount


def _notify_role(
    db,
    role,
    message,
    link,
    *,
    category="system",
    title="System update",
    related_type=None,
    related_id=None,
    dedupe_key=None,
    exclude_user_id=None,
    exclude_user_ids=(),
):
    query = "SELECT id FROM users WHERE role = ? AND is_active = 1"
    parameters = [role]
    excluded_user_ids = set(exclude_user_ids)
    if exclude_user_id is not None:
        excluded_user_ids.add(exclude_user_id)
    if excluded_user_ids:
        placeholders = ", ".join("?" for _ in excluded_user_ids)
        query += f" AND id NOT IN ({placeholders})"
        parameters.extend(sorted(excluded_user_ids))
    users = db.execute(
        query,
        parameters,
    ).fetchall()
    for user in users:
        _create_notification(
            db, user["id"], message, link,
            category=category, title=title,
            related_type=related_type, related_id=related_id,
            dedupe_key=(
                f"{dedupe_key}:user:{user['id']}" if dedupe_key else None
            ),
        )


def _profile_request_for_template(row):
    request_view = dict(row)
    request_view["previous"] = json.loads(row["previous_values"])
    request_view["proposed"] = json.loads(row["proposed_values"])
    return request_view


def _log_account_event(
    db,
    actor_user_id,
    affected_user_id,
    event_type,
    previous_values=None,
    new_values=None,
    reason=None,
):
    db.execute("""
        INSERT INTO account_events (
            actor_user_id, affected_user_id, event_type,
            previous_values, new_values, reason
        )
        VALUES (?, ?, ?, ?, ?, ?)
    """, (
        actor_user_id,
        affected_user_id,
        event_type,
        json.dumps(previous_values, ensure_ascii=False, sort_keys=True)
        if previous_values is not None else None,
        json.dumps(new_values, ensure_ascii=False, sort_keys=True)
        if new_values is not None else None,
        reason,
    ))


def _active_cooldown(db, user_id, group_name, now=None):
    now = now or _utc_now()
    row = db.execute("""
        SELECT available_after
        FROM profile_change_cooldowns
        WHERE user_id = ? AND field_group = ?
    """, (user_id, group_name)).fetchone()
    if not row:
        return None
    available_after = datetime.fromisoformat(row["available_after"])
    if available_after.tzinfo is None:
        available_after = available_after.replace(tzinfo=timezone.utc)
    return available_after if available_after > now else None


def _append_search(conditions, params, query, columns, key="q"):
    query = query.strip()
    if not query:
        return ""
    if len(query) > 120:
        abort(400)
    pattern = f"%{_escape_like(query)}%"
    conditions.append(
        "(" + " OR ".join(
            f"LOWER(CAST({column} AS TEXT)) LIKE LOWER(:{key}) ESCAPE '\\'"
            for column in columns
        ) + ")"
    )
    params[key] = pattern
    return query


def _appointment_filters(
    args,
    search_columns,
    services,
    allow_personnel=False,
    sort_options=None,
):
    sort_options = sort_options or APPOINTMENT_SORTS
    conditions = []
    params = {}
    filters = {
        "q": _append_search(
            conditions,
            params,
            args.get("q", ""),
            search_columns,
        ),
        "status": args.get("status", "").strip(),
        "service": args.get("service", "").strip(),
        "date_range": args.get("date_range", "").strip(),
        "date_from": args.get("date_from", "").strip(),
        "date_to": args.get("date_to", "").strip(),
        "personnel": args.get("personnel", "").strip() if allow_personnel else "",
        "sort": args.get("sort", "date_asc").strip(),
    }

    if filters["status"]:
        if filters["status"] not in APPOINTMENT_STATUSES:
            abort(400)
        conditions.append("a.status = :status")
        params["status"] = filters["status"]

    if filters["service"]:
        if filters["service"] not in services:
            abort(400)
        conditions.append("a.service = :service")
        params["service"] = filters["service"]

    date_range = filters["date_range"]
    if date_range not in {"", "today", "tomorrow", "this_week", "this_month", "custom"}:
        abort(400)
    date_start = None
    date_end = None
    today = date.today()
    if date_range == "today":
        date_start = date_end = today.isoformat()
    elif date_range == "tomorrow":
        date_start = date_end = (today + timedelta(days=1)).isoformat()
    elif date_range == "this_week":
        monday = today - timedelta(days=today.weekday())
        date_start = monday.isoformat()
        date_end = (monday + timedelta(days=6)).isoformat()
    elif date_range == "this_month":
        first = today.replace(day=1)
        next_month = first.replace(
            year=first.year + (1 if first.month == 12 else 0),
            month=1 if first.month == 12 else first.month + 1,
        )
        date_start = first.isoformat()
        date_end = (next_month - timedelta(days=1)).isoformat()
    elif date_range == "custom":
        try:
            date_start = date.fromisoformat(filters["date_from"]).isoformat()
            date_end = date.fromisoformat(filters["date_to"]).isoformat()
        except ValueError:
            abort(400)
        if date_start > date_end:
            abort(400)

    if date_start:
        conditions.append("a.appointment_date >= :date_start")
        params["date_start"] = date_start
        conditions.append("a.appointment_date <= :date_end")
        params["date_end"] = date_end

    if filters["personnel"]:
        if not allow_personnel:
            abort(400)
        if filters["personnel"] == "unassigned":
            conditions.append("a.assigned_personnel_id IS NULL")
        else:
            try:
                personnel_id = int(filters["personnel"])
            except ValueError:
                abort(400)
            if personnel_id < 1:
                abort(400)
            conditions.append("a.assigned_personnel_id = :personnel_id")
            params["personnel_id"] = personnel_id

    if filters["sort"] not in sort_options:
        abort(400)
    return conditions, params, filters, sort_options[filters["sort"]]


def _user_filters(args, search_columns, sort_options, prefix, roles=None):
    conditions = []
    params = {}
    search_key = f"{prefix}_q"
    filters = {
        "q": _append_search(
            conditions,
            params,
            args.get(search_key, ""),
            search_columns,
            key=search_key,
        ),
        "status": args.get(f"{prefix}_status", "").strip(),
        "role": args.get(f"{prefix}_role", "").strip(),
        "availability": args.get(f"{prefix}_availability", "").strip(),
        "assignment": args.get(f"{prefix}_assignment", "").strip(),
        "activity": args.get(f"{prefix}_activity", "").strip(),
        "sort": args.get(f"{prefix}_sort", "name_asc").strip(),
    }

    if roles:
        role_keys = [f"{prefix}_allowed_role_{index}" for index in range(len(roles))]
        conditions.append(
            "u.role IN (" + ", ".join(f":{key}" for key in role_keys) + ")"
        )
        params.update(dict(zip(role_keys, roles)))
    if filters["role"]:
        if not roles or filters["role"] not in roles:
            abort(400)
        conditions.append(f"u.role = :{prefix}_role")
        params[f"{prefix}_role"] = filters["role"]
    if filters["status"]:
        if filters["status"] not in {"active", "suspended"}:
            abort(400)
        conditions.append(f"u.is_active = :{prefix}_active")
        params[f"{prefix}_active"] = 1 if filters["status"] == "active" else 0
    if filters["availability"]:
        if filters["availability"] not in {"configured", "not_configured"}:
            abort(400)
        availability_exists = (
            "EXISTS (SELECT 1 FROM personnel_availability pa "
            "WHERE pa.personnel_id = u.id AND pa.personnel_role = u.role)"
        )
        conditions.append(
            ("NOT " if filters["availability"] == "not_configured" else "")
            + availability_exists
        )
    if filters["assignment"]:
        if filters["assignment"] not in {"assigned", "unassigned"}:
            abort(400)
        assignment_exists = (
            "EXISTS (SELECT 1 FROM appointments ap "
            "WHERE ap.assigned_personnel_id = u.id "
            "AND ap.assigned_personnel_role = u.role "
            "AND ap.status != 'Cancelled')"
        )
        conditions.append(
            ("NOT " if filters["assignment"] == "unassigned" else "")
            + assignment_exists
        )
    if filters["activity"]:
        if filters["activity"] not in {"has_appointments", "no_appointments"}:
            abort(400)
        activity_exists = (
            "EXISTS (SELECT 1 FROM appointments ap WHERE ap.user_id = u.id)"
        )
        conditions.append(
            ("NOT " if filters["activity"] == "no_appointments" else "")
            + activity_exists
        )
        conditions.append("u.role = 'Student'")
    if filters["sort"] not in sort_options:
        abort(400)
    return conditions, params, filters, sort_options[filters["sort"]]


def _paginate_query(
    db,
    select_clause,
    from_clause,
    conditions,
    params,
    order_by,
    page_param="page",
    anchor=None,
):
    try:
        page = int(request.args.get(page_param, "1"))
    except ValueError:
        abort(400)
    if page < 1:
        abort(400)

    where_clause = " WHERE " + " AND ".join(conditions) if conditions else ""
    total = db.execute(
        f"SELECT COUNT(*) {from_clause}{where_clause}", params
    ).fetchone()[0]
    pages = max(1, (total + PAGE_SIZE - 1) // PAGE_SIZE)
    page = min(page, pages)
    rows = db.execute(
        f"{select_clause} {from_clause}{where_clause} "
        f"ORDER BY {order_by} LIMIT :limit OFFSET :offset",
        {**params, "limit": PAGE_SIZE, "offset": (page - 1) * PAGE_SIZE},
    ).fetchall()

    def page_url(target_page):
        query_args = request.args.to_dict()
        query_args[page_param] = target_page
        target = url_for(request.endpoint, **query_args)
        return f"{target}#{anchor}" if anchor else target

    return rows, {
        "total": total,
        "page": page,
        "pages": pages,
        "previous_url": page_url(page - 1) if page > 1 else None,
        "next_url": page_url(page + 1) if page < pages else None,
    }


def migrate_admin_role():
    if not os.path.exists(DATABASE):
        return

    db = sqlite3.connect(DATABASE)
    try:
        table = db.execute(
            "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'users'"
        ).fetchone()
        if not table or "'Admin'" in (table[0] or ""):
            return

        columns = {
            row[1] for row in db.execute("PRAGMA table_info(users)").fetchall()
        }
        required_columns = {"id", "name", "email", "password_hash", "role"}
        if not required_columns.issubset(columns):
            raise RuntimeError("Cannot migrate users table with an unexpected schema.")

        foreign_key_issues = db.execute("PRAGMA foreign_key_check").fetchall()
        if foreign_key_issues:
            raise RuntimeError(
                "Cannot migrate users table because existing foreign-key issues were found."
            )

        backup_path = (
            f"{DATABASE}.before_admin_{datetime.now().strftime('%Y%m%d_%H%M%S')}.bak"
        )
        backup = sqlite3.connect(backup_path)
        try:
            db.backup(backup)
        finally:
            backup.close()

        user_columns = (
            "id", "name", "email", "password_hash", "role", "mobile",
            "student_number"
        )
        select_columns = [
            column if column in columns else f"NULL AS {column}"
            for column in user_columns
        ]
        users_before = db.execute(
            "SELECT " + ", ".join(user_columns) + " FROM users ORDER BY id"
        ).fetchall() if {"mobile", "student_number"}.issubset(columns) else db.execute(
            "SELECT " + ", ".join(select_columns) + " FROM users ORDER BY id"
        ).fetchall()
        appointments_before = db.execute(
            "SELECT * FROM appointments ORDER BY id"
        ).fetchall() if db.execute(
            "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'appointments'"
        ).fetchone() else []

        db.execute("PRAGMA foreign_keys = OFF")
        db.execute("BEGIN IMMEDIATE")
        db.execute("""
            CREATE TABLE users_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL
                    CHECK(role IN ('Student', 'Teacher', 'Registrar Staff', 'Admin')),
                mobile TEXT,
                student_number TEXT
            )
        """)
        db.execute(
            "INSERT INTO users_new (" + ", ".join(user_columns) + ") "
            "SELECT " + ", ".join(select_columns) + " FROM users"
        )
        db.execute("DROP TABLE users")
        db.execute("ALTER TABLE users_new RENAME TO users")

        users_after = db.execute(
            "SELECT " + ", ".join(user_columns) + " FROM users ORDER BY id"
        ).fetchall()
        appointments_after = db.execute(
            "SELECT * FROM appointments ORDER BY id"
        ).fetchall() if appointments_before else []
        if users_after != users_before or appointments_after != appointments_before:
            raise RuntimeError("Database records changed unexpectedly during role migration.")
        if db.execute("PRAGMA foreign_key_check").fetchall():
            raise RuntimeError("Foreign-key verification failed during role migration.")

        db.commit()
        db.execute("PRAGMA foreign_keys = ON")
        print(f"Admin-role migration completed. Database backup: {os.path.basename(backup_path)}")
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()

def send_reset_email(recipient, reset_link):
    """Send a reset link using SMTP settings supplied by the project owner."""
    host = os.environ.get("MAIL_SERVER", "")
    port = int(os.environ.get("MAIL_PORT", "587"))
    username = os.environ.get("MAIL_USERNAME", "")
    password = os.environ.get("MAIL_PASSWORD", "")
    sender = os.environ.get("MAIL_SENDER", username)

    if not all([host, username, password, sender]):
        raise RuntimeError("Email settings are not configured.")

    message = EmailMessage()
    message["Subject"] = "School Appointment System - Password Reset"
    message["From"] = sender
    message["To"] = recipient
    message.set_content(
        "We received a request to reset your School Appointment System password.\n\n"
        f"Open this link within 30 minutes:\n{reset_link}\n\n"
        "If you did not request this, you can ignore this email."
    )

    with smtplib.SMTP(host, port, timeout=20) as smtp:
        smtp.starttls()
        smtp.login(username, password)
        smtp.send_message(message)


# Connect to the SQLite database
def get_db():
    connection = sqlite3.connect(DATABASE)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    return connection



# Create database tables
def init_db():
    migrate_admin_role()
    with get_db() as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL
                    CHECK(role IN ('Student', 'Teacher', 'Registrar Staff', 'Admin'))
            )
        """)

                # Add the mobile column to existing databases when needed.
        columns = {
            row["name"]
            for row in db.execute("PRAGMA table_info(users)").fetchall()
        }

        if "mobile" not in columns:
            db.execute("ALTER TABLE users ADD COLUMN mobile TEXT")

        # Add the student_number column if it does not exist.
        if "student_number" not in columns:
            db.execute(
                "ALTER TABLE users ADD COLUMN student_number TEXT"
            )

        if "is_active" not in columns:
            db.execute(
                "ALTER TABLE users ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1"
            )

        if "profile_image" not in columns:
            db.execute("ALTER TABLE users ADD COLUMN profile_image TEXT")
        if "first_name" not in columns:
            db.execute("ALTER TABLE users ADD COLUMN first_name TEXT")
        if "last_name" not in columns:
            db.execute("ALTER TABLE users ADD COLUMN last_name TEXT")
        if "middle_initial" not in columns:
            db.execute("ALTER TABLE users ADD COLUMN middle_initial TEXT")
        if "name_review_required" not in columns:
            db.execute(
                "ALTER TABLE users ADD COLUMN name_review_required "
                "INTEGER NOT NULL DEFAULT 1"
            )
        if "auth_version" not in columns:
            db.execute(
                "ALTER TABLE users ADD COLUMN auth_version "
                "INTEGER NOT NULL DEFAULT 0"
            )
        if "password_changed_at" not in columns:
            db.execute("ALTER TABLE users ADD COLUMN password_changed_at TEXT")

        db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS
            idx_users_student_number_unique
            ON users(student_number)
            WHERE student_number IS NOT NULL AND student_number != ''
        """)

        

        # Allow different users to register with unique mobile numbers.
        db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS
            idx_users_mobile_unique
            ON users(mobile)
            WHERE mobile IS NOT NULL AND mobile != ''
        """)

        db.execute("""
            CREATE TABLE IF NOT EXISTS appointments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                service TEXT NOT NULL,
                appointment_date TEXT NOT NULL,
                appointment_time TEXT NOT NULL,
                reason TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Pending',
                FOREIGN KEY (user_id)
                    REFERENCES users(id)
            )
        """)

        # Add appointment fields safely for existing databases.
        appointment_columns = {
            row["name"]
            for row in db.execute(
                "PRAGMA table_info(appointments)"
            ).fetchall()
        }

        if "reference_number" not in appointment_columns:
            db.execute(
                "ALTER TABLE appointments "
                "ADD COLUMN reference_number TEXT"
            )

        if "campus" not in appointment_columns:
            db.execute(
                "ALTER TABLE appointments "
                "ADD COLUMN campus TEXT"
            )

        # Give existing appointments reference numbers
        # and the school's campus name.
        db.execute("""
            UPDATE appointments
            SET reference_number = 'EDU-' || printf('%06d', id)
            WHERE reference_number IS NULL
               OR reference_number = ''
        """)

        db.execute("""
            UPDATE appointments
            SET campus = ?
            WHERE campus IS NULL OR campus = ''
        """, ("Main Campus – Registrar's Office",))

        # Add verification tokens to existing appointments.
        appointment_columns = {
            row["name"]
            for row in db.execute(
                "PRAGMA table_info(appointments)"
            ).fetchall()
        }

        if "verification_token" not in appointment_columns:
            db.execute(
                "ALTER TABLE appointments "
                "ADD COLUMN verification_token TEXT"
            )

        # Assign unique random tokens to older appointments that need them.
        old_appointments = db.execute("""
            SELECT id
            FROM appointments
            WHERE verification_token IS NULL
               OR verification_token = ''
        """).fetchall()

        for old_appointment in old_appointments:
            db.execute(
                "UPDATE appointments SET verification_token = ? WHERE id = ?",
                (secrets.token_urlsafe(32), old_appointment["id"])
            )

        db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS
            idx_appointments_verification_unique
            ON appointments(verification_token)
            WHERE verification_token IS NOT NULL
        """)

        # Keep appointment reference numbers unique.
        db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS
            idx_appointments_reference_unique
            ON appointments(reference_number)
            WHERE reference_number IS NOT NULL
        """)
        # Keep appointment reference numbers unique.
        db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS
            idx_appointments_reference_unique
            ON appointments(reference_number)
            WHERE reference_number IS NOT NULL
        """)

        appointment_columns = {
            row["name"]
            for row in db.execute("PRAGMA table_info(appointments)").fetchall()
        }
        if "assigned_teacher_id" not in appointment_columns:
            db.execute(
                "ALTER TABLE appointments ADD COLUMN assigned_teacher_id "
                "INTEGER REFERENCES users(id) ON DELETE SET NULL"
            )
        if "rejection_reason" not in appointment_columns:
            db.execute("ALTER TABLE appointments ADD COLUMN rejection_reason TEXT")
        if "assigned_personnel_id" not in appointment_columns:
            db.execute(
                "ALTER TABLE appointments ADD COLUMN assigned_personnel_id "
                "INTEGER REFERENCES users(id) ON DELETE SET NULL"
            )
        if "assigned_personnel_role" not in appointment_columns:
            db.execute("ALTER TABLE appointments ADD COLUMN assigned_personnel_role TEXT")
        if "assignment_status" not in appointment_columns:
            db.execute(
                "ALTER TABLE appointments ADD COLUMN assignment_status "
                "TEXT NOT NULL DEFAULT 'Unassigned'"
            )
        db.execute("""
            UPDATE appointments
            SET assigned_personnel_id = assigned_teacher_id,
                assigned_personnel_role = 'Teacher',
                assignment_status = 'Assigned'
            WHERE assigned_personnel_id IS NULL
              AND assigned_teacher_id IS NOT NULL
        """)

        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_appointments_assigned_teacher
            ON appointments(assigned_teacher_id, appointment_date, appointment_time)
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_appointments_assigned_personnel
            ON appointments(
                assigned_personnel_id, assigned_personnel_role,
                appointment_date, appointment_time
            )
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_appointments_user_schedule
            ON appointments(user_id, appointment_date, appointment_time)
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_appointments_status_schedule
            ON appointments(status, appointment_date, appointment_time)
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_appointments_service_schedule
            ON appointments(service, appointment_date, appointment_time)
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_users_role_name
            ON users(role, name COLLATE NOCASE)
        """)

        db.execute("""
            CREATE TABLE IF NOT EXISTS teacher_availability (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                teacher_id INTEGER NOT NULL,
                weekday INTEGER NOT NULL CHECK(weekday BETWEEN 0 AND 5),
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                CHECK(start_time < end_time),
                UNIQUE(teacher_id, weekday),
                FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS teacher_unavailable_dates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                teacher_id INTEGER NOT NULL,
                unavailable_date TEXT NOT NULL,
                note TEXT,
                UNIQUE(teacher_id, unavailable_date),
                FOREIGN KEY (teacher_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS personnel_availability (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                personnel_id INTEGER NOT NULL,
                personnel_role TEXT NOT NULL
                    CHECK(personnel_role IN ('Teacher', 'Registrar Staff')),
                weekday INTEGER NOT NULL CHECK(weekday BETWEEN 0 AND 5),
                start_time TEXT NOT NULL,
                end_time TEXT NOT NULL,
                CHECK(start_time < end_time),
                UNIQUE(personnel_id, weekday),
                FOREIGN KEY (personnel_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)
        db.execute("""
            INSERT OR IGNORE INTO personnel_availability (
                personnel_id, personnel_role, weekday, start_time, end_time
            )
            SELECT teacher_id, 'Teacher', weekday, start_time, end_time
            FROM teacher_availability
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS personnel_unavailable_dates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                personnel_id INTEGER NOT NULL,
                personnel_role TEXT NOT NULL
                    CHECK(personnel_role IN ('Teacher', 'Registrar Staff')),
                unavailable_date TEXT NOT NULL,
                note TEXT,
                UNIQUE(personnel_id, unavailable_date),
                FOREIGN KEY (personnel_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)
        db.execute("""
            INSERT OR IGNORE INTO personnel_unavailable_dates (
                personnel_id, personnel_role, unavailable_date, note
            )
            SELECT teacher_id, 'Teacher', unavailable_date, note
            FROM teacher_unavailable_dates
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS appointment_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                appointment_id INTEGER NOT NULL,
                actor_user_id INTEGER,
                event_type TEXT NOT NULL,
                previous_status TEXT,
                new_status TEXT,
                previous_assigned_teacher_id INTEGER,
                new_assigned_teacher_id INTEGER,
                note TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (appointment_id)
                    REFERENCES appointments(id) ON DELETE CASCADE,
                FOREIGN KEY (actor_user_id)
                    REFERENCES users(id) ON DELETE SET NULL
            )
        """)
        event_columns = {
            row["name"] for row in db.execute(
                "PRAGMA table_info(appointment_events)"
            ).fetchall()
        }
        for column_name, declaration in (
            ("previous_assigned_personnel_id", "INTEGER REFERENCES users(id) ON DELETE SET NULL"),
            ("new_assigned_personnel_id", "INTEGER REFERENCES users(id) ON DELETE SET NULL"),
            ("previous_assigned_personnel_role", "TEXT"),
            ("new_assigned_personnel_role", "TEXT"),
        ):
            if column_name not in event_columns:
                db.execute(
                    f"ALTER TABLE appointment_events ADD COLUMN "
                    f"{column_name} {declaration}"
                )
        db.execute("""
            UPDATE appointment_events
            SET previous_assigned_personnel_id = previous_assigned_teacher_id,
                previous_assigned_personnel_role = 'Teacher'
            WHERE previous_assigned_personnel_id IS NULL
              AND previous_assigned_teacher_id IS NOT NULL
        """)
        db.execute("""
            UPDATE appointment_events
            SET new_assigned_personnel_id = new_assigned_teacher_id,
                new_assigned_personnel_role = 'Teacher'
            WHERE new_assigned_personnel_id IS NULL
              AND new_assigned_teacher_id IS NOT NULL
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_appointment_events_appointment
            ON appointment_events(appointment_id, created_at)
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS profile_change_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                previous_values TEXT NOT NULL,
                proposed_values TEXT NOT NULL,
                changed_groups TEXT NOT NULL,
                status TEXT NOT NULL,
                submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                registrar_reviewer_id INTEGER,
                registrar_decision TEXT NOT NULL DEFAULT 'Pending',
                registrar_decided_at TEXT,
                admin_reviewer_id INTEGER,
                admin_decision TEXT NOT NULL DEFAULT 'Pending',
                admin_decided_at TEXT,
                rejection_reason TEXT,
                email_verification_token_hash TEXT,
                email_verification_expires_at TEXT,
                email_verified_at TEXT,
                cooldown_override_reason TEXT,
                cooldown_override_by INTEGER,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                FOREIGN KEY (registrar_reviewer_id) REFERENCES users(id) ON DELETE SET NULL,
                FOREIGN KEY (admin_reviewer_id) REFERENCES users(id) ON DELETE SET NULL,
                FOREIGN KEY (cooldown_override_by) REFERENCES users(id) ON DELETE SET NULL
            )
        """)
        db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_profile_change_one_pending
            ON profile_change_requests(user_id)
            WHERE status IN (
                'Pending Email Verification',
                'Pending Registrar Review',
                'Pending Administrator Review'
            )
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_profile_change_review_queue
            ON profile_change_requests(status, submitted_at)
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS profile_change_cooldowns (
                user_id INTEGER NOT NULL,
                field_group TEXT NOT NULL,
                available_after TEXT NOT NULL,
                PRIMARY KEY (user_id, field_group),
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                category TEXT NOT NULL DEFAULT 'system',
                title TEXT NOT NULL DEFAULT 'System update',
                message TEXT NOT NULL,
                link TEXT,
                related_type TEXT,
                related_id INTEGER,
                dedupe_key TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                read_at TEXT,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        """)
        notification_columns = {
            row["name"] for row in db.execute(
                "PRAGMA table_info(notifications)"
            ).fetchall()
        }
        for column_name, declaration in (
            ("category", "TEXT NOT NULL DEFAULT 'system'"),
            ("title", "TEXT NOT NULL DEFAULT 'System update'"),
            ("related_type", "TEXT"),
            ("related_id", "INTEGER"),
            ("dedupe_key", "TEXT"),
        ):
            if column_name not in notification_columns:
                db.execute(
                    f"ALTER TABLE notifications ADD COLUMN "
                    f"{column_name} {declaration}"
                )
        db.execute("""
            CREATE UNIQUE INDEX IF NOT EXISTS idx_notifications_dedupe_key
            ON notifications(dedupe_key)
            WHERE dedupe_key IS NOT NULL
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_notifications_user_date
            ON notifications(user_id, read_at, created_at)
        """)
        db.execute("""
            CREATE TABLE IF NOT EXISTS account_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                actor_user_id INTEGER,
                affected_user_id INTEGER,
                event_type TEXT NOT NULL,
                previous_values TEXT,
                new_values TEXT,
                reason TEXT,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (actor_user_id) REFERENCES users(id) ON DELETE SET NULL,
                FOREIGN KEY (affected_user_id) REFERENCES users(id) ON DELETE SET NULL
            )
        """)
        db.execute("""
            CREATE INDEX IF NOT EXISTS idx_account_events_affected_date
            ON account_events(affected_user_id, created_at)
        """)


def log_appointment_event(
    db,
    appointment_id,
    actor_user_id,
    event_type,
    previous_status=None,
    new_status=None,
    previous_assigned_teacher_id=None,
    new_assigned_teacher_id=None,
    note=None,
    previous_assigned_personnel_id=None,
    new_assigned_personnel_id=None,
    previous_assigned_personnel_role=None,
    new_assigned_personnel_role=None,
):
    if previous_assigned_personnel_id is None:
        previous_assigned_personnel_id = previous_assigned_teacher_id
        previous_assigned_personnel_role = (
            "Teacher" if previous_assigned_teacher_id is not None else None
        )
    if new_assigned_personnel_id is None:
        new_assigned_personnel_id = new_assigned_teacher_id
        new_assigned_personnel_role = (
            "Teacher" if new_assigned_teacher_id is not None else None
        )
    cursor = db.execute("""
        INSERT INTO appointment_events (
            appointment_id, actor_user_id, event_type,
            previous_status, new_status,
            previous_assigned_teacher_id, new_assigned_teacher_id, note,
            previous_assigned_personnel_id, new_assigned_personnel_id,
            previous_assigned_personnel_role, new_assigned_personnel_role
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        appointment_id,
        actor_user_id,
        event_type,
        previous_status,
        new_status,
        previous_assigned_teacher_id,
        new_assigned_teacher_id,
        note,
        previous_assigned_personnel_id,
        new_assigned_personnel_id,
        previous_assigned_personnel_role,
        new_assigned_personnel_role,
    ))
    return cursor.lastrowid


def personnel_slot_is_available(
    db,
    personnel_id,
    personnel_role,
    appointment_date,
    appointment_time,
    exclude_appointment_id=None,
):
    chosen_date = date.fromisoformat(appointment_date)
    start = datetime.strptime(appointment_time, "%H:%M")
    end = (start + timedelta(minutes=30)).strftime("%H:%M")

    unavailable = db.execute("""
        SELECT 1
        FROM personnel_unavailable_dates
        WHERE personnel_id = ? AND personnel_role = ?
          AND unavailable_date = ?
    """, (personnel_id, personnel_role, appointment_date)).fetchone()
    if unavailable:
        return False

    availability = db.execute("""
        SELECT 1
        FROM personnel_availability
        WHERE personnel_id = ? AND personnel_role = ?
          AND weekday = ?
          AND start_time <= ?
          AND end_time >= ?
    """, (
        personnel_id,
        personnel_role,
        chosen_date.weekday(),
        appointment_time,
        end,
    )).fetchone()
    if not availability:
        return False

    conflict = db.execute("""
        SELECT 1
        FROM appointments
        WHERE assigned_personnel_id = ?
          AND assigned_personnel_role = ?
          AND appointment_date = ?
          AND appointment_time = ?
          AND status != 'Cancelled'
          AND (? IS NULL OR id != ?)
        LIMIT 1
    """, (
        personnel_id,
        personnel_role,
        appointment_date,
        appointment_time,
        exclude_appointment_id,
        exclude_appointment_id,
    )).fetchone()
    return conflict is None


def teacher_slot_is_available(
    db,
    teacher_id,
    appointment_date,
    appointment_time,
    exclude_appointment_id=None,
):
    return personnel_slot_is_available(
        db,
        teacher_id,
        "Teacher",
        appointment_date,
        appointment_time,
        exclude_appointment_id,
    )


def staff_dashboard_endpoint():
    if session.get("user_role") == "Teacher":
        return "teacher_dashboard"
    return "registrar_dashboard"


# CSRF protection token for forms
def csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_hex(32)

    return session["csrf_token"]


app.jinja_env.globals["csrf_token"] = csrf_token


@app.before_request
def protect_post_requests():
    if request.method == "POST":
        submitted = request.form.get("csrf_token", "")
        saved = session.get("csrf_token", "")

        if not saved or not secrets.compare_digest(
            submitted, saved
        ):
            abort(
                400,
                description="Security token invalid. Refresh and try again."
            )


# Require login before accessing protected pages
def login_required(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in first.")
            return redirect(url_for("login"))

        return function(*args, **kwargs)

    return wrapper


def role_required(*allowed_roles):
    def decorator(function):
        @wraps(function)
        @login_required
        def wrapper(*args, **kwargs):
            with get_db() as db:
                user = db.execute(
                    """SELECT role, is_active, auth_version, name,
                              first_name, last_name, middle_initial
                       FROM users WHERE id = ?""",
                    (session["user_id"],)
                ).fetchone()

            if not user or not user["is_active"]:
                session.clear()
                flash("This account is unavailable. Please contact an administrator.")
                return redirect(url_for("login"))
            if session.get("auth_version") != user["auth_version"]:
                session.clear()
                flash("Your session has expired. Please sign in again.")
                return redirect(url_for("login"))

            session["user_role"] = user["role"]
            session["user_name"] = _format_full_name(
                user["last_name"], user["first_name"],
                user["middle_initial"], user["name"],
            )
            if user["role"] not in allowed_roles:
                abort(403)
            return function(*args, **kwargs)
        return wrapper
    return decorator


@app.context_processor
def inject_current_user():
    user_id = session.get("user_id")
    if user_id is None:
        return {"current_user": None}

    with get_db() as db:
        current_user = db.execute(
            f"""SELECT id, {_full_name_sql('users')} AS name, profile_image
                FROM users WHERE id = ?""",
            (user_id,)
        ).fetchone()
        notifications = db.execute("""
            SELECT id, category, title, message, link, created_at
            FROM notifications
            WHERE user_id = ? AND read_at IS NULL
            ORDER BY id DESC
            LIMIT 5
        """, (user_id,)).fetchall()
        unread_notification_count = db.execute("""
            SELECT COUNT(*) FROM notifications
            WHERE user_id = ? AND read_at IS NULL
        """, (user_id,)).fetchone()[0]
    return {
        "current_user": current_user,
        "notifications": notifications,
        "unread_notification_count": unread_notification_count,
    }


@app.route("/notifications")
@role_required("Student", "Registrar Staff", "Teacher", "Admin")
def notification_center():
    selected_status = request.args.get("status", "all")
    if selected_status not in {"all", "unread", "read"}:
        selected_status = "all"
    selected_category = request.args.get("category", "all")
    valid_categories = {"all", "appointment", "profile", "security", "account", "system"}
    if selected_category not in valid_categories:
        selected_category = "all"
    try:
        page = max(1, int(request.args.get("page", "1")))
    except ValueError:
        page = 1
    page_size = 25
    where = ["user_id = ?"]
    parameters = [session["user_id"]]
    if selected_status == "unread":
        where.append("read_at IS NULL")
    elif selected_status == "read":
        where.append("read_at IS NOT NULL")
    if selected_category != "all":
        where.append("category = ?")
        parameters.append(selected_category)
    where_clause = " AND ".join(where)
    with get_db() as db:
        total = db.execute(
            f"SELECT COUNT(*) FROM notifications WHERE {where_clause}",
            parameters,
        ).fetchone()[0]
        pages = max(1, (total + page_size - 1) // page_size)
        page = min(page, pages)
        notifications = db.execute(
            f"""SELECT id, category, title, message, link, created_at, read_at
                FROM notifications
                WHERE {where_clause}
                ORDER BY id DESC
                LIMIT ? OFFSET ?""",
            (*parameters, page_size, (page - 1) * page_size),
        ).fetchall()
    return render_template(
        "notifications.html",
        page_notifications=notifications,
        selected_status=selected_status,
        selected_category=selected_category,
        notification_total=total,
        notification_page=page,
        notification_pages=pages,
    )


@app.route("/notifications/read-all", methods=["POST"])
@role_required("Student", "Registrar Staff", "Teacher", "Admin")
def mark_all_notifications_read():
    with get_db() as db:
        db.execute("""
            UPDATE notifications
            SET read_at = CURRENT_TIMESTAMP
            WHERE user_id = ? AND read_at IS NULL
        """, (session["user_id"],))
    return redirect(url_for("notification_center"))


@app.route("/notifications/<int:notification_id>/read", methods=["POST"])
@role_required("Student", "Registrar Staff", "Teacher", "Admin")
def mark_notification_read(notification_id):
    with get_db() as db:
        result = db.execute("""
            UPDATE notifications
            SET read_at = CURRENT_TIMESTAMP
            WHERE id = ? AND user_id = ? AND read_at IS NULL
        """, (notification_id, session["user_id"]))
    if not result.rowcount:
        abort(404)
    next_url = request.form.get("next", "")
    if not next_url.startswith("/") or next_url.startswith("//"):
        next_url = url_for("notification_center")
    return redirect(next_url)


@app.route("/notifications/<int:notification_id>/unread", methods=["POST"])
@role_required("Student", "Registrar Staff", "Teacher", "Admin")
def mark_notification_unread(notification_id):
    with get_db() as db:
        result = db.execute("""
            UPDATE notifications
            SET read_at = NULL
            WHERE id = ? AND user_id = ? AND read_at IS NOT NULL
        """, (notification_id, session["user_id"]))
    if not result.rowcount:
        abort(404)
    return redirect(url_for("notification_center"))


# Home page
@app.route("/")
def home():
    if session.get("user_role") == "Admin":
        return redirect(url_for("admin_dashboard"))
    if session.get("user_role") == "Registrar Staff":
        return redirect(url_for("registrar_dashboard"))
    if session.get("user_role") == "Teacher":
        return redirect(url_for("teacher_dashboard"))
    if session.get("user_role") == "Student":
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))



# Registration
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name_parts = _normalized_name_parts(request.form)
        student_number = request.form.get("student_number", "").strip()
        email = request.form.get("email", "").strip().lower()
        mobile = request.form.get("mobile", "").strip()
        password = request.form.get("password", "")
        # Public registration is always for Students; ignore submitted roles.
        role = "Student"

        
        # Require a name, password, and at least one contact method.
        if not name_parts or not password or (not email and not mobile):
            flash("Enter your last and first name, password, and an email or mobile number.")
            return render_template("index.html", page="register")

        # Every Student account must have a Student Number.
        if role == "Student" and not student_number:
            flash("Student Number is required for Student accounts.")
            return render_template("index.html", page="register")

        if len(email) > 254 or len(mobile) > 20:
            flash("Contact information is too long.")
            return render_template("index.html", page="register")

       
        # Validate Student Number.
        if student_number:
            if len(student_number) > 30:
                flash("Student Number is too long.")
                return render_template("index.html", page="register")

            if not re.fullmatch(r"[0-9]+-[0-9]+", student_number):
                flash("Enter a valid Student Number using numbers and one dash.")
                return render_template("index.html", page="register")

        if len(password) < 8:
            flash("Password must be at least 8 characters.")
            return render_template("index.html", page="register")


        # Basic mobile number validation.
        if mobile and not mobile.replace("+", "").isdigit():
            flash("Please enter a valid mobile number using digits and an optional +.")
            return render_template("index.html", page="register")

        # The existing database requires an email value.
        # For mobile-only accounts, use an internal placeholder.
        if not email:
            mobile_key = mobile.replace("+", "")
            email = f"mobile_{mobile_key}@phone.local"

        last_name, first_name, middle_initial = name_parts
        name = _format_full_name(last_name, first_name, middle_initial)
        password_hash = generate_password_hash(password)

        try:
            with get_db() as db:
                
                cursor = db.execute(
                    """
                    INSERT INTO users
                    (name, first_name, last_name, middle_initial,
                     name_review_required, email, mobile, password_hash,
                     role, student_number)
                    VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?)
                    """,
                    (
                        name,
                        first_name,
                        last_name,
                        middle_initial or None,
                        email,
                        mobile or None,
                        password_hash,
                        role,
                        student_number or None,
                    ),
                )
                _log_account_event(
                    db, None, cursor.lastrowid, "account_registered",
                    new_values={
                        "name": name, "email": email, "mobile": mobile or None,
                        "role": role, "student_number": student_number or None,
                    },
                )
                _create_notification(
                    db,
                    cursor.lastrowid,
                    "Your account is ready. Sign in to manage your appointments.",
                    url_for("login"),
                    category="account",
                    title="Welcome",
                    related_type="user",
                    related_id=cursor.lastrowid,
                )
            flash("Registration successful! You can now log in.")
            return redirect(url_for("login"))

        except sqlite3.IntegrityError:
            flash("That email, mobile number, or Student Number is already registered.")
            return render_template("index.html", page="register")

    return render_template("index.html", page="register")





# Login
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        identifier = request.form.get("email", "").strip()
        password = request.form.get("password", "")

        with get_db() as db:
            user = db.execute(
                """
                SELECT * FROM users
                WHERE LOWER(email) = LOWER(?) OR mobile = ?
                """,
                (identifier, identifier)
            ).fetchone()

        if user and check_password_hash(
            user["password_hash"], password
        ):
            if not user["is_active"]:
                flash("This account is suspended. Contact an administrator.")
                return redirect(url_for("login"))

            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = _format_full_name(
                user["last_name"],
                user["first_name"],
                user["middle_initial"],
                user["name"],
            )
            session["user_role"] = user["role"]
            session["auth_version"] = user["auth_version"]
            session["csrf_token"] = secrets.token_hex(32)

            if user["role"] == "Registrar Staff":
                return redirect(url_for("registrar_dashboard"))
            if user["role"] == "Teacher":
                return redirect(url_for("teacher_dashboard"))
            if user["role"] == "Admin":
                return redirect(url_for("admin_dashboard"))
            if user["role"] == "Student":
                return redirect(url_for("dashboard"))
            session.clear()
            flash("This account does not have access to the appointment portal.")
            return redirect(url_for("login"))

        flash("Incorrect email/mobile number or password.")

    return render_template("index.html", page="login")



# Request a password-reset link by email.
@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()

        # Keep the response general so the page does not reveal account existence.
        with get_db() as db:
            user = db.execute(
                "SELECT id, email, auth_version FROM users WHERE LOWER(email) = LOWER(?)",
                (email,)
            ).fetchone()

        if user and not user["email"].endswith("@phone.local"):
            token = reset_serializer.dumps(
                {
                    "user_id": user["id"],
                    "email": user["email"],
                    "auth_version": user["auth_version"],
                },
                salt="password-reset"
            )
            reset_link = url_for("reset_password", token=token, _external=True)
            try:
                send_reset_email(user["email"], reset_link)
            except Exception:
                app.logger.exception("Could not send password reset email")
                # Do not expose SMTP details or account existence to the visitor.
        flash("If that email is registered and email delivery is configured, a reset link will be sent.")
        return redirect(url_for("login"))

    return render_template("index.html", page="forgot_password")


# Set a new password using a signed, expiring email token.
@app.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    try:
        data = reset_serializer.loads(
            token, salt="password-reset", max_age=1800
        )
    except (BadSignature, SignatureExpired):
        flash("This password-reset link is invalid or expired. Please request a new one.")
        return redirect(url_for("forgot_password"))

    with get_db() as db:
        user = db.execute(
            """SELECT id, auth_version FROM users
               WHERE id = ? AND LOWER(email) = LOWER(?) AND auth_version = ?""",
            (
                data.get("user_id"), data.get("email", ""),
                data.get("auth_version"),
            )
        ).fetchone()

    if not user:
        flash("This password-reset link is no longer valid. Please request a new one.")
        return redirect(url_for("forgot_password"))

    if request.method == "POST":
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        if len(password) < 8:
            flash("Password must be at least 8 characters.")
            return render_template("index.html", page="reset_password", token=token)
        if password != confirm:
            flash("The passwords do not match.")
            return render_template("index.html", page="reset_password", token=token)

        with get_db() as db:
            db.execute(
                """UPDATE users
                   SET password_hash = ?, password_changed_at = ?,
                       auth_version = auth_version + 1
                   WHERE id = ?""",
                (generate_password_hash(password), _utc_now().isoformat(), user["id"])
            )
            _log_account_event(
                db, user["id"], user["id"], "password_reset",
                previous_values={"auth_version": user["auth_version"]},
                new_values={"auth_version": user["auth_version"] + 1},
            )
            _create_notification(
                db, user["id"],
                "Your password was reset. If you did not request this, contact an Administrator.",
                url_for("login"),
                category="security",
                title="Password reset",
                related_type="user",
                related_id=user["id"],
            )
            _notify_role(
                db, "Admin",
                "A user password was reset.",
                url_for("admin_dashboard") + "#activity",
                category="security",
                title="Password reset",
                related_type="user",
                related_id=user["id"],
                exclude_user_id=user["id"],
            )
        flash("Your password has been changed. You can now log in.")
        return redirect(url_for("login"))

    return render_template("index.html", page="reset_password", token=token)


# Appointment schedule: Monday-Saturday, 8:00 AM to 5:00 PM, 30-minute slots.
def make_time_slots():
    slots = []
    current = datetime.combine(date.today(), time(8, 0))
    end = datetime.combine(date.today(), time(17, 0))
    while current < end:
        slots.append(current.strftime("%H:%M"))
        current += timedelta(minutes=30)
    return slots


def is_valid_appointment_date(chosen_date):
    # Monday is 0; Sunday is 6.
    return chosen_date.weekday() <= 5


# Registrar dashboard for office-wide appointment management.
@app.route("/registrar-dashboard")
@role_required("Registrar Staff")
def registrar_dashboard():
    with get_db() as db:
        services = [
            row["service"] for row in db.execute(
                "SELECT DISTINCT service FROM appointments ORDER BY service COLLATE NOCASE"
            ).fetchall()
        ]
        appointment_conditions, appointment_params, appointment_filters, appointment_order = (
            _appointment_filters(
                request.args,
                (
                    "a.id", "a.reference_number", "u.name", "u.first_name",
                    "u.last_name", "u.middle_initial", "u.student_number",
                    "a.service", "a.reason", "p.name", "p.first_name",
                    "p.last_name", "a.appointment_date",
                    "a.appointment_time", "a.status",
                ),
                services,
                allow_personnel=True,
            )
        )
        appointments, appointment_pagination = _paginate_query(
            db,
            f"""SELECT a.id, a.reference_number, a.service, a.reason,
                      a.appointment_date, a.appointment_time, a.campus, a.status,
                      a.assigned_teacher_id, a.rejection_reason,
                      a.assigned_personnel_id, a.assigned_personnel_role,
                      a.assignment_status,
                      {_full_name_sql('u')} AS student_name, u.student_number,
                      {_full_name_sql('p')} AS teacher_name,
                      {_full_name_sql('p')} AS assigned_personnel_name""",
            """FROM appointments a
               JOIN users u ON u.id = a.user_id
               LEFT JOIN users p ON p.id = a.assigned_personnel_id""",
            appointment_conditions,
            appointment_params,
            appointment_order,
            anchor="appointments",
        )
        teachers = db.execute(f"""
            SELECT id, role, {_full_name_sql('users')} AS name,
                   first_name, last_name, middle_initial
            FROM users
            WHERE role IN ('Teacher', 'Registrar Staff') AND is_active = 1
            ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE, name COLLATE NOCASE
        """).fetchall()
        personnel = db.execute(f"""
            SELECT id, role, {_full_name_sql('users')} AS name,
                   first_name, last_name, middle_initial
            FROM users
            WHERE role IN ('Teacher', 'Registrar Staff')
            ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE, name COLLATE NOCASE
        """).fetchall()
        student_conditions, student_params, student_filters, student_order = _user_filters(
            request.args,
            ("u.name", "u.first_name", "u.last_name", "u.middle_initial", "u.student_number", "u.id"),
            {
                "name_asc": USER_SORTS["name_asc"],
                "name_desc": USER_SORTS["name_desc"],
                "student_number_asc": USER_SORTS["student_number_asc"],
                "student_number_desc": USER_SORTS["student_number_desc"],
            },
            "students",
            roles=("Student",),
        )
        students, student_pagination = _paginate_query(
            db,
            f"""SELECT u.id, {_full_name_sql('u')} AS name,
                      u.student_number, u.is_active""",
            "FROM users u",
            student_conditions,
            student_params,
            student_order,
            page_param="student_page",
            anchor="students",
        )
        staff_conditions, staff_params, staff_filters, staff_order = _user_filters(
            request.args,
            ("u.name", "u.first_name", "u.last_name", "u.middle_initial", "u.id", "u.email", "u.mobile", "u.role"),
            USER_SORTS,
            "staff",
            roles=("Teacher", "Registrar Staff"),
        )
        staff, staff_pagination = _paginate_query(
            db,
            f"""SELECT u.id, {_full_name_sql('u')} AS name,
                      u.email, u.mobile, u.role, u.is_active,
                      (SELECT COUNT(*) FROM appointments a
                       WHERE a.assigned_personnel_id = u.id
                         AND a.assigned_personnel_role = u.role
                         AND a.status != 'Cancelled') AS assigned_appointments""",
            "FROM users u",
            staff_conditions,
            staff_params,
            staff_order,
            page_param="staff_page",
            anchor="staff",
        )
        current_staff_id = session["user_id"]
        staff_availability = {
            row["weekday"]: row
            for row in db.execute("""
                SELECT weekday, start_time, end_time
                FROM personnel_availability
                WHERE personnel_id = ? AND personnel_role = 'Registrar Staff'
            """, (current_staff_id,)).fetchall()
        }
        staff_unavailable_dates = db.execute("""
            SELECT id, unavailable_date, note
            FROM personnel_unavailable_dates
            WHERE personnel_id = ? AND personnel_role = 'Registrar Staff'
              AND unavailable_date >= ?
            ORDER BY unavailable_date
        """, (current_staff_id, date.today().isoformat())).fetchall()
        profile_requests = [
            _profile_request_for_template(row)
            for row in db.execute(f"""
                SELECT r.*, {_full_name_sql('u')} AS requester_name,
                       u.role AS requester_role
                FROM profile_change_requests r
                JOIN users u ON u.id = r.user_id
                WHERE r.status = 'Pending Registrar Review'
                  AND r.user_id != ?
                ORDER BY r.submitted_at, r.id
                LIMIT 100
            """, (current_staff_id,)).fetchall()
        ]
    return render_template(
        "registrar_dashboard.html",
        appointments=appointments,
        teachers=teachers,
        personnel=personnel,
        services=services,
        statuses=APPOINTMENT_STATUSES,
        appointment_filters=appointment_filters,
        appointment_pagination=appointment_pagination,
        students=students,
        student_pagination=student_pagination,
        student_filters=student_filters,
        staff=staff,
        staff_pagination=staff_pagination,
        staff_filters=staff_filters,
        staff_availability=staff_availability,
        staff_unavailable_dates=staff_unavailable_dates,
        profile_requests=profile_requests,
        today=date.today().isoformat(),
        weekdays=tuple((day, name) for day, name in enumerate(
            ("Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        )),
    )


@app.route("/teacher-dashboard")
@role_required("Teacher")
def teacher_dashboard():
    teacher_id = session["user_id"]
    with get_db() as db:
        services = [
            row["service"] for row in db.execute("""
                SELECT DISTINCT service
                FROM appointments
                WHERE assigned_personnel_id = ?
                  AND assigned_personnel_role = 'Teacher'
                ORDER BY service COLLATE NOCASE
            """, (teacher_id,)).fetchall()
        ]
        conditions, search_params, filters, order_by = _appointment_filters(
            request.args,
            (
                "a.id", "a.reference_number", "u.name", "u.first_name",
                "u.last_name", "u.middle_initial", "u.student_number",
                "a.service", "a.reason", "a.appointment_date",
                "a.appointment_time", "a.status",
            ),
            services,
            sort_options={
                key: APPOINTMENT_SORTS[key]
                for key in (
                    "date_asc", "date_desc", "student_asc", "student_desc",
                    "category_asc", "status",
                )
            },
        )
        conditions.insert(
            0,
            "a.assigned_personnel_id = :teacher_id "
            "AND a.assigned_personnel_role = 'Teacher'",
        )
        search_params["teacher_id"] = teacher_id
        appointments, appointment_pagination = _paginate_query(
            db,
            f"""SELECT a.id, a.reference_number, a.service, a.reason,
                      a.appointment_date, a.appointment_time, a.campus, a.status,
                      a.rejection_reason, {_full_name_sql('u')} AS student_name,
                      u.student_number""",
            """FROM appointments a
               JOIN users u ON u.id = a.user_id""",
            conditions,
            search_params,
            order_by,
            anchor="assigned-appointments",
        )
        availability = {
            row["weekday"]: row
            for row in db.execute("""
                SELECT weekday, start_time, end_time
                FROM personnel_availability
                WHERE personnel_id = ? AND personnel_role = 'Teacher'
            """, (teacher_id,)).fetchall()
        }
        unavailable_dates = db.execute("""
            SELECT id, unavailable_date, note
            FROM personnel_unavailable_dates
            WHERE personnel_id = ? AND personnel_role = 'Teacher'
              AND unavailable_date >= ?
            ORDER BY unavailable_date
        """, (teacher_id, date.today().isoformat())).fetchall()

    return render_template(
        "teacher_dashboard.html",
        appointments=appointments,
        services=services,
        statuses=APPOINTMENT_STATUSES,
        appointment_filters=filters,
        appointment_pagination=appointment_pagination,
        availability=availability,
        unavailable_dates=unavailable_dates,
        today=date.today().isoformat(),
        weekdays=(
            (0, "Monday"),
            (1, "Tuesday"),
            (2, "Wednesday"),
            (3, "Thursday"),
            (4, "Friday"),
            (5, "Saturday"),
        ),
    )


@app.route("/registrar/appointments/<int:appointment_id>/assign", methods=["POST"])
@role_required("Registrar Staff")
def assign_appointment(appointment_id):
    personnel_text = request.form.get(
        "personnel_id", request.form.get("teacher_id", "")
    ).strip()
    personnel_id = None
    personnel_role = None
    if ":" in personnel_text:
        personnel_role, personnel_text = personnel_text.split(":", 1)
    elif personnel_text:
        personnel_role = "Teacher"
    if personnel_text:
        try:
            personnel_id = int(personnel_text)
        except ValueError:
            abort(400)
    if personnel_id is not None and personnel_role not in {"Teacher", "Registrar Staff"}:
        abort(400)

    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        appointment = db.execute("""
            SELECT id, status, appointment_date, appointment_time,
                   reference_number, user_id, assigned_personnel_id,
                   assigned_personnel_role
            FROM appointments
            WHERE id = ?
        """, (appointment_id,)).fetchone()
        if not appointment:
            abort(404)
        if appointment["status"] != "Pending":
            flash("Only pending appointments can be assigned.")
            return redirect(url_for("registrar_dashboard"))
        if (
            appointment["assigned_personnel_id"] == personnel_id
            and appointment["assigned_personnel_role"] == personnel_role
        ):
            flash("That appointment is already assigned as selected.")
            return redirect(url_for("registrar_dashboard"))

        if personnel_id is not None:
            personnel = db.execute("""
                SELECT id
                FROM users
                WHERE id = ? AND role = ? AND is_active = 1
            """, (personnel_id, personnel_role)).fetchone()
            if not personnel:
                flash("Select an active Teacher or Registrar Staff account.")
                return redirect(url_for("registrar_dashboard"))
            if not personnel_slot_is_available(
                db,
                personnel_id,
                personnel_role,
                appointment["appointment_date"],
                appointment["appointment_time"],
                exclude_appointment_id=appointment_id,
            ):
                flash(
                    "The selected personnel member is unavailable at that time. "
                    "Check their schedule and assigned appointments."
                )
                return redirect(url_for("registrar_dashboard"))

        previous_id = appointment["assigned_personnel_id"]
        previous_role = appointment["assigned_personnel_role"]
        assignment_status = (
            "Unassigned" if personnel_id is None
            else "Reassigned" if previous_id is not None
            else "Assigned"
        )
        db.execute("""
            UPDATE appointments
            SET assigned_personnel_id = ?,
                assigned_personnel_role = ?,
                assigned_teacher_id = ?,
                assignment_status = ?
            WHERE id = ?
        """, (
            personnel_id,
            personnel_role if personnel_id is not None else None,
            personnel_id if personnel_role == "Teacher" else None,
            assignment_status,
            appointment_id,
        ))
        event_type = (
            "unassigned" if personnel_id is None
            else "reassigned" if previous_id is not None
            else "assigned"
        )
        assignment_event_id = log_appointment_event(
            db,
            appointment_id,
            session["user_id"],
            event_type,
            previous_status=appointment["status"],
            new_status=appointment["status"],
            previous_assigned_teacher_id=(
                previous_id if previous_role == "Teacher" else None
            ),
            new_assigned_teacher_id=(
                personnel_id if personnel_role == "Teacher" else None
            ),
            previous_assigned_personnel_id=previous_id,
            new_assigned_personnel_id=personnel_id,
            previous_assigned_personnel_role=previous_role,
            new_assigned_personnel_role=personnel_role,
        )
        if personnel_id is not None:
            _create_notification(
                db,
                personnel_id,
                f"Appointment {appointment['reference_number']} was assigned to you.",
                url_for("teacher_dashboard")
                if personnel_role == "Teacher"
                else url_for("registrar_dashboard"),
                category="appointment",
                title="Appointment assigned",
                related_type="appointment",
                related_id=appointment_id,
                dedupe_key=f"appointment-event:{assignment_event_id}:assignment:{personnel_id}:{personnel_role}",
            )
        if previous_id is not None and previous_id != personnel_id:
            _create_notification(
                db,
                previous_id,
                f"Appointment {appointment['reference_number']} is no longer assigned to you.",
                url_for("teacher_dashboard")
                if previous_role == "Teacher"
                else url_for("registrar_dashboard"),
                category="appointment",
                title="Appointment assignment changed",
                related_type="appointment",
                related_id=appointment_id,
                dedupe_key=f"appointment-event:{assignment_event_id}:unassigned:{previous_id}:{previous_role}",
            )
        _create_notification(
            db,
            appointment["user_id"],
            (
                f"Appointment {appointment['reference_number']} was assigned."
                if personnel_id is not None
                else f"Assignment removed from appointment {appointment['reference_number']}."
            ),
            url_for("dashboard"),
            category="appointment",
            title="Appointment assignment updated",
            related_type="appointment",
            related_id=appointment_id,
            dedupe_key=f"appointment-event:{assignment_event_id}:student-assignment:{personnel_id}:{personnel_role}",
        )

    flash("Appointment assignment updated.")
    return redirect(url_for("registrar_dashboard"))


@app.route("/teacher/availability", methods=["POST"])
@role_required("Teacher")
def update_teacher_availability():
    return _save_personnel_availability("Teacher")


@app.route("/registrar/availability", methods=["POST"])
@role_required("Registrar Staff")
def update_registrar_availability():
    return _save_personnel_availability("Registrar Staff")


def _save_personnel_availability(personnel_role):
    weekday_values = request.form.getlist("weekdays")
    try:
        weekdays = {int(value) for value in weekday_values}
    except ValueError:
        abort(400)
    if any(weekday < 0 or weekday > 5 for weekday in weekdays):
        abort(400)

    start_text = request.form.get("start_time", "")
    end_text = request.form.get("end_time", "")
    try:
        start = datetime.strptime(start_text, "%H:%M").time()
        end = datetime.strptime(end_text, "%H:%M").time()
    except ValueError:
        flash("Enter valid availability start and end times.")
        return redirect(url_for(staff_dashboard_endpoint()))

    opening = time(8, 0)
    closing = time(17, 0)
    if (
        start >= end
        or start < opening
        or end > closing
        or start.minute not in {0, 30}
        or end.minute not in {0, 30}
    ):
        flash(
            "Availability must use 30-minute increments between 8:00 AM and 5:00 PM."
        )
        return redirect(url_for(staff_dashboard_endpoint()))

    personnel_id = session["user_id"]
    start_value = start.strftime("%H:%M")
    end_value = end.strftime("%H:%M")
    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        unavailable_dates = {
            row["unavailable_date"]
            for row in db.execute("""
                SELECT unavailable_date
                FROM personnel_unavailable_dates
                WHERE personnel_id = ? AND personnel_role = ?
            """, (personnel_id, personnel_role)).fetchall()
        }
        upcoming_appointments = db.execute("""
            SELECT appointment_date, appointment_time
            FROM appointments
            WHERE assigned_personnel_id = ?
              AND assigned_personnel_role = ?
              AND status != 'Cancelled'
              AND appointment_date >= ?
        """, (
            personnel_id, personnel_role, date.today().isoformat()
        )).fetchall()
        for appointment in upcoming_appointments:
            appointment_date = date.fromisoformat(appointment["appointment_date"])
            appointment_end = (
                datetime.strptime(appointment["appointment_time"], "%H:%M")
                + timedelta(minutes=30)
            ).strftime("%H:%M")
            if (
                appointment_date.weekday() not in weekdays
                or appointment["appointment_date"] in unavailable_dates
                or appointment["appointment_time"] < start_value
                or appointment_end > end_value
            ):
                flash(
                    "Availability cannot be changed because it would exclude "
                    "an upcoming assigned appointment."
                )
                return redirect(url_for(staff_dashboard_endpoint()))

        db.execute("""
            DELETE FROM personnel_availability
            WHERE personnel_id = ? AND personnel_role = ?
        """, (personnel_id, personnel_role))
        db.executemany("""
            INSERT INTO personnel_availability (
                personnel_id, personnel_role, weekday, start_time, end_time
            )
            VALUES (?, ?, ?, ?, ?)
        """, [
            (personnel_id, personnel_role, weekday, start_value, end_value)
            for weekday in sorted(weekdays)
        ])
        if personnel_role == "Teacher":
            db.execute(
                "DELETE FROM teacher_availability WHERE teacher_id = ?",
                (personnel_id,),
            )
            db.executemany("""
                INSERT INTO teacher_availability (
                    teacher_id, weekday, start_time, end_time
                )
                VALUES (?, ?, ?, ?)
            """, [
                (personnel_id, weekday, start_value, end_value)
                for weekday in sorted(weekdays)
            ])

    flash("Weekly availability saved.")
    return redirect(url_for(
        "teacher_dashboard" if personnel_role == "Teacher"
        else "registrar_dashboard"
    ))


@app.route("/teacher/unavailable-dates", methods=["POST"])
@role_required("Teacher", "Registrar Staff")
def add_teacher_unavailable_date():
    unavailable_date = request.form.get("unavailable_date", "").strip()
    note = request.form.get("note", "").strip()
    try:
        chosen_date = date.fromisoformat(unavailable_date)
    except ValueError:
        flash("Choose a valid unavailable date.")
        return redirect(url_for(staff_dashboard_endpoint()))
    if chosen_date < date.today() or len(note) > 200:
        flash("Choose a future date and keep the note within 200 characters.")
        return redirect(url_for(staff_dashboard_endpoint()))

    personnel_id = session["user_id"]
    personnel_role = session["user_role"]
    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        appointment = db.execute("""
            SELECT 1
            FROM appointments
            WHERE assigned_personnel_id = ?
              AND assigned_personnel_role = ?
              AND appointment_date = ?
              AND status != 'Cancelled'
            LIMIT 1
        """, (personnel_id, personnel_role, unavailable_date)).fetchone()
        if appointment:
            flash(
                "The date cannot be blocked because an appointment is already assigned."
            )
            return redirect(url_for(staff_dashboard_endpoint()))
        try:
            db.execute("""
                INSERT INTO personnel_unavailable_dates (
                    personnel_id, personnel_role, unavailable_date, note
                )
                VALUES (?, ?, ?, ?)
            """, (
                personnel_id, personnel_role, unavailable_date, note or None
            ))
            if personnel_role == "Teacher":
                db.execute("""
                    INSERT INTO teacher_unavailable_dates (
                        teacher_id, unavailable_date, note
                    )
                    VALUES (?, ?, ?)
                """, (personnel_id, unavailable_date, note or None))
        except sqlite3.IntegrityError:
            flash("That date is already marked unavailable.")
            return redirect(url_for(staff_dashboard_endpoint()))

    flash("Unavailable date added.")
    return redirect(url_for(staff_dashboard_endpoint()))


@app.route(
    "/teacher/unavailable-dates/<int:unavailable_id>/delete",
    methods=["POST"],
)
@role_required("Teacher", "Registrar Staff")
def delete_teacher_unavailable_date(unavailable_id):
    with get_db() as db:
        if session["user_role"] == "Teacher":
            target = db.execute("""
                SELECT unavailable_date FROM teacher_unavailable_dates
                WHERE id = ? AND teacher_id = ?
            """, (unavailable_id, session["user_id"])).fetchone()
            if not target:
                abort(404)
            db.execute("""
                DELETE FROM personnel_unavailable_dates
                WHERE personnel_id = ? AND personnel_role = 'Teacher'
                  AND unavailable_date = ?
            """, (session["user_id"], target["unavailable_date"]))
            result = db.execute("""
                DELETE FROM teacher_unavailable_dates
                WHERE id = ? AND teacher_id = ?
            """, (unavailable_id, session["user_id"]))
        else:
            result = db.execute("""
                DELETE FROM personnel_unavailable_dates
                WHERE id = ? AND personnel_id = ?
                  AND personnel_role = 'Registrar Staff'
            """, (unavailable_id, session["user_id"]))
    if not result.rowcount:
        abort(404)
    flash("Unavailable date removed.")
    return redirect(url_for(staff_dashboard_endpoint()))


@app.route("/admin")
@role_required("Admin")
def admin_dashboard():
    with get_db() as db:
        services = [
            row["service"] for row in db.execute(
                "SELECT DISTINCT service FROM appointments ORDER BY service COLLATE NOCASE"
            ).fetchall()
        ]
        appointment_conditions, appointment_params, appointment_filters, appointment_order = (
            _appointment_filters(
                request.args,
                (
                    "a.id", "a.reference_number", "u.name", "u.first_name",
                    "u.last_name", "u.middle_initial", "u.student_number",
                    "a.service", "a.reason", "p.name", "p.first_name",
                    "p.last_name", "a.appointment_date",
                    "a.appointment_time", "a.status",
                ),
                services,
                allow_personnel=True,
            )
        )
        appointments, appointment_pagination = _paginate_query(
            db,
            f"""SELECT a.id, a.reference_number, a.service, a.reason,
                      a.appointment_date, a.appointment_time, a.campus, a.status,
                      a.assigned_teacher_id, a.rejection_reason,
                      a.assigned_personnel_id, a.assigned_personnel_role,
                      a.assignment_status,
                      {_full_name_sql('u')} AS student_name, u.student_number,
                      {_full_name_sql('p')} AS teacher_name,
                      {_full_name_sql('p')} AS assigned_personnel_name""",
            """FROM appointments a
               JOIN users u ON u.id = a.user_id
               LEFT JOIN users p ON p.id = a.assigned_personnel_id""",
            appointment_conditions,
            appointment_params,
            appointment_order,
            anchor="appointments",
        )
        user_conditions, user_params, user_filters, user_order = _user_filters(
            request.args,
            ("u.id", "u.name", "u.first_name", "u.last_name", "u.middle_initial",
             "u.student_number", "u.email", "u.mobile", "u.role"),
            USER_SORTS,
            "users",
            roles=("Student", "Teacher", "Registrar Staff", "Admin"),
        )
        users, user_pagination = _paginate_query(
            db,
            f"""SELECT u.id, {_full_name_sql('u')} AS name,
                      u.first_name, u.last_name, u.middle_initial,
                      u.name_review_required, u.name AS legacy_name,
                      u.email, u.mobile, u.role,
                      u.student_number, u.is_active, u.profile_image,
                      (SELECT COUNT(*) FROM appointments a
                       WHERE a.assigned_personnel_id = u.id
                         AND a.assigned_personnel_role = u.role
                         AND a.status != 'Cancelled') AS assigned_appointments""",
            "FROM users u",
            user_conditions,
            user_params,
            user_order,
            page_param="user_page",
            anchor="accounts",
        )
        teachers = db.execute(f"""
            SELECT id, role, {_full_name_sql('users')} AS name,
                   first_name, last_name, middle_initial
            FROM users WHERE role IN ('Teacher', 'Registrar Staff') AND is_active = 1
            ORDER BY last_name COLLATE NOCASE, first_name COLLATE NOCASE, name COLLATE NOCASE
        """).fetchall()
        events = db.execute("""
            SELECT e.id, e.event_type, e.previous_status, e.new_status,
                   e.previous_assigned_teacher_id, e.new_assigned_teacher_id,
                   e.previous_assigned_personnel_id,
                   e.new_assigned_personnel_id,
                   e.previous_assigned_personnel_role,
                   e.new_assigned_personnel_role,
                   e.note, e.created_at, a.reference_number,
                   actor.name AS actor_name,
                   previous_personnel.name AS previous_teacher_name,
                   new_personnel.name AS new_teacher_name
            FROM appointment_events e
            JOIN appointments a ON a.id = e.appointment_id
            LEFT JOIN users actor ON actor.id = e.actor_user_id
            LEFT JOIN users previous_personnel
                ON previous_personnel.id = e.previous_assigned_personnel_id
            LEFT JOIN users new_personnel
                ON new_personnel.id = e.new_assigned_personnel_id
            ORDER BY e.id DESC
            LIMIT 100
        """).fetchall()
        profile_requests = [
            _profile_request_for_template(row)
            for row in db.execute(f"""
                SELECT r.*, {_full_name_sql('u')} AS requester_name,
                       u.role AS requester_role
                FROM profile_change_requests r
                JOIN users u ON u.id = r.user_id
                WHERE r.status = 'Pending Administrator Review'
                  AND r.user_id != ?
                ORDER BY r.submitted_at, r.id
                LIMIT 100
            """, (session["user_id"],)).fetchall()
        ]
        account_events = db.execute("""
            SELECT e.id, e.event_type, e.previous_values, e.new_values,
                   e.reason, e.created_at,
                   actor.name AS actor_name, affected.name AS affected_name
            FROM account_events e
            LEFT JOIN users actor ON actor.id = e.actor_user_id
            LEFT JOIN users affected ON affected.id = e.affected_user_id
            ORDER BY e.id DESC
            LIMIT 100
        """).fetchall()

    return render_template(
        "admin_dashboard.html",
        users=users,
        user_pagination=user_pagination,
        user_filters=user_filters,
        appointments=appointments,
        appointment_pagination=appointment_pagination,
        appointment_filters=appointment_filters,
        services=services,
        teachers=teachers,
        events=events,
        profile_requests=profile_requests,
        account_events=account_events,
        roles=("Student", "Teacher", "Registrar Staff", "Admin"),
        statuses=("Pending", "Approved", "Rejected", "Cancelled"),
    )


@app.route("/admin/users", methods=["POST"])
@role_required("Admin")
def admin_create_user():
    name_parts = _normalized_name_parts(request.form)
    email = request.form.get("email", "").strip().lower()
    mobile = request.form.get("mobile", "").strip()
    student_number = request.form.get("student_number", "").strip()
    password = request.form.get("password", "")
    role = request.form.get("role", "")
    valid_roles = {"Student", "Teacher", "Registrar Staff", "Admin"}

    if (
        not name_parts or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email)
        or len(email) > 254
        or len(mobile) > 20 or role not in valid_roles or len(password) < 8
    ):
        flash("Check the account details. Passwords must be at least 8 characters.")
        return redirect(url_for("admin_dashboard"))
    if mobile and not mobile.replace("+", "").isdigit():
        flash("Enter a valid mobile number.")
        return redirect(url_for("admin_dashboard"))
    if role == "Student" and not student_number:
        flash("Student accounts require a student number.")
        return redirect(url_for("admin_dashboard"))
    if student_number and (
        len(student_number) > 30
        or not re.fullmatch(r"[0-9]+-[0-9]+", student_number)
    ):
        flash("Enter a valid student number using numbers and one dash.")
        return redirect(url_for("admin_dashboard"))

    last_name, first_name, middle_initial = name_parts
    name = _format_full_name(last_name, first_name, middle_initial)
    try:
        with get_db() as db:
            cursor = db.execute("""
                INSERT INTO users
                    (name, first_name, last_name, middle_initial,
                     name_review_required, email, mobile, password_hash,
                     role, student_number)
                VALUES (?, ?, ?, ?, 0, ?, ?, ?, ?, ?)
            """, (
                name, first_name, last_name, middle_initial or None, email,
                mobile or None, generate_password_hash(password), role,
                student_number or None,
            ))
            _log_account_event(
                db, session["user_id"], cursor.lastrowid, "account_created",
                new_values={
                    "name": name, "email": email, "mobile": mobile or None,
                    "role": role, "student_number": student_number or None,
                },
            )
            _create_notification(
                db,
                cursor.lastrowid,
                "Your account has been created. Sign in to view your account.",
                url_for("login"),
                category="account",
                title="Account created",
                related_type="user",
                related_id=cursor.lastrowid,
            )
            _notify_role(
                db, "Admin",
                "An Administrator created an account.",
                url_for("admin_dashboard") + "#activity",
                category="account",
                title="Account created",
                related_type="user",
                related_id=cursor.lastrowid,
                exclude_user_ids=(session["user_id"], cursor.lastrowid),
            )
    except sqlite3.IntegrityError:
        flash("That email, mobile number, or student number is already registered.")
        return redirect(url_for("admin_dashboard"))

    flash("User account created.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/users/<int:user_id>/edit", methods=["POST"])
@role_required("Admin")
def admin_edit_user(user_id):
    if any(field in request.form for field in (
        "name", "first_name", "last_name", "middle_initial", "email",
        "student_number",
    )):
        abort(400, description="Sensitive profile fields require an approval request.")
    mobile = request.form.get("mobile", "").strip()
    role = request.form.get("role", "").strip()
    allowed_roles = {"Student", "Teacher", "Registrar Staff", "Admin"}

    if role not in allowed_roles:
        flash("Choose a valid account role.")
        return redirect(url_for("admin_dashboard"))
    if len(mobile) > 20 or (mobile and not mobile.replace("+", "").isdigit()):
        flash("Enter a valid mobile number.")
        return redirect(url_for("admin_dashboard"))

    try:
        with get_db() as db:
            db.execute("BEGIN IMMEDIATE")
            user = db.execute(
                "SELECT role, is_active, student_number, mobile FROM users WHERE id = ?",
                (user_id,),
            ).fetchone()
            if not user:
                abort(404)
            if user_id == session["user_id"] and role != user["role"]:
                flash("You cannot change your own account role.")
                return redirect(url_for("admin_dashboard"))
            if (
                user["role"] == "Admin"
                and user["is_active"]
                and role != "Admin"
            ):
                admin_count = db.execute(
                    "SELECT COUNT(*) FROM users WHERE role = 'Admin' AND is_active = 1"
                ).fetchone()[0]
                if admin_count <= 1:
                    flash("The last active admin account cannot be demoted.")
                    return redirect(url_for("admin_dashboard"))
            if role == "Student" and not user["student_number"]:
                flash("Student accounts require a student number.")
                return redirect(url_for("admin_dashboard"))
            if role != user["role"]:
                assigned_count = db.execute("""
                    SELECT COUNT(*) FROM appointments
                    WHERE assigned_personnel_id = ?
                      AND assigned_personnel_role = ?
                      AND status != 'Cancelled'
                """, (user_id, user["role"])).fetchone()[0]
                if assigned_count:
                    flash("Unassign or reassign this account's appointments before changing its role.")
                    return redirect(url_for("admin_dashboard"))
                personnel_roles = {"Teacher", "Registrar Staff"}
                if user["role"] in personnel_roles and role in personnel_roles:
                    db.execute("""
                        UPDATE personnel_availability
                        SET personnel_role = ?
                        WHERE personnel_id = ? AND personnel_role = ?
                    """, (role, user_id, user["role"]))
                    db.execute("""
                        UPDATE personnel_unavailable_dates
                        SET personnel_role = ?
                        WHERE personnel_id = ? AND personnel_role = ?
                    """, (role, user_id, user["role"]))
                elif user["role"] in personnel_roles:
                    db.execute("""
                        DELETE FROM personnel_availability WHERE personnel_id = ?
                    """, (user_id,))
                    db.execute("""
                        DELETE FROM personnel_unavailable_dates WHERE personnel_id = ?
                    """, (user_id,))
                if user["role"] == "Teacher":
                    db.execute(
                        "DELETE FROM teacher_availability WHERE teacher_id = ?",
                        (user_id,),
                    )
                    db.execute(
                        "DELETE FROM teacher_unavailable_dates WHERE teacher_id = ?",
                        (user_id,),
                    )
                if role == "Teacher":
                    db.execute("""
                        INSERT OR IGNORE INTO teacher_availability (
                            teacher_id, weekday, start_time, end_time
                        )
                        SELECT personnel_id, weekday, start_time, end_time
                        FROM personnel_availability
                        WHERE personnel_id = ? AND personnel_role = 'Teacher'
                    """, (user_id,))
                    db.execute("""
                        INSERT OR IGNORE INTO teacher_unavailable_dates (
                            teacher_id, unavailable_date, note
                        )
                        SELECT personnel_id, unavailable_date, note
                        FROM personnel_unavailable_dates
                        WHERE personnel_id = ? AND personnel_role = 'Teacher'
                    """, (user_id,))
            db.execute("""
                UPDATE users
                SET mobile = ?, role = ?
                WHERE id = ?
            """, (mobile or None, role, user_id))
            if user["role"] != role or user["mobile"] != (mobile or None):
                _log_account_event(
                    db, session["user_id"], user_id, "account_access_updated",
                    previous_values={"role": user["role"], "mobile": user["mobile"]},
                    new_values={"role": role, "mobile": mobile or None},
                )
                _create_notification(
                    db, user_id,
                    "Your account role or contact details were updated by an Administrator.",
                    url_for("profile"),
                    category="account",
                    title="Account access updated",
                    related_type="user",
                    related_id=user_id,
                )
                _notify_role(
                    db, "Admin",
                    "An Administrator updated account access or contact details.",
                    url_for("admin_dashboard") + "#activity",
                    category="account",
                    title="Account access updated",
                    related_type="user",
                    related_id=user_id,
                    exclude_user_ids=(session["user_id"], user_id),
                )
    except sqlite3.IntegrityError:
        flash("That email, mobile number, or student number is already registered.")
        return redirect(url_for("admin_dashboard"))

    flash("User account updated.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/users/<int:user_id>/active", methods=["POST"])
@role_required("Admin")
def admin_set_user_active(user_id):
    if user_id == session["user_id"]:
        flash("You cannot suspend your own account.")
        return redirect(url_for("admin_dashboard"))

    active = request.form.get("active") == "1"
    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        user = db.execute(
            "SELECT id, role, is_active FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        if not user:
            abort(404)
        if bool(user["is_active"]) == active:
            flash("That account already has the selected status.")
            return redirect(url_for("admin_dashboard"))
        if not active and user["role"] == "Admin":
            admin_count = db.execute(
                "SELECT COUNT(*) FROM users WHERE role = 'Admin' AND is_active = 1"
            ).fetchone()[0]
            if admin_count <= 1:
                flash("The last active admin cannot be suspended.")
                return redirect(url_for("admin_dashboard"))
        db.execute(
            "UPDATE users SET is_active = ? WHERE id = ?",
            (1 if active else 0, user_id)
        )
        _log_account_event(
            db, session["user_id"], user_id,
            "account_reactivated" if active else "account_suspended",
            previous_values={"is_active": user["is_active"]},
            new_values={"is_active": 1 if active else 0},
        )
        _create_notification(
            db, user_id,
            "Your account was reactivated by an Administrator."
            if active else "Your account was suspended by an Administrator.",
            url_for("login") if active else None,
            category="account",
            title="Account reactivated" if active else "Account suspended",
            related_type="user",
            related_id=user_id,
        )
        _notify_role(
            db, "Admin",
            "An Administrator reactivated an account."
            if active else "An Administrator suspended an account.",
            url_for("admin_dashboard") + "#activity",
            category="account",
            title="Account status updated",
            related_type="user",
            related_id=user_id,
            exclude_user_ids=(session["user_id"], user_id),
        )

    flash("User account reactivated." if active else "User account suspended.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/users/<int:user_id>/delete", methods=["POST"])
@role_required("Admin")
def admin_delete_user(user_id):
    if user_id == session["user_id"]:
        flash("You cannot delete your own account.")
        return redirect(url_for("admin_dashboard"))

    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        user = db.execute(
            "SELECT id, role, name, email, student_number, is_active, profile_image "
            "FROM users WHERE id = ?",
            (user_id,)
        ).fetchone()
        if not user:
            abort(404)
        if user["role"] == "Admin" and user["is_active"]:
            admin_count = db.execute(
                "SELECT COUNT(*) FROM users WHERE role = 'Admin' AND is_active = 1"
            ).fetchone()[0]
            if admin_count <= 1:
                flash("The last admin account cannot be deleted.")
                return redirect(url_for("admin_dashboard"))
        assigned_appointments = db.execute("""
            SELECT id, user_id, reference_number, assigned_personnel_role
            FROM appointments
            WHERE assigned_personnel_id = ?
        """, (user_id,)).fetchall()
        for appointment in assigned_appointments:
            db.execute("""
                UPDATE appointments
                SET assigned_teacher_id = NULL,
                    assigned_personnel_id = NULL,
                    assigned_personnel_role = NULL,
                    assignment_status = 'Unassigned'
                WHERE id = ?
            """, (appointment["id"],))
            assignment_event_id = log_appointment_event(
                db, appointment["id"], session["user_id"],
                "personnel_deleted_unassigned",
                previous_assigned_teacher_id=(
                    user_id if appointment["assigned_personnel_role"] == "Teacher"
                    else None
                ),
                new_assigned_teacher_id=None,
                previous_assigned_personnel_id=user_id,
                new_assigned_personnel_id=None,
                previous_assigned_personnel_role=appointment["assigned_personnel_role"],
                new_assigned_personnel_role=None,
            )
            _create_notification(
                db, appointment["user_id"],
                f"Appointment {appointment['reference_number']} is now unassigned.",
                url_for("dashboard"),
                category="appointment",
                title="Appointment assignment changed",
                related_type="appointment",
                related_id=appointment["id"],
                dedupe_key=f"appointment-event:{assignment_event_id}:personnel-deleted",
            )
        db.execute("DELETE FROM appointments WHERE user_id = ?", (user_id,))
        _log_account_event(
            db, session["user_id"], user_id, "account_deleted",
            previous_values={
                "name": user["name"], "email": user["email"],
                "role": user["role"], "student_number": user["student_number"],
                "is_active": user["is_active"],
            },
        )
        _notify_role(
            db, "Admin",
            "An Administrator deleted an account.",
            url_for("admin_dashboard") + "#activity",
            category="account",
            title="Account deleted",
            related_type="user",
            related_id=user_id,
            exclude_user_id=session["user_id"],
        )
        db.execute("DELETE FROM users WHERE id = ?", (user_id,))

    if user["profile_image"] and os.path.basename(user["profile_image"]) == user["profile_image"]:
        photo_path = os.path.join(PROFILE_PHOTO_FOLDER, user["profile_image"])
        if os.path.isfile(photo_path):
            os.remove(photo_path)
    flash("User and their appointment records were permanently deleted.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/users/<int:user_id>/role", methods=["POST"])
@role_required("Admin")
def admin_update_user_role(user_id):
    allowed_roles = {"Student", "Teacher", "Registrar Staff", "Admin"}
    new_role = request.form.get("role", "")
    if new_role not in allowed_roles:
        abort(400)
    if user_id == session["user_id"]:
        flash("You cannot change your own account role.")
        return redirect(url_for("admin_dashboard"))

    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        user = db.execute(
            "SELECT id, role, is_active, student_number "
            "FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        if not user:
            abort(404)

        if user["role"] == "Admin" and user["is_active"] and new_role != "Admin":
            admin_count = db.execute(
                "SELECT COUNT(*) FROM users WHERE role = 'Admin' AND is_active = 1"
            ).fetchone()[0]
            if admin_count <= 1:
                flash("The last admin account cannot be demoted.")
                return redirect(url_for("admin_dashboard"))

        if new_role == "Student" and not user["student_number"]:
            flash("A Student account must have a student number before changing its role.")
            return redirect(url_for("admin_dashboard"))
        if new_role != user["role"]:
            assigned_count = db.execute("""
                SELECT COUNT(*) FROM appointments
                WHERE assigned_personnel_id = ?
                  AND assigned_personnel_role = ?
                  AND status != 'Cancelled'
            """, (user_id, user["role"])).fetchone()[0]
            if assigned_count:
                flash("Unassign or reassign this account's appointments before changing its role.")
                return redirect(url_for("admin_dashboard"))
            personnel_roles = {"Teacher", "Registrar Staff"}
            if user["role"] in personnel_roles and new_role in personnel_roles:
                db.execute("""
                    UPDATE personnel_availability SET personnel_role = ?
                    WHERE personnel_id = ? AND personnel_role = ?
                """, (new_role, user_id, user["role"]))
                db.execute("""
                    UPDATE personnel_unavailable_dates SET personnel_role = ?
                    WHERE personnel_id = ? AND personnel_role = ?
                """, (new_role, user_id, user["role"]))
            elif user["role"] in personnel_roles:
                db.execute(
                    "DELETE FROM personnel_availability WHERE personnel_id = ?",
                    (user_id,),
                )
                db.execute(
                    "DELETE FROM personnel_unavailable_dates WHERE personnel_id = ?",
                    (user_id,),
                )
            if user["role"] == "Teacher":
                db.execute("DELETE FROM teacher_availability WHERE teacher_id = ?", (user_id,))
                db.execute("DELETE FROM teacher_unavailable_dates WHERE teacher_id = ?", (user_id,))
            if new_role == "Teacher":
                db.execute("""
                    INSERT OR IGNORE INTO teacher_availability (
                        teacher_id, weekday, start_time, end_time
                    )
                    SELECT personnel_id, weekday, start_time, end_time
                    FROM personnel_availability
                    WHERE personnel_id = ? AND personnel_role = 'Teacher'
                """, (user_id,))
                db.execute("""
                    INSERT OR IGNORE INTO teacher_unavailable_dates (
                        teacher_id, unavailable_date, note
                    )
                    SELECT personnel_id, unavailable_date, note
                    FROM personnel_unavailable_dates
                    WHERE personnel_id = ? AND personnel_role = 'Teacher'
                """, (user_id,))
        db.execute("UPDATE users SET role = ? WHERE id = ?", (new_role, user_id))
        if new_role != user["role"]:
            _log_account_event(
                db, session["user_id"], user_id, "account_role_updated",
                previous_values={"role": user["role"]},
                new_values={"role": new_role},
            )
            _create_notification(
                db, user_id,
                "Your account role was updated by an Administrator.",
                url_for("profile"),
                category="account",
                title="Account role updated",
                related_type="user",
                related_id=user_id,
            )
            _notify_role(
                db, "Admin",
                "An Administrator updated an account role.",
                url_for("admin_dashboard") + "#activity",
                category="account",
                title="Account role updated",
                related_type="user",
                related_id=user_id,
                exclude_user_ids=(session["user_id"], user_id),
            )

    flash("User role updated.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/appointments/<int:appointment_id>/status", methods=["POST"])
@role_required("Admin")
def admin_update_appointment_status(appointment_id):
    allowed_statuses = {"Pending", "Approved", "Rejected", "Cancelled"}
    new_status = request.form.get("status", "")
    rejection_reason = request.form.get("rejection_reason", "").strip()
    if new_status not in allowed_statuses:
        abort(400)
    if new_status == "Rejected" and (
        not rejection_reason or len(rejection_reason) > 1000
    ):
        flash("Enter a rejection reason of no more than 1000 characters.")
        return redirect(url_for("admin_dashboard"))
    if new_status != "Rejected":
        rejection_reason = ""

    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        appointment = db.execute(
            """
            SELECT id, status, appointment_date, appointment_time,
                   user_id, reference_number, assigned_personnel_id,
                   assigned_personnel_role, rejection_reason
            FROM appointments
            WHERE id = ?
            """,
            (appointment_id,)
        ).fetchone()
        if not appointment:
            abort(404)
        if (
            appointment["status"] == new_status
            and appointment["rejection_reason"] == (rejection_reason or None)
        ):
            flash("That appointment already has the selected status.")
            return redirect(url_for("admin_dashboard"))

        if new_status != "Cancelled":
            conflict = db.execute("""
                SELECT id FROM appointments
                WHERE appointment_date = ?
                  AND appointment_time = ?
                  AND status != 'Cancelled'
                  AND id != ?
                LIMIT 1
            """, (
                appointment["appointment_date"],
                appointment["appointment_time"],
                appointment_id,
            )).fetchone()
            if conflict:
                flash("That time slot is already occupied by another appointment.")
                return redirect(url_for("admin_dashboard"))

        db.execute("""
            UPDATE appointments
            SET status = ?, rejection_reason = ?
            WHERE id = ?
        """, (new_status, rejection_reason or None, appointment_id))
        status_event_id = log_appointment_event(
            db,
            appointment_id,
            session["user_id"],
            "status_changed",
            previous_status=appointment["status"],
            new_status=new_status,
            previous_assigned_teacher_id=(
                appointment["assigned_personnel_id"]
                if appointment["assigned_personnel_role"] == "Teacher" else None
            ),
            new_assigned_teacher_id=(
                appointment["assigned_personnel_id"]
                if appointment["assigned_personnel_role"] == "Teacher" else None
            ),
            previous_assigned_personnel_id=appointment["assigned_personnel_id"],
            new_assigned_personnel_id=appointment["assigned_personnel_id"],
            previous_assigned_personnel_role=appointment["assigned_personnel_role"],
            new_assigned_personnel_role=appointment["assigned_personnel_role"],
            note=rejection_reason or None,
        )
        _create_notification(
            db, appointment["user_id"],
            f"Appointment {appointment['reference_number']} status changed to {new_status}.",
            url_for("dashboard"),
            category="appointment",
            title="Appointment status updated",
            related_type="appointment",
            related_id=appointment_id,
            dedupe_key=f"appointment-event:{status_event_id}:status:{new_status}",
        )
        if (
            appointment["assigned_personnel_id"] is not None
            and appointment["assigned_personnel_id"] != session["user_id"]
        ):
            _create_notification(
                db,
                appointment["assigned_personnel_id"],
                f"Appointment {appointment['reference_number']} status changed to {new_status}.",
                url_for(
                    "teacher_dashboard"
                    if appointment["assigned_personnel_role"] == "Teacher"
                    else "registrar_dashboard"
                ),
                category="appointment",
                title="Assigned appointment status updated",
                related_type="appointment",
                related_id=appointment_id,
                dedupe_key=f"appointment-event:{status_event_id}:personnel-status",
            )

    flash("Appointment status updated.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/export/<dataset>.csv")
@role_required("Admin")
def admin_export_csv(dataset):
    exports = {
        "users": (
            "users.csv",
            ("ID", "Name", "Email", "Mobile", "Role", "Student Number", "Account Status"),
            f"""
                SELECT id, {_full_name_sql('users')}, email, mobile, role, student_number,
                       CASE WHEN is_active = 1 THEN 'Active' ELSE 'Suspended' END
                FROM users ORDER BY id
            """,
        ),
        "appointments": (
            "appointments.csv",
            (
                "ID", "Reference Number", "Student", "Student Number",
                "Service", "Reason", "Date", "Time", "Campus", "Status",
                "Assigned Teacher", "Rejection Reason"
            ),
            f"""
                SELECT a.id, a.reference_number, {_full_name_sql('u')}, u.student_number,
                       a.service, a.reason, a.appointment_date,
                       a.appointment_time, a.campus, a.status, {_full_name_sql('p')},
                       a.rejection_reason
                FROM appointments a
                JOIN users u ON u.id = a.user_id
                LEFT JOIN users p ON p.id = a.assigned_personnel_id
                ORDER BY a.id
            """,
        ),
    }
    if dataset not in exports:
        abort(404)

    filename, headers, query = exports[dataset]
    with get_db() as db:
        rows = db.execute(query).fetchall()

    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(headers)
    for row in rows:
        writer.writerow([
            "'" + str(value) if value is not None and str(value).startswith(
                ("=", "+", "-", "@", "\t", "\r")
            ) else value
            for value in row
        ])

    return Response(
        output.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


# Registrar Staff can approve any pending appointment; Teachers can approve
# only appointments assigned to them.
@app.route("/registrar/approve/<int:appointment_id>", methods=["POST"])
@role_required("Registrar Staff", "Teacher")
def approve_appointment(appointment_id):
    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        appointment = db.execute("""
            SELECT status, assigned_personnel_id, assigned_personnel_role,
                   user_id, reference_number
            FROM appointments
            WHERE id = ?
        """, (appointment_id,)).fetchone()
        if not appointment:
            abort(404)
        if (
            session["user_role"] == "Teacher"
            and (
                appointment["assigned_personnel_id"] != session["user_id"]
                or appointment["assigned_personnel_role"] != "Teacher"
            )
        ):
            abort(403)
        if appointment["status"] != "Pending":
            flash("This appointment is no longer pending.")
            return redirect(url_for(staff_dashboard_endpoint()))
        db.execute("""
            UPDATE appointments
            SET status = 'Approved', rejection_reason = NULL
            WHERE id = ?
        """, (appointment_id,))
        approval_event_id = log_appointment_event(
            db,
            appointment_id,
            session["user_id"],
            "approved",
            previous_status=appointment["status"],
            new_status="Approved",
            previous_assigned_teacher_id=(
                appointment["assigned_personnel_id"]
                if appointment["assigned_personnel_role"] == "Teacher" else None
            ),
            new_assigned_teacher_id=(
                appointment["assigned_personnel_id"]
                if appointment["assigned_personnel_role"] == "Teacher" else None
            ),
            previous_assigned_personnel_id=appointment["assigned_personnel_id"],
            new_assigned_personnel_id=appointment["assigned_personnel_id"],
            previous_assigned_personnel_role=appointment["assigned_personnel_role"],
            new_assigned_personnel_role=appointment["assigned_personnel_role"],
        )
        _create_notification(
            db, appointment["user_id"],
            f"Appointment {appointment['reference_number']} was approved.",
            url_for("dashboard"),
            category="appointment",
            title="Appointment approved",
            related_type="appointment",
            related_id=appointment_id,
            dedupe_key=f"appointment-event:{approval_event_id}:status:Approved",
        )

    flash("Appointment approved successfully.")
    return redirect(url_for(staff_dashboard_endpoint()))


@app.route("/staff/appointments/<int:appointment_id>/reject", methods=["POST"])
@role_required("Registrar Staff", "Teacher")
def reject_appointment(appointment_id):
    reason = request.form.get("rejection_reason", "").strip()
    if not reason or len(reason) > 1000:
        flash("Enter a rejection reason of no more than 1000 characters.")
        return redirect(url_for(staff_dashboard_endpoint()))

    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        appointment = db.execute("""
            SELECT status, assigned_personnel_id, assigned_personnel_role,
                   user_id, reference_number
            FROM appointments
            WHERE id = ?
        """, (appointment_id,)).fetchone()
        if not appointment:
            abort(404)
        if (
            session["user_role"] == "Teacher"
            and (
                appointment["assigned_personnel_id"] != session["user_id"]
                or appointment["assigned_personnel_role"] != "Teacher"
            )
        ):
            abort(403)
        if appointment["status"] != "Pending":
            flash("This appointment is no longer pending.")
            return redirect(url_for(staff_dashboard_endpoint()))
        db.execute("""
            UPDATE appointments
            SET status = 'Rejected', rejection_reason = ?
            WHERE id = ?
        """, (reason, appointment_id))
        rejection_event_id = log_appointment_event(
            db,
            appointment_id,
            session["user_id"],
            "rejected",
            previous_status=appointment["status"],
            new_status="Rejected",
            previous_assigned_teacher_id=(
                appointment["assigned_personnel_id"]
                if appointment["assigned_personnel_role"] == "Teacher" else None
            ),
            new_assigned_teacher_id=(
                appointment["assigned_personnel_id"]
                if appointment["assigned_personnel_role"] == "Teacher" else None
            ),
            previous_assigned_personnel_id=appointment["assigned_personnel_id"],
            new_assigned_personnel_id=appointment["assigned_personnel_id"],
            previous_assigned_personnel_role=appointment["assigned_personnel_role"],
            new_assigned_personnel_role=appointment["assigned_personnel_role"],
            note=reason,
        )
        _create_notification(
            db, appointment["user_id"],
            f"Appointment {appointment['reference_number']} was rejected. Sign in to view details.",
            url_for("dashboard"),
            category="appointment",
            title="Appointment rejected",
            related_type="appointment",
            related_id=appointment_id,
            dedupe_key=f"appointment-event:{rejection_event_id}:status:Rejected",
        )

    flash("Appointment rejected.")
    return redirect(url_for(staff_dashboard_endpoint()))


# Dashboard
@app.route("/dashboard")
@role_required("Student")
def dashboard():
    with get_db() as db:
        student_id = session["user_id"]
        services = [
            row["service"] for row in db.execute("""
                SELECT DISTINCT service
                FROM appointments
                WHERE user_id = ?
                ORDER BY service COLLATE NOCASE
            """, (student_id,)).fetchall()
        ]
        conditions, params, filters, order_by = _appointment_filters(
            request.args,
            (
                "a.id", "a.reference_number", "u.name", "u.student_number",
                "u.first_name", "u.last_name", "u.middle_initial",
                "a.service", "a.reason", "p.name", "p.first_name",
                "p.last_name", "a.appointment_date",
                "a.appointment_time", "a.status",
            ),
            services,
            sort_options={
                "date_asc": APPOINTMENT_SORTS["date_asc"],
                "date_desc": APPOINTMENT_SORTS["date_desc"],
            },
        )
        conditions.insert(0, "a.user_id = :student_id")
        params["student_id"] = student_id
        appointments, appointment_pagination = _paginate_query(
            db,
            f"""SELECT a.*, {_full_name_sql('u')} AS student_name,
                      u.student_number, {_full_name_sql('p')} AS assigned_teacher_name,
                      {_full_name_sql('p')} AS assigned_personnel_name""",
            """FROM appointments a
               JOIN users u ON u.id = a.user_id
               LEFT JOIN users p ON p.id = a.assigned_personnel_id""",
            conditions,
            params,
            order_by,
            anchor="my-requests",
        )

    return render_template(
        "index.html",
        page="dashboard",
        appointments=appointments,
        services=services,
        statuses=APPOINTMENT_STATUSES,
        appointment_filters=filters,
        appointment_pagination=appointment_pagination,
        booking_services=SERVICES,
        today=date.today().isoformat()
    )


# Return available time slots for the selected date.
@app.route("/available-slots")
@role_required("Student")
def available_slots():
    date_text = request.args.get("date", "")
    try:
        chosen_date = date.fromisoformat(date_text)
    except ValueError:
        return jsonify({"slots": []})

    if chosen_date < date.today() or not is_valid_appointment_date(chosen_date):
        return jsonify({"slots": []})

    with get_db() as db:
        booked = {
            row["appointment_time"][:5]
            for row in db.execute(
                """
                SELECT appointment_time FROM appointments
                WHERE appointment_date = ?
                  AND status != 'Cancelled'
                """,
                (date_text,)
            ).fetchall()
        }

    slots = make_time_slots()
    if chosen_date == date.today():
        now = datetime.now().time()
        slots = [
            slot for slot in slots
            if datetime.strptime(slot, "%H:%M").time() > now
        ]

    return jsonify({"slots": [slot for slot in slots if slot not in booked]})


# Book an appointment
@app.route("/book", methods=["POST"])
@role_required("Student")
def book():
    service = request.form.get("service", "")
    appointment_date = request.form.get("appointment_date", "")
    appointment_time = request.form.get("appointment_time", "")
    reason = request.form.get("reason", "").strip()

    if service not in SERVICES:
        flash("Please select a valid service.")
        return redirect(url_for("dashboard"))

    try:
        chosen_date = date.fromisoformat(appointment_date)
    except ValueError:
        flash("Please select a valid appointment date.")
        return redirect(url_for("dashboard"))

    if chosen_date < date.today():
        flash("Please choose today or a future date.")
        return redirect(url_for("dashboard"))

    if not is_valid_appointment_date(chosen_date):
        flash("Appointments are available Monday through Saturday only.")
        return redirect(url_for("dashboard"))

    if appointment_time not in make_time_slots() or len(reason) > 1000 or not reason:
        flash("Please select a valid available time and enter your reason.")
        return redirect(url_for("dashboard"))

    if chosen_date == date.today():
        selected_time = datetime.strptime(appointment_time, "%H:%M").time()
        if selected_time <= datetime.now().time():
            flash("That time has already passed. Please choose another slot.")
            return redirect(url_for("dashboard"))

    try:
        with get_db() as db:
            # Lock writes while checking and reserving to prevent double booking.
            db.execute("BEGIN IMMEDIATE")
            occupied = db.execute(
                """
                SELECT id FROM appointments
                WHERE appointment_date = ?
                  AND appointment_time = ?
                  AND status != 'Cancelled'
                LIMIT 1
                """,
                (appointment_date, appointment_time)
            ).fetchone()

            if occupied:
                flash("Sorry, that time slot was just booked. Please choose another.")
                return redirect(url_for("dashboard"))

            
            
            reference_number = f"EDU-{secrets.token_hex(4).upper()}"
            verification_token = secrets.token_urlsafe(32)


            db.execute(
                """
                INSERT INTO appointments
                (
                    user_id,
                    service,
                    appointment_date,
                    appointment_time,
                    reason,
                    reference_number,
                    campus,
                    verification_token
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    session["user_id"],
                    service,
                    appointment_date,
                    appointment_time,
                    reason,
                    reference_number,
                    "Main Campus – Registrar's Office",
                    verification_token,
                ),
            )
            appointment_id = db.execute(
                "SELECT last_insert_rowid()"
            ).fetchone()[0]
            appointment_event_id = log_appointment_event(
                db,
                appointment_id,
                session["user_id"],
                "created",
                new_status="Pending",
                note=f"Service: {service}",
            )
            _create_notification(
                db,
                session["user_id"],
                f"Appointment {reference_number} was submitted and is awaiting review.",
                url_for("dashboard"),
                category="appointment",
                title="Appointment submitted",
                related_type="appointment",
                related_id=appointment_id,
                dedupe_key=f"appointment-event:{appointment_event_id}:student-created",
            )
            _notify_role(
                db,
                "Registrar Staff",
                "A new appointment is awaiting review and assignment.",
                url_for("registrar_dashboard") + "#appointments",
                category="appointment",
                title="New appointment request",
                related_type="appointment",
                related_id=appointment_id,
                dedupe_key=f"appointment-event:{appointment_event_id}:registrar-created",
            )
    except sqlite3.IntegrityError:
        flash("We couldn't save that appointment. Please try another slot.")
        return redirect(url_for("dashboard"))

    flash("Appointment submitted successfully!")
    return redirect(url_for("dashboard"))


# Cancel an appointment belonging to the logged-in user
@app.route("/cancel/<int:appointment_id>", methods=["POST"])
@role_required("Student")
def cancel(appointment_id):
    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        appointment = db.execute("""
            SELECT status, reference_number, assigned_personnel_id,
                   assigned_personnel_role
            FROM appointments
            WHERE id = ? AND user_id = ?
        """, (appointment_id, session["user_id"])).fetchone()
        if not appointment or appointment["status"] != "Pending":
            flash("Appointment could not be cancelled.")
            return redirect(url_for("dashboard"))
        result = db.execute(
            """
            UPDATE appointments
            SET status = 'Cancelled'
            WHERE id = ?
              AND user_id = ?
              AND status = 'Pending'
            """,
            (appointment_id, session["user_id"])
        )
        if result.rowcount:
            cancellation_event_id = log_appointment_event(
                db,
                appointment_id,
                session["user_id"],
                "cancelled",
                previous_status=appointment["status"],
                new_status="Cancelled",
                previous_assigned_teacher_id=(
                    appointment["assigned_personnel_id"]
                    if appointment["assigned_personnel_role"] == "Teacher" else None
                ),
                new_assigned_teacher_id=(
                    appointment["assigned_personnel_id"]
                    if appointment["assigned_personnel_role"] == "Teacher" else None
                ),
                previous_assigned_personnel_id=appointment["assigned_personnel_id"],
                new_assigned_personnel_id=appointment["assigned_personnel_id"],
                previous_assigned_personnel_role=appointment["assigned_personnel_role"],
                new_assigned_personnel_role=appointment["assigned_personnel_role"],
            )
            if appointment["assigned_personnel_id"]:
                _create_notification(
                    db,
                    appointment["assigned_personnel_id"],
                    f"Appointment {appointment['reference_number']} was cancelled.",
                    url_for(
                        "teacher_dashboard"
                        if appointment["assigned_personnel_role"] == "Teacher"
                        else "registrar_dashboard"
                    ),
                    category="appointment",
                    title="Assigned appointment cancelled",
                    related_type="appointment",
                    related_id=appointment_id,
                    dedupe_key=f"appointment-event:{cancellation_event_id}:assigned-cancelled",
                )
            _notify_role(
                db,
                "Registrar Staff",
                f"Appointment {appointment['reference_number']} was cancelled.",
                url_for("registrar_dashboard") + "#appointments",
                category="appointment",
                title="Appointment cancelled",
                related_type="appointment",
                related_id=appointment_id,
                dedupe_key=f"appointment-event:{cancellation_event_id}:registrar-cancelled",
                exclude_user_id=appointment["assigned_personnel_id"],
            )

    if result.rowcount:
        flash("Appointment cancelled.")
    else:
        flash("Appointment could not be cancelled.")

    return redirect(url_for("dashboard"))


# Account Profile
@app.route("/profile", methods=["GET", "POST"])
@role_required("Student", "Registrar Staff", "Teacher", "Admin")
def profile():
    user_id = session["user_id"]
    new_photo_name = None
    old_photo_name = None
    sanitized_photo_data = None

    if request.method == "POST":
        name_parts = _normalized_name_parts(request.form)
        name_fields_present = any(
            request.form.get(field, "").strip()
            for field in ("last_name", "first_name", "middle_initial")
        )
        email = request.form.get("email", "").strip().lower()
        mobile = request.form.get("mobile", "").strip()
        student_number = request.form.get("student_number", "").strip()
        photo = request.files.get("profile_image")
        photo_data = photo.read(MAX_PROFILE_PHOTO_BYTES + 1) if photo and photo.filename else None

        if email and (
            len(email) > 254
            or not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email)
        ):
            flash("Enter a valid email address.")
            return redirect(url_for("profile"))
        if len(mobile) > 20 or (mobile and not mobile.replace("+", "").isdigit()):
            flash("Enter a valid mobile number.")
            return redirect(url_for("profile"))
        if student_number and (
            len(student_number) > 30
            or not re.fullmatch(r"[0-9]+-[0-9]+", student_number)
        ):
            flash("Enter a valid student number using numbers and one dash.")
            return redirect(url_for("profile"))
        if photo_data:
            if len(photo_data) > MAX_PROFILE_PHOTO_BYTES:
                flash("Profile photos must be 3 MB or smaller.")
                return redirect(url_for("profile"))
            try:
                with Image.open(io.BytesIO(photo_data)) as image:
                    if image.format not in {"JPEG", "PNG", "WEBP"}:
                        raise ValueError("unsupported image format")
                    if image.width * image.height > 20_000_000:
                        raise ValueError("image dimensions are too large")
                    image.thumbnail((512, 512))
                    sanitized_photo = io.BytesIO()
                    image.convert("RGB").save(
                        sanitized_photo, format="JPEG", quality=88, optimize=True
                    )
            except (
                UnidentifiedImageError,
                OSError,
                ValueError,
                Image.DecompressionBombError,
            ):
                flash("Choose a valid JPG, PNG, or WebP image.")
                return redirect(url_for("profile"))
            os.makedirs(PROFILE_PHOTO_FOLDER, exist_ok=True)
            new_photo_name = f"{secrets.token_hex(16)}.jpg"
            sanitized_photo_data = sanitized_photo.getvalue()

        verification_token = None
        verification_email = None
        request_id = None
        try:
            with get_db() as db:
                db.execute("BEGIN IMMEDIATE")
                current = db.execute("""
                    SELECT id, name, first_name, last_name, middle_initial,
                           email, mobile, role, student_number, profile_image
                    FROM users WHERE id = ?
                """, (user_id,)).fetchone()
                if not current:
                    session.clear()
                    flash("Please log in again.")
                    return redirect(url_for("login"))

                if name_fields_present and not name_parts:
                    flash("Enter both first and last name to request a name change.")
                    return redirect(url_for("profile"))
                if current["role"] == "Student" and not (student_number or current["student_number"]):
                    flash("Student accounts require a student number.")
                    return redirect(url_for("profile"))
                if (
                    current["role"] != "Student"
                    and student_number
                    and student_number != (current["student_number"] or "")
                ):
                    flash("Only Student accounts can change a student number.")
                    return redirect(url_for("profile"))

                changes = {}
                if name_parts:
                    last_name, first_name, middle_initial = name_parts
                    proposed_name = {
                        "last_name": last_name,
                        "first_name": first_name,
                        "middle_initial": middle_initial or None,
                    }
                    current_name = {
                        "last_name": current["last_name"],
                        "first_name": current["first_name"],
                        "middle_initial": current["middle_initial"],
                    }
                    if proposed_name != current_name:
                        changes["name"] = proposed_name
                if email and email != current["email"].lower():
                    if email.endswith("@phone.local"):
                        flash("Use a personal email address.")
                        return redirect(url_for("profile"))
                    changes["email"] = {"email": email}
                if (
                    current["role"] == "Student"
                    and student_number
                    and student_number != (current["student_number"] or "")
                ):
                    changes["student_number"] = {"student_number": student_number}

                if changes:
                    duplicate = db.execute(
                        "SELECT id FROM profile_change_requests "
                        "WHERE user_id = ? AND status IN "
                        "('Pending Email Verification', 'Pending Registrar Review', "
                        "'Pending Administrator Review')",
                        (user_id,),
                    ).fetchone()
                    if duplicate:
                        flash("Withdraw your pending profile request before submitting another.")
                        return redirect(url_for("profile"))

                if changes:
                    if "student_number" in changes:
                        existing_student = db.execute("""
                            SELECT id FROM users WHERE student_number = ? AND id != ?
                        """, (changes["student_number"]["student_number"], user_id)).fetchone()
                        if existing_student:
                            flash("That student number is already in use.")
                            return redirect(url_for("profile"))
                    if "email" in changes:
                        existing_email = db.execute("""
                            SELECT id FROM users WHERE LOWER(email) = LOWER(?) AND id != ?
                        """, (changes["email"]["email"], user_id)).fetchone()
                        if existing_email:
                            flash("That email address is already in use.")
                            return redirect(url_for("profile"))

                if not changes and not new_photo_name and mobile == (current["mobile"] or ""):
                    flash("No profile changes were submitted.")
                    return redirect(url_for("profile"))
                if mobile != (current["mobile"] or ""):
                    db.execute(
                        "UPDATE users SET mobile = ? WHERE id = ?",
                        (mobile or None, user_id),
                    )
                    _log_account_event(
                        db, user_id, user_id, "mobile_updated",
                        previous_values={"mobile": current["mobile"]},
                        new_values={"mobile": mobile or None},
                    )
                if new_photo_name:
                    with open(
                        os.path.join(PROFILE_PHOTO_FOLDER, new_photo_name), "wb"
                    ) as image_file:
                        image_file.write(sanitized_photo_data)
                    db.execute(
                        "UPDATE users SET profile_image = ? WHERE id = ?",
                        (new_photo_name, user_id),
                    )
                    old_photo_name = current["profile_image"]

                if changes:
                    previous_values = {}
                    for group_name, proposed in changes.items():
                        if group_name == "name":
                            previous_values[group_name] = {
                                field: current[field] for field in PROFILE_CHANGE_GROUPS[group_name]
                            }
                        elif group_name == "email":
                            previous_values[group_name] = {"email": current["email"]}
                        else:
                            previous_values[group_name] = {
                                "student_number": current["student_number"]
                            }

                    if "email" in changes:
                        verification_token = secrets.token_urlsafe(32)
                        verification_email = changes["email"]["email"]
                        status = "Pending Email Verification"
                        token_hash = hashlib.sha256(
                            verification_token.encode("utf-8")
                        ).hexdigest()
                        expires_at = (_utc_now() + timedelta(hours=24)).isoformat()
                    else:
                        status = "Pending Registrar Review"
                        token_hash = None
                        expires_at = None
                    cursor = db.execute("""
                        INSERT INTO profile_change_requests (
                            user_id, previous_values, proposed_values,
                            changed_groups, status, email_verification_token_hash,
                            email_verification_expires_at
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?)
                    """, (
                        user_id,
                        json.dumps(previous_values, sort_keys=True),
                        json.dumps(changes, sort_keys=True),
                        json.dumps(sorted(changes)),
                        status,
                        token_hash,
                        expires_at,
                    ))
                    request_id = cursor.lastrowid
                    _log_account_event(
                        db, user_id, user_id, "profile_change_requested",
                        previous_values=previous_values,
                        new_values=changes,
                    )
                    if status == "Pending Registrar Review":
                        _create_notification(
                            db, user_id,
                            "Your profile change request is awaiting Registrar review.",
                            url_for("profile"),
                            category="profile",
                            title="Profile change submitted",
                            related_type="profile_change_request",
                            related_id=request_id,
                            dedupe_key=f"profile-request:{request_id}:submitted",
                        )
                        _notify_role(
                            db, "Registrar Staff",
                            "A profile change request is ready for review.",
                            url_for("registrar_dashboard") + "#profile-reviews",
                            category="profile",
                            title="Profile change review",
                            related_type="profile_change_request",
                            related_id=request_id,
                            dedupe_key=f"profile-request:{request_id}:registrar-review",
                            exclude_user_id=user_id,
                        )
        except sqlite3.IntegrityError:
            if new_photo_name:
                photo_path = os.path.join(PROFILE_PHOTO_FOLDER, new_photo_name)
                if os.path.isfile(photo_path):
                    os.remove(photo_path)
            flash("That email, mobile number, or student number is already in use.")
            return redirect(url_for("profile"))

        if verification_token and verification_email:
            verification_link = url_for(
                "verify_profile_email", token=verification_token, _external=True
            )
            try:
                _send_email(
                    verification_email,
                    "Verify your profile email change",
                    "Verify this email address for your School Appointment System "
                    f"profile change within 24 hours:\n\n{verification_link}",
                )
            except Exception:
                app.logger.exception("Could not send profile email verification")
                with get_db() as db:
                    db.execute("""
                        UPDATE profile_change_requests
                        SET status = 'Email Delivery Failed'
                        WHERE id = ? AND status = 'Pending Email Verification'
                    """, (request_id,))
                    _log_account_event(
                        db, user_id, user_id, "profile_verification_delivery_failed",
                        new_values={"request_id": request_id},
                    )
                flash("The request was not submitted because the verification email could not be sent. Check email settings or try again.")
            else:
                with get_db() as db:
                    _create_notification(
                        db, user_id,
                        "Your profile change request is awaiting email verification.",
                        url_for("profile"),
                        category="profile",
                        title="Verify your profile change",
                        related_type="profile_change_request",
                        related_id=request_id,
                        dedupe_key=f"profile-request:{request_id}:submitted",
                    )
                flash("Profile change submitted. Check the new email for a verification link.")
        elif request_id:
            flash("Profile change submitted for Registrar Staff and Administrator review.")
        else:
            flash("Profile updated.")

        if old_photo_name and os.path.basename(old_photo_name) == old_photo_name:
            old_path = os.path.join(PROFILE_PHOTO_FOLDER, old_photo_name)
            if os.path.isfile(old_path):
                os.remove(old_path)
        return redirect(url_for("profile"))

    with get_db() as db:
        user_profile = db.execute(f"""
            SELECT id, name, {_full_name_sql('users')} AS display_name,
                   first_name, last_name, middle_initial, email, mobile, role,
                   student_number, profile_image
            FROM users WHERE id = ?
        """, (user_id,)).fetchone()
        pending_profile_request = db.execute("""
            SELECT id, proposed_values, changed_groups, status, submitted_at
            FROM profile_change_requests
            WHERE user_id = ? AND status IN (
                'Pending Email Verification',
                'Pending Registrar Review',
                'Pending Administrator Review'
            )
            ORDER BY id DESC LIMIT 1
        """, (user_id,)).fetchone()
        recent_profile_requests = db.execute("""
            SELECT id, status, submitted_at, rejection_reason
            FROM profile_change_requests
            WHERE user_id = ?
            ORDER BY id DESC LIMIT 5
        """, (user_id,)).fetchall()
        cooldowns = {
            row["field_group"]: row["available_after"]
            for row in db.execute("""
                SELECT field_group, available_after
                FROM profile_change_cooldowns WHERE user_id = ?
            """, (user_id,)).fetchall()
        }

    if not user_profile:
        session.clear()
        flash("Please log in again.")
        return redirect(url_for("login"))

    return render_template(
        "index.html",
        page="profile",
        user_profile=user_profile,
        pending_profile_request=pending_profile_request,
        recent_profile_requests=recent_profile_requests,
        profile_cooldowns=cooldowns,
    )


@app.route("/profile/verify-email/<token>")
def verify_profile_email(token):
    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    now = _utc_now().isoformat()
    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        change_request = db.execute("""
            SELECT id, user_id, status
            FROM profile_change_requests
            WHERE email_verification_token_hash = ?
              AND status = 'Pending Email Verification'
              AND email_verification_expires_at > ?
        """, (token_hash, now)).fetchone()
        if not change_request:
            flash("This verification link is invalid or expired.")
            return redirect(url_for("login"))
        db.execute("""
            UPDATE profile_change_requests
            SET status = 'Pending Registrar Review',
                email_verified_at = ?, email_verification_token_hash = NULL,
                email_verification_expires_at = NULL
            WHERE id = ?
        """, (now, change_request["id"]))
        _log_account_event(
            db, change_request["user_id"], change_request["user_id"],
            "profile_email_verified",
            new_values={"request_id": change_request["id"]},
        )
        _create_notification(
            db, change_request["user_id"],
            "Your new email is verified; the profile request is awaiting review.",
            url_for("profile"),
            category="profile",
            title="Email verified",
            related_type="profile_change_request",
            related_id=change_request["id"],
            dedupe_key=f"profile-request:{change_request['id']}:email-verified",
        )
        _notify_role(
            db, "Registrar Staff",
            "A profile change request is ready for review.",
            url_for("registrar_dashboard") + "#profile-reviews",
            category="profile",
            title="Profile change review",
            related_type="profile_change_request",
            related_id=change_request["id"],
            dedupe_key=f"profile-request:{change_request['id']}:registrar-review",
            exclude_user_id=change_request["user_id"],
        )
    flash("Email verified. Your profile request is now awaiting review.")
    return redirect(url_for("login"))


@app.route("/profile/requests/<int:request_id>/withdraw", methods=["POST"])
@role_required("Student", "Registrar Staff", "Teacher", "Admin")
def withdraw_profile_change(request_id):
    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        change_request = db.execute("""
            SELECT id, status, previous_values, proposed_values
            FROM profile_change_requests
            WHERE id = ? AND user_id = ?
        """, (request_id, session["user_id"])).fetchone()
        if not change_request:
            abort(404)
        if change_request["status"] not in {
            "Pending Email Verification", "Pending Registrar Review",
            "Pending Administrator Review",
        }:
            flash("Only a pending profile request can be withdrawn.")
            return redirect(url_for("profile"))
        db.execute("""
            UPDATE profile_change_requests SET status = 'Withdrawn'
            WHERE id = ?
        """, (request_id,))
        _log_account_event(
            db, session["user_id"], session["user_id"], "profile_change_withdrawn",
            previous_values=json.loads(change_request["previous_values"]),
            new_values=json.loads(change_request["proposed_values"]),
        )
    flash("Profile change request withdrawn.")
    return redirect(url_for("profile"))


@app.route("/profile/requests/<int:request_id>/review", methods=["POST"])
@role_required("Registrar Staff", "Admin")
def review_profile_change(request_id):
    decision = request.form.get("decision", "").strip()
    reason = request.form.get("reason", "").strip()
    override_reason = request.form.get("cooldown_override_reason", "").strip()
    actor_id = session["user_id"]
    actor_role = session["user_role"]
    if decision not in {"approve", "reject"}:
        abort(400)
    if decision == "reject" and (not reason or len(reason) > 500):
        flash("Provide a rejection reason of no more than 500 characters.")
        return redirect(url_for(
            "registrar_dashboard" if actor_role == "Registrar Staff"
            else "admin_dashboard"
        ) + "#profile-reviews")
    if override_reason and (actor_role != "Admin" or len(override_reason) < 10 or len(override_reason) > 500):
        flash("An administrator override requires a reason between 10 and 500 characters.")
        return redirect(url_for("admin_dashboard") + "#profile-reviews")

    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        change_request = db.execute("""
            SELECT * FROM profile_change_requests WHERE id = ?
        """, (request_id,)).fetchone()
        if not change_request:
            abort(404)
        if change_request["user_id"] == actor_id:
            abort(403)

        if actor_role == "Registrar Staff":
            if change_request["status"] != "Pending Registrar Review":
                flash("This request is not awaiting Registrar Staff review.")
                return redirect(url_for("registrar_dashboard") + "#profile-reviews")
            if decision == "reject":
                db.execute("""
                    UPDATE profile_change_requests
                    SET status = 'Rejected', registrar_reviewer_id = ?,
                        registrar_decision = 'Rejected', registrar_decided_at = ?,
                        rejection_reason = ?
                    WHERE id = ?
                """, (actor_id, _utc_now().isoformat(), reason, request_id))
            else:
                db.execute("""
                    UPDATE profile_change_requests
                    SET status = 'Pending Administrator Review',
                        registrar_reviewer_id = ?,
                        registrar_decision = 'Approved',
                        registrar_decided_at = ?
                    WHERE id = ?
                """, (actor_id, _utc_now().isoformat(), request_id))
                _create_notification(
                    db, change_request["user_id"],
                    "Your profile request passed Registrar review and is awaiting Administrator review.",
                    url_for("profile"),
                    category="profile",
                    title="Profile request advanced",
                    related_type="profile_change_request",
                    related_id=request_id,
                    dedupe_key=f"profile-request:{request_id}:registrar-approved",
                )
                _notify_role(
                    db, "Admin",
                    "A profile change request is awaiting Administrator review.",
                    url_for("admin_dashboard") + "#profile-reviews",
                    category="profile",
                    title="Profile change review",
                    related_type="profile_change_request",
                    related_id=request_id,
                    dedupe_key=f"profile-request:{request_id}:administrator-review",
                    exclude_user_id=change_request["user_id"],
                )
        else:
            if change_request["status"] != "Pending Administrator Review":
                flash("This request is not awaiting Administrator review.")
                return redirect(url_for("admin_dashboard") + "#profile-reviews")
            if change_request["registrar_reviewer_id"] == actor_id:
                abort(403)
            if decision == "reject":
                db.execute("""
                    UPDATE profile_change_requests
                    SET status = 'Rejected', admin_reviewer_id = ?,
                        admin_decision = 'Rejected', admin_decided_at = ?,
                        rejection_reason = ?
                    WHERE id = ?
                """, (actor_id, _utc_now().isoformat(), reason, request_id))
            else:
                changed_groups = json.loads(change_request["changed_groups"])
                active_cooldowns = [
                    group for group in changed_groups
                    if _active_cooldown(db, change_request["user_id"], group)
                ]
                if active_cooldowns and not override_reason:
                    flash(
                        "The 30-day cooldown is active for "
                        + ", ".join(active_cooldowns)
                        + ". Provide an Administrator override reason to approve."
                    )
                    return redirect(url_for("admin_dashboard") + "#profile-reviews")

                proposed = json.loads(change_request["proposed_values"])
                previous = json.loads(change_request["previous_values"])
                update_values = {}
                if "name" in proposed:
                    name_value = proposed["name"]
                    update_values.update(name_value)
                    update_values["name"] = _format_full_name(
                        name_value["last_name"],
                        name_value["first_name"],
                        name_value.get("middle_initial") or "",
                    )
                if "email" in proposed:
                    update_values["email"] = proposed["email"]["email"]
                if "student_number" in proposed:
                    update_values["student_number"] = proposed["student_number"]["student_number"]
                assignments = ", ".join(f"{field} = ?" for field in update_values)
                if assignments:
                    if "name" in proposed:
                        assignments += ", name_review_required = 0"
                    db.execute(
                        f"UPDATE users SET {assignments} "
                        "WHERE id = ?",
                        (*update_values.values(), change_request["user_id"]),
                    )
                now = _utc_now()
                cooldown_until = (now + timedelta(days=30)).isoformat()
                for group in changed_groups:
                    db.execute("""
                        INSERT INTO profile_change_cooldowns (
                            user_id, field_group, available_after
                        )
                        VALUES (?, ?, ?)
                        ON CONFLICT(user_id, field_group)
                        DO UPDATE SET available_after = excluded.available_after
                    """, (change_request["user_id"], group, cooldown_until))
                db.execute("""
                    UPDATE profile_change_requests
                    SET status = 'Approved', admin_reviewer_id = ?,
                        admin_decision = 'Approved', admin_decided_at = ?,
                        cooldown_override_reason = ?, cooldown_override_by = ?
                    WHERE id = ?
                """, (
                    actor_id, now.isoformat(), override_reason or None,
                    actor_id if override_reason else None, request_id,
                ))
                _log_account_event(
                    db, actor_id, change_request["user_id"], "profile_change_approved",
                    previous_values=previous, new_values=proposed,
                    reason=override_reason or None,
                )
            if decision == "reject":
                _log_account_event(
                    db, actor_id, change_request["user_id"], "profile_change_rejected",
                    reason=reason,
                )

        if decision == "reject" or actor_role == "Admin":
            final_status = "Rejected" if decision == "reject" else "Approved"
            _create_notification(
                db, change_request["user_id"],
                f"Your profile change request #{request_id} was {final_status.lower()}."
                " Sign in to view details.",
                url_for("profile"),
                category="profile",
                title=f"Profile change {final_status.lower()}",
                related_type="profile_change_request",
                related_id=request_id,
                dedupe_key=f"profile-request:{request_id}:{final_status.lower()}",
            )
        if actor_role == "Registrar Staff" and decision == "reject":
            _notify_role(
                db, "Admin",
                "A profile change request was rejected during Registrar review.",
                url_for("admin_dashboard") + "#activity",
                category="profile",
                title="Profile review outcome",
                related_type="profile_change_request",
                related_id=request_id,
                dedupe_key=f"profile-request:{request_id}:registrar-rejected",
                exclude_user_ids=(actor_id, change_request["user_id"]),
            )
        if actor_role == "Admin":
            _notify_role(
                db, "Admin",
                f"An Administrator {final_status.lower()} a profile change request.",
                url_for("admin_dashboard") + "#activity",
                category="profile",
                title="Profile review outcome",
                related_type="profile_change_request",
                related_id=request_id,
                dedupe_key=f"profile-request:{request_id}:administrator-{final_status.lower()}",
                exclude_user_ids=(actor_id, change_request["user_id"]),
            )
        if actor_role == "Registrar Staff":
            _log_account_event(
                db, actor_id, change_request["user_id"],
                "profile_change_registrar_" + decision,
                reason=reason or None,
            )

    flash(
        "Profile request reviewed."
        if decision == "approve"
        else "Profile request rejected."
    )
    return redirect(url_for(
        "registrar_dashboard" if actor_role == "Registrar Staff"
        else "admin_dashboard"
    ) + "#profile-reviews")


@app.route("/profile/change-password", methods=["POST"])
@role_required("Student", "Registrar Staff", "Teacher", "Admin")
def change_password():
    current_password = request.form.get("current_password", "")
    new_password = request.form.get("new_password", "")
    confirm_password = request.form.get("confirm_password", "")
    if len(new_password) < 8:
        flash("New password must be at least 8 characters.")
        return redirect(url_for("profile"))
    if new_password != confirm_password:
        flash("The new passwords do not match.")
        return redirect(url_for("profile"))

    with get_db() as db:
        db.execute("BEGIN IMMEDIATE")
        user = db.execute("""
            SELECT password_hash, auth_version
            FROM users WHERE id = ?
        """, (session["user_id"],)).fetchone()
        if not user or not check_password_hash(user["password_hash"], current_password):
            flash("Current password is incorrect.")
            return redirect(url_for("profile"))
        if check_password_hash(user["password_hash"], new_password):
            flash("Choose a password different from your current password.")
            return redirect(url_for("profile"))
        db.execute("""
            UPDATE users
            SET password_hash = ?, password_changed_at = ?,
                auth_version = auth_version + 1
            WHERE id = ?
        """, (
            generate_password_hash(new_password), _utc_now().isoformat(),
            session["user_id"],
        ))
        _log_account_event(
            db, session["user_id"], session["user_id"], "password_changed",
            previous_values={"auth_version": user["auth_version"]},
            new_values={"auth_version": user["auth_version"] + 1},
        )
        _create_notification(
            db, session["user_id"],
            "Your password was changed. If you did not make this change, contact an Administrator.",
            url_for("login"),
            category="security",
            title="Password changed",
            related_type="user",
            related_id=session["user_id"],
        )
        _notify_role(
            db, "Admin",
            "A user password was changed.",
            url_for("admin_dashboard") + "#activity",
            category="security",
            title="Password changed",
            related_type="user",
            related_id=session["user_id"],
            exclude_user_id=session["user_id"],
        )
    session.clear()
    flash("Password changed. Please sign in again.")
    return redirect(url_for("login"))


# View Appointment Receipt
@app.route("/appointment-receipt/<int:appointment_id>")
@role_required("Student")
def appointment_receipt(appointment_id):
    with get_db() as db:
        appointment = db.execute(
            """
            SELECT
                a.*,
                u.name,
                u.student_number
            FROM appointments a
            JOIN users u ON a.user_id = u.id
            WHERE a.id = ?
              AND a.user_id = ?
            """,
            (appointment_id, session["user_id"])
        ).fetchone()

    if not appointment:
        abort(404)

    # Prepare QR code data
    verification_token = appointment["verification_token"]

    verify_url = url_for(
        "verify_appointment",
        token=verification_token,
        _external=True
    )

    qr = qrcode.QRCode(
        version=None,
        error_correction=qrcode.constants.ERROR_CORRECT_M,
        box_size=8,
        border=4
    )

    qr.add_data(verify_url)
    qr.make(fit=True)

    qr_image = qr.make_image(
        fill_color="black",
        back_color="white"
    )

    qr_buffer = io.BytesIO()
    qr_image.save(qr_buffer, format="PNG")

    qr_base64 = base64.b64encode(
        qr_buffer.getvalue()
    ).decode("utf-8")

    qr_data_uri = f"data:image/png;base64,{qr_base64}"

    return render_template(
        "receipt.html",
        appointment=appointment,
        qr_data_uri=qr_data_uri
    )


# Verify Appointment using QR Code
@app.route("/verify-appointment/<token>")
def verify_appointment(token):
    with get_db() as db:
        appointment = db.execute(
            """
            SELECT
                reference_number,
                service,
                appointment_date,
                appointment_time,
                campus,
                status
            FROM appointments
            WHERE verification_token = ?
            """,
            (token,)
        ).fetchone()

    if not appointment:
        abort(404)

    return render_template(
        "verify_appointment.html",
        appointment=appointment
    )


# Logout
@app.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    return redirect(url_for("login"))


# Initialize database and start Flask
init_db()

if __name__ == "__main__":
    app.run(debug=True)
